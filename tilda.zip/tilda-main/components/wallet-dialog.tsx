"use client"

import { useState } from "react"
import { useTonAddress, useTonConnectUI } from "@tonconnect/ui-react"
import { Wallet, Check, ChevronRight, Loader2 } from "lucide-react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogBody, DialogFooter } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"

const WalletIcon = ({ size = 20, color = "#fff" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M21.1009 8.00353C21.0442 7.99996 20.9825 7.99998 20.9186 8L20.9026 8.00001H18.3941C16.3264 8.00001 14.5572 9.62757 14.5572 11.75C14.5572 13.8724 16.3264 15.5 18.3941 15.5H20.9026L20.9186 15.5C20.9825 15.5 21.0442 15.5001 21.1009 15.4965C21.9408 15.4434 22.6835 14.7862 22.746 13.8682C22.7501 13.808 22.75 13.7431 22.75 13.683L22.75 13.6667V9.83334L22.75 9.81702C22.75 9.75688 22.7501 9.69199 22.746 9.6318C22.6835 8.71381 21.9408 8.05657 21.1009 8.00353ZM18.1717 12.75C18.704 12.75 19.1355 12.3023 19.1355 11.75C19.1355 11.1977 18.704 10.75 18.1717 10.75C17.6394 10.75 17.2078 11.1977 17.2078 11.75C17.2078 12.3023 17.6394 12.75 18.1717 12.75Z"
      fill={color}
    />
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M20.9179 17C21.067 16.9961 21.1799 17.1342 21.1394 17.2778C20.9387 17.9902 20.62 18.5975 20.1088 19.1088C19.3604 19.8571 18.4114 20.1892 17.239 20.3469C16.0998 20.5 14.6442 20.5 12.8064 20.5H10.6936C8.85583 20.5 7.40019 20.5 6.26098 20.3469C5.08856 20.1892 4.13961 19.8571 3.39124 19.1088C2.64288 18.3604 2.31076 17.4114 2.15314 16.239C1.99997 15.0998 1.99998 13.6442 2 11.8064V11.6936C1.99998 9.85583 1.99997 8.40019 2.15314 7.26098C2.31076 6.08856 2.64288 5.13961 3.39124 4.39124C4.13961 3.64288 5.08856 3.31076 6.26098 3.15314C7.40019 2.99997 8.85582 2.99998 10.6936 3L12.8064 3C14.6442 2.99998 16.0998 2.99997 17.239 3.15314C18.4114 3.31076 19.3604 3.64288 20.1088 4.39124C20.62 4.90252 20.9386 5.50974 21.1394 6.22218C21.1799 6.36575 21.067 6.50387 20.9179 6.5L18.394 6.50001C15.5574 6.50001 13.0571 8.74091 13.0571 11.75C13.0571 14.7591 15.5574 17 18.394 17L20.9179 17ZM5.75 7C5.33579 7 5 7.33579 5 7.75C5 8.16421 5.33579 8.5 5.75 8.5H9.75C10.1642 8.5 10.5 8.16421 10.5 7.75C10.5 7.33579 10.1642 7 9.75 7H5.75Z"
      fill={color}
    />
  </svg>
)

interface WalletDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  walletConnected: boolean
  userAddress: string | null
}

export function WalletDialog({ open, onOpenChange, walletConnected, userAddress }: WalletDialogProps) {
  const [tonConnectUI] = useTonConnectUI()
  const [isConnecting, setIsConnecting] = useState(false)

  const formatAddress = (address: string) => {
    if (!address) return ""
    return `${address.slice(0, 8)}...${address.slice(-8)}`
  }

  const handleConnect = async () => {
   setIsConnecting(true);
    try {
    if (walletConnected) {
      await tonConnectUI.disconnect()
    }
    onOpenChange(false)
    await tonConnectUI.openModal()
  } finally {
    setIsConnecting(false);
   }
 }

  const handleDisconnect = async () => {
    setIsConnecting(true)
    try {
      await tonConnectUI.disconnect()
    } finally {
      setIsConnecting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95%] max-w-md mx-auto gradient-dark text-white rounded-3xl">
        <DialogHeader className="text-center">
          <DialogTitle className="text-center fire-text text-xl font-bold">
            Wallet Connection
          </DialogTitle>
          <DialogDescription className="text-[#a0a0a0] text-sm">
            {walletConnected ? "Manage your connected wallet" : "Connect your TON wallet"}
          </DialogDescription>
        </DialogHeader>

        <DialogBody className="space-y-4 py-4">
          {walletConnected && userAddress && (
            <div className="space-y-3">
              <div className="text-white text-sm font-medium">Connected Wallet</div>
              <Card className="border border-[#1A1A1A] bg-[#0f0f0f] rounded-2xl">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full fire-gradient flex items-center justify-center">
                      <WalletIcon size={20} color="#fff" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="font-medium text-sm truncate text-white">TON Wallet</div>
                        <Badge className="bg-[#ff6b35] text-white text-xs px-2 py-0.5 rounded-full border-0 font-medium">
                          Connected
                        </Badge>
                      </div>
                      <div className="text-xs font-mono text-[#a0a0a0] truncate">{formatAddress(userAddress)}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <div className="space-y-3">
            <Button
              onClick={handleConnect}
              className="w-full fire-gradient hover:[#ff6b35]/90 text-white rounded-2xl h-12 flex items-center justify-center gap-2 transition-all duration-200"
              disabled={isConnecting}
            >
              {isConnecting ? <Loader2 className="w-5 h-5 animate-spin" /> : <>
                <WalletIcon className="w-5 h-5" />
                {walletConnected ? "Switch Wallet" : "Connect Wallet"}
              </>}
            </Button>

            {walletConnected && (
              <Button
                onClick={handleDisconnect}
                variant="outline"
                className="w-full border border-[#1A1A1A] text-[#ff4d4d] hover:bg-[#2a2a2a] hover:text-[#ff4d4d] rounded-2xl h-12 transition-all duration-200"
                disabled={isConnecting}
              >
                {isConnecting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Disconnect Wallet"}
              </Button>
            )}
          </div>
        </DialogBody>

        <DialogFooter>
          <Button
            onClick={() => onOpenChange(false)}
            variant="outline"
            className="w-full border-[#1A1A1A] text-[#a0a0a0] hover:bg-[#2a2a2a] rounded-xl h-11 transition-all duration-200"
          >
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

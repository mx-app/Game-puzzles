import { motion } from "framer-motion"
import { FaTrophy, FaTelegram } from "react-icons/fa"
import { MdRocketLaunch } from "react-icons/md"
import { CHANNEL_URL } from "@/lib/config"

export function LeaderboardSection({ router }: { router: any }) {
  return (
    <motion.div 
      className="dark-bg bg-overlay rounded-2xl overflow-hidden relative"
    >
      <div className="relative z-2">
        <motion.div 
          whileTap={{ scale: 0.98 }}
          onClick={() => window.open(CHANNEL_URL, "_blank")}
          className="p-2.5 flex items-center justify-between cursor-pointer hover:bg-[#1a1a1a] transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="bg-[#ff6b35]/10 p-2 rounded-lg border border-[#ff6b35]/20">
              <FaTelegram className="w-5 h-5 text-[#ff6b35]" />
            </div>
            <div>
              <div className="text-sm font-medium">Telegram Channel</div>
              <div className="text-xs text-[#a0a0a0]">Follow our Latest updates</div>
            </div>
          </div>
          <svg 
            width="20" 
            height="20" 
            viewBox="0 0 24 24" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg"
            className="text-[#ff6b35]"
          >
            <path 
              d="M9 18L15 12L9 6" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
          </svg>
        </motion.div>

        <div className="border-t border-[#1A1A1A] mx-3" />
        
        <motion.div 
          whileTap={{ scale: 0.98 }}
          onClick={() => router.push("/drop")}
          className="p-2.5 flex items-center justify-between cursor-pointer hover:bg-[#1a1a1a] transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="bg-[#ff6b35]/10 p-2 rounded-lg border border-[#ff6b35]/20">
              <MdRocketLaunch className="w-5 h-5 text-[#ff6b35]" />
            </div>
            <div>
              <div className="text-sm font-medium">Airdrop</div>
              <div className="text-xs text-[#a0a0a0]">Complete tasks & Get ready</div>
            </div>
          </div>
          <svg 
            width="20" 
            height="20" 
            viewBox="0 0 24 24" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg"
            className="text-[#ff6b35]"
          >
            <path 
              d="M9 18L15 12L9 6" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
          </svg>
        </motion.div>
      </div>
    </motion.div>
  )
}

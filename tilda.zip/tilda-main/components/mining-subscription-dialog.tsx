"use client"

import { FaClock, FaBolt, FaInfoCircle, FaCrown } from "react-icons/fa"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { SIMPLE, NAME } from "@/lib/config"

export const MiningSubscriptionDialog = ({
  open,
  onOpenChange,
  subscription,
  upgrades,
  onUpgrade
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  subscription: any
  upgrades: any
  onUpgrade: () => void
}) => {
  const isPremium = subscription?.plan === 'premium'
  const miningRate = isPremium ? 20000 : 5000
  const miningDuration = isPremium ? 8 : 12

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95%] max-w-md mx-auto gradient-dark rounded-3xl">
        <DialogHeader className="text-center">
          <DialogTitle className="fire-text text-xl font-bold">
            {isPremium ? 'Premium Mining' : 'Free Mining'}
          </DialogTitle>
          <DialogDescription className="text-[#a0a0a0] text-sm">
            Your current mining subscription details
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 px-6 py-4">
          <div className="bg-[#0f0f0f] border border-[#1A1A1A] rounded-xl p-4">
            <div className="flex items-center justify-between mb-4">
              <Badge variant={isPremium ? "premium" : "secondary"} className={isPremium ? "bg-[#ff6b35]" : "bg-[#45aef5]"}>
                {isPremium ? 'Premium Plan' : 'Free Plan'}
              </Badge>
              {!isPremium && (
                <Button 
                  onClick={onUpgrade}
                  size="sm" 
                  className="fire-gradient rounded-xl"
                >
                  <FaCrown className="mr-2" />
                  Upgrade
                </Button>
              )}
            </div>

            <div className="flex items-center gap-3 mb-3">
              <div className={`${isPremium ? 'bg-[#ff6b35]/10' : 'bg-[#45aef5]/10'} p-2 rounded-lg`}>
                <FaBolt className={`w-5 h-5 ${isPremium ? 'text-[#ff6b35]' : 'text-[#45aef5]'}`} />
              </div>
              <div>
                <div className="text-white font-medium">Mining Rate</div>
                <div className="text-[#a0a0a0] text-sm">
                  {miningRate} {SIMPLE} per session
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className={`${isPremium ? 'bg-[#ff6b35]/10' : 'bg-[#45aef5]/10'} p-2 rounded-lg`}>
                <FaClock className={`w-5 h-5 ${isPremium ? 'text-[#ff6b35]' : 'text-[#45aef5]'}`} />
              </div>
              <div>
                <div className="text-white font-medium">Mining Duration</div>
                <div className="text-[#a0a0a0] text-sm">
                  Every {miningDuration} hours
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#0f0f0f] border border-[#1A1A1A] rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="bg-purple-500/10 p-2 rounded-lg">
                <FaInfoCircle className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <div className="text-white font-medium">Subscription Status</div>
                <div className="text-[#a0a0a0] text-sm">
                  Active - {isPremium ? 'Premium (Permanent)' : 'Free (Permanent)'}
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button
            onClick={() => onOpenChange(false)}
            variant="outline"
            className="w-full border-[#1A1A1A] text-[#a0a0a0] hover:bg-[#2a2a2a] rounded-xl h-11 transition-all duration-200"
          >
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

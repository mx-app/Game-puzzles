import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { LuPickaxe } from "react-icons/lu"
import { FaInfoCircle, FaClock } from "react-icons/fa"
import { SIMPLE, NAME } from "@/lib/config"

export function MiningStatusCard({
  isSubscriptionActive,
  canClaim,
  minedCoins,
  timeRemaining,
  isProcessing,
  setShowPlanDialog,
  setShowSubscriptionInfoDialog,
  handleClaimReward
}: {
  isSubscriptionActive: boolean
  canClaim: boolean
  minedCoins: number
  timeRemaining: number
  isProcessing: boolean
  setShowPlanDialog: (open: boolean) => void
  setShowSubscriptionInfoDialog: (open: boolean) => void
  handleClaimReward: () => void
}) {
  const formatTime = (milliseconds: number) => {
    const totalSeconds = Math.floor(milliseconds / 1000)
    const hours = Math.floor(totalSeconds / 3600)
    const minutes = Math.floor((totalSeconds % 3600) / 60)
    const seconds = totalSeconds % 60
    return `${hours}h ${minutes}m ${seconds}s`
  }

  const formatMiningCoins = (coins: number) => {
    return coins.toFixed(1)
  }

  return (
    <div className="flex gap-2 mb-4">
      {isSubscriptionActive && (
        <Button
          onClick={() => setShowSubscriptionInfoDialog(true)}
          className="rounded-2xl bg-[#0f0f0f] hover:bg-[#2a2a2a] h-12 px-4"
        >
          <FaInfoCircle className="w-5 h-5" />
        </Button>
      )}
      
       <motion.div
        whileTap={{ scale: 0.95 }}
        transition={{ type: "spring", stiffness: 400, damping: 17 }}
        className="flex-1"
      >
        <Button
          onClick={() => isSubscriptionActive 
            ? (canClaim ? handleClaimReward() : null) 
            : setShowPlanDialog(true)}
          className={`w-full h-12 rounded-2xl relative overflow-hidden ${isSubscriptionActive 
            ? canClaim 
              ? "fire-gradient hover:bg-[#ff6b35]/50" 
              : "bg-[#2a2a2a] hover:bg-[#3a3a3a]"
            : "fire-gradient hover:bg-[#ff6b35]/50"}`}
          disabled={isSubscriptionActive && !canClaim && !isProcessing}
        >
          {isProcessing ? (
            <div className="flex items-center gap-2">
              <FaClock className="w-5 h-5 animate-spin" />
              <span>Processing...</span>
            </div>
          ) : isSubscriptionActive ? (
            canClaim ? (
              <div className="w-full flex items-center justify-center gap-2">
                <LuPickaxe className="w-5 h-5" />
                <span>Claim {formatMiningCoins(minedCoins)} {SIMPLE}</span>
              </div>
            ) : (
              <div className="w-full flex items-center justify-between px-4">
                <div className="flex items-center gap-1">
                  <div className="text-sm opacity-80">
                    {formatMiningCoins(minedCoins)} {SIMPLE}
                  </div>
                </div>
                <div className="text-sm opacity-80">
                  {formatTime(timeRemaining)}
                </div>
              </div>
            )
          ) : (
            <div className="flex items-center gap-2">
              <LuPickaxe className="w-5 h-5" />
              <span>Start Mining</span>
            </div>
          )}
        </Button>
      </motion.div>
    </div>
  )
}

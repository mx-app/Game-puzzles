"use client"

import { useRouter, usePathname } from "next/navigation"
import { GameController, ListChecks, Ranking, Users, HouseSimple } from "@phosphor-icons/react"

export function BottomNavigation() {
  const router = useRouter()
  const pathname = usePathname()

  const navItems = [
    {
      name: "Games",
      path: "/games",
      icon: <GameController className="w-5 h-5" />,
      activeIcon: (
        <GameController
          className="w-6 h-6"
          weight="duotone"
          color="#ff6b35"
          secondaryColor="#ff6b35"
          secondaryOpacity={0.5}
        />
      ),
    },
    {
      name: "Tasks",
      path: "/tasks",
      icon: <ListChecks className="w-5 h-5" />,
      activeIcon: (
        <ListChecks
          className="w-6 h-6"
          weight="duotone"
          color="#ff6b35"
          secondaryColor="#ff6b35"
          secondaryOpacity={0.5}
        />
      ),
    },
    {
      name: "Home",
      path: "/",
      icon: <HouseSimple className="w-5 h-5" />,
      activeIcon: (
        <HouseSimple
          className="w-6 h-6"
          weight="duotone"
          color="#ff6b35"
          secondaryColor="#ff6b35"
          secondaryOpacity={0.5}
        />
      ),
    },
    {
      name: "Leaders",
      path: "/leaders",
      icon: <Ranking className="w-5 h-5" />,
      activeIcon: (
        <Ranking
          className="w-6 h-6"
          weight="duotone"
          color="#ff6b35"
          secondaryColor="#ff6b35"
          secondaryOpacity={0.5}
        />
      ),
    },
    {
      name: "Referrals",
      path: "/referrals",
      icon: <Users className="w-5 h-5" />,
      activeIcon: (
        <Users
          className="w-6 h-6"
          weight="duotone"
          color="#ff6b35"
          secondaryColor="#ff6b35"
          secondaryOpacity={0.5}
        />
      ),
    },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 z-20 bg-[#000]/80 backdrop-blur-md px-3">
      <div className="flex items-stretch h-full">
        {navItems.map((item, index) => {
          const isActive = pathname === item.path
          const Icon = isActive ? item.activeIcon : item.icon
          return (
            <button
              key={item.path || index}
              onClick={() => router.push(item.path)}
              className={`flex-1 flex flex-col items-center justify-center py-3 transition-all duration-300 ${
                isActive ? "text-[#ff6b35]" : "text-[#666666] hover:text-[#a0a0a0]"
              }`}
            >
              <div className={`transition-all duration-300 ${isActive ? "scale-110" : ""}`}>
                {Icon}
              </div>
              <span
                className={`text-xs font-medium mt-1 truncate max-w-full px-1 ${
                  isActive ? "text-[#ff6b35]" : "text-[#666666]"
                }`}
              >
                {item.name}
              </span>
            </button>
          )
        })}
      </div>
    </div>
  )
}

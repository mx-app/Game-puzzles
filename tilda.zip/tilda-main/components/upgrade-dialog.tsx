"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogBody, DialogFooter } from "@/components/ui/dialog"
import { FaBolt, FaClock } from "react-icons/fa"
import Image from "next/image"
import { motion } from "framer-motion"
import { useTonAddress, useTonConnectUI } from "@tonconnect/ui-react"
import { createInvoiceLink, openTelegramInvoice } from "@/lib/payment-service"
import { WALLET_ADDRESS } from "@/lib/wallet-config"
import { useToast } from "@/components/ui/use-toast"
import { walletService } from "@/lib/wallet-service"
import { SIMPLE, NAME } from "@/lib/config"

interface UpgradeDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onUpgrade: () => void
  type: "rate" | "time"
  currentLevel: number
  miningRate: number
  miningDuration: number
}

export function UpgradeDialog({
  open,
  onOpenChange,
  onUpgrade,
  type,
  currentLevel,
  miningRate,
  miningDuration
}: UpgradeDialogProps) {
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingMethod, setProcessingMethod] = useState<"ton" | "stars" | null>(null)
  const [tonConnectUI] = useTonConnectUI()
  const userAddress = useTonAddress()
  const { toast } = useToast()
  const [walletBalance, setWalletBalance] = useState<string>("0") 

  const upgradeCost = 0.2 + currentLevel * 0.2
  const starsCost = Math.floor(upgradeCost * 400)

  useEffect(() => {
    const fetchWalletBalance = async () => {
      if (!userAddress) {
        setWalletBalance("0")
        return
      }

      try {
        const balanceData = await walletService.checkTonWalletBalance(userAddress)
        
        if (balanceData.success) {
          setWalletBalance(balanceData.balance)
        } else {
          console.error("Failed to fetch wallet balance:", balanceData.error)
          setWalletBalance("0")
        }
      } catch (error) {
        console.error("Error fetching wallet balance:", error)
        setWalletBalance("0")
      }
    }

    fetchWalletBalance()
  }, [userAddress])

  const processUpgrade = async (paymentMethod: "ton" | "stars") => {
    setIsProcessing(true)
    setProcessingMethod(paymentMethod)
    
    try {
      if (paymentMethod === "ton") {
        if (!userAddress) {
          onOpenChange(false)
          await tonConnectUI.openModal()
          return
        }

        const balanceCheck = await walletService.hasEnoughBalance(
          userAddress,
          upgradeCost
        )

        if (!balanceCheck.sufficient) {
          throw new Error(
            `Insufficient balance. You need ${upgradeCost} TON but have ${balanceCheck.currentBalance.toFixed(2)} TON`
          )
        }

        const tonAmount = BigInt(Math.floor(upgradeCost * 1000000000))

        const result = await tonConnectUI.sendTransaction({
          validUntil: Math.floor(Date.now() / 1000) + 600,
          messages: [
            {
              address: WALLET_ADDRESS,
              amount: tonAmount.toString(),
            },
          ],
        })

        if (!result?.boc) {
          throw new Error("Transaction failed")
        }
      } else {
        const invoiceLink = await createInvoiceLink(
          starsCost,
          `Mining Upgrade - ${type}`,
          `Upgrade your mining ${type === "rate" ? "rate" : "time"}`,
        )

        const status = await openTelegramInvoice(invoiceLink)
        if (status !== "paid") {
          throw new Error("Payment not completed")
        }
      }

      onUpgrade()
    } catch (error) {
      console.error("Upgrade error:", error)
      toast({
        title: "Upgrade failed",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
      setProcessingMethod(null)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95%] max-w-md mx-auto gradient-dark rounded-3xl">
        <DialogHeader className="text-center">
          <DialogTitle className="fire-text text-xl font-bold">
            Upgrade {type === "rate" ? "Mining Rate" : "Time Reduction"}
          </DialogTitle>
          <DialogDescription className="text-[#a0a0a0] text-sm">
            {type === "rate"
              ? "Increase the amount of tokens you mine per session"
              : "Reduce the time needed between mining sessions"}
          </DialogDescription>
        </DialogHeader>

        <DialogBody className="space-y-4 px-6 py-4">
          <div className="bg-[#1A1A1A] rounded-xl p-4">
            <div className="text-[#a0a0a0] text-sm mb-1 text-center">Upgrade Cost</div>
            <div className="text-white font-semibold text-lg flex items-center justify-center gap-1">
              {upgradeCost.toFixed(1)} <Image src="/toncoin.svg" alt="TON" width={16} height={16} />
              <span className="mx-2">or</span> 
              {starsCost} <Image src="/stars.svg" alt="Stars" width={16} height={16} />
            </div>
            <div className="mt-3 text-center">
              <Badge className="bg-[#ff6b35]/10 text-[#ff6b35] border-[#ff6b35]/20 text-xs">
                Current Level: {currentLevel}/5
              </Badge>
            </div>
            {userAddress && (
              <div className="text-sm text-[#a0a0a0] mt-2 text-center">
                Wallet Balance: <span className="text-white">{Number(walletBalance).toFixed(2)} TON</span>
              </div>
            )}
          </div>

          <motion.div whileTap={{ scale: 0.98 }}>
            <Button
              onClick={() => processUpgrade("ton")}
              disabled={isProcessing}
              className="w-full fire-gradient hover:bg-[#3a9de0] text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
            >
              {isProcessing && processingMethod === "ton" ? (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                </div>
              ) : (
                <>
                  <Image src="/toncoin.svg" alt="TON" width={20} height={20} />
                  <span>Pay {upgradeCost.toFixed(1)} TON</span>
                </>
              )}
            </Button>
          </motion.div>

          <motion.div whileTap={{ scale: 0.98 }}>
            <Button
              onClick={() => processUpgrade("stars")}
              disabled={isProcessing}
              className="w-full fire-gradient hover:from-yellow-500 hover:to-yellow-700 text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
            >
              {isProcessing && processingMethod === "stars" ? (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                </div>
              ) : (
                <>
                  <Image src="/stars.svg" alt="Stars" width={20} height={20} />
                  <span>Pay {starsCost} Stars</span>
                </>
              )}
            </Button>
          </motion.div>
        </DialogBody>

        <DialogFooter className="px-6 pb-6">
          <motion.div whileTap={{ scale: 0.98 }} className="w-full">
            <Button
              onClick={() => onOpenChange(false)}
              variant="outline"
              className="w-full border-[#1A1A1A] text-[#a0a0a0] hover:bg-[#1a1a1a] rounded-xl h-10"
            >
              Cancel
            </Button>
          </motion.div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

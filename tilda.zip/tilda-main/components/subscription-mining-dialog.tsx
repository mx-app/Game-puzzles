"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogBody, DialogFooter } from "@/components/ui/dialog"
import Image from "next/image"
import { motion } from "framer-motion"
import { useTonAddress, useTonConnectUI } from "@tonconnect/ui-react"
import { createInvoiceLink, openTelegramInvoice } from "@/lib/payment-service"
import { WALLET_ADDRESS } from "@/lib/wallet-config"
import { useToast } from "@/components/ui/use-toast"
import { walletService } from "@/lib/wallet-service"
import { Badge } from "@/components/ui/badge"
import { FaClock, FaBolt, FaInfoCircle, FaCrown } from "react-icons/fa"
import { cn } from "@/lib/utils"
import { SIMPLE, NAME } from "@/lib/config"

interface SubscriptionDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubscribe: (plan: 'free' | 'premium') => void
  currentPlan?: 'free' | 'premium' | null
}

export function SubscriptionDialog({ 
  open, 
  onOpenChange,
  onSubscribe,
  currentPlan
}: SubscriptionDialogProps) {
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingMethod, setProcessingMethod] = useState<"ton" | "stars" | null>(null)
  const [tonConnectUI] = useTonConnectUI()
  const userAddress = useTonAddress()
  const { toast } = useToast()
  const [walletBalance, setWalletBalance] = useState<string>("0")

  useEffect(() => {
    const fetchWalletBalance = async () => {
      if (!userAddress) {
        setWalletBalance("0")
        return
      }

      try {
        const balanceData = await walletService.checkTonWalletBalance(userAddress)
        
        if (balanceData.success) {
          setWalletBalance(balanceData.balance)
        } else {
          console.error("Failed to fetch wallet balance:", balanceData.error)
          setWalletBalance("0")
        }
      } catch (error) {
        console.error("Error fetching wallet balance:", error)
        setWalletBalance("0")
      }
    }

    fetchWalletBalance()
  }, [userAddress])

  const handleSubscribe = async (paymentMethod: "ton" | "stars" | "free") => {
    setIsProcessing(true)
    setProcessingMethod(paymentMethod === 'free' ? null : paymentMethod)
    
    try {
      if (paymentMethod === "free") {
        onSubscribe('free')
        toast({
          title: "Free Subscription Activated",
          description: "Your free mining subscription is now active!",
        })
        onOpenChange(false)
        return
      }

      if (paymentMethod === "ton") {
        if (!userAddress) {
          onOpenChange(false)
          await tonConnectUI.openModal()
          return
        }

        const balanceCheck = await walletService.hasEnoughBalance(
          userAddress,
          1
        )

        if (!balanceCheck.sufficient) {
          throw new Error(
            `Insufficient balance. You need 1 TON but have ${balanceCheck.currentBalance.toFixed(2)} TON`
          )
        }

        const tonAmount = BigInt(Math.floor(1 * 1000000000))

        const result = await tonConnectUI.sendTransaction({
          validUntil: Math.floor(Date.now() / 1000) + 600,
          messages: [
            {
              address: WALLET_ADDRESS,
              amount: tonAmount.toString(),
            },
          ],
        })

        if (!result?.boc) {
          throw new Error("Transaction failed")
        }
      } else if (paymentMethod === "stars") {
        const invoiceLink = await createInvoiceLink(
          400,
          "Premium Mining Subscription",
          "Activate premium mining subscription",
        )

        const status = await openTelegramInvoice(invoiceLink)
        if (status !== "paid") {
          throw new Error("Payment not completed")
        }
      }

      onSubscribe('premium')
      toast({
        title: "Premium Subscription Activated",
        description: "Your premium mining subscription is now active!",
      })
      onOpenChange(false)
    } catch (error) {
      console.error("Subscription error:", error)
      toast({
        title: "Subscription failed",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
      setProcessingMethod(null)
    }
  }

  const isFreePlanActive = currentPlan === 'free'

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95%] max-w-md mx-auto gradient-dark rounded-3xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader className="text-center shrink-0">
          <DialogTitle className="fire-text text-xl font-bold">Mining Subscription</DialogTitle>
          <DialogDescription className="text-[#a0a0a0] text-sm">
            Choose your mining subscription plan
          </DialogDescription>
        </DialogHeader>

        <DialogBody className="flex-1 overflow-y-auto px-6 py-4">
          <div className="space-y-4">
            <div className="dark-bg border-tp rounded-2xl p-4">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-white font-bold">Premium Plan</h3>
                <Badge variant="secondary" className="tp-bg text-white">
                  Premium
                </Badge>
              </div>
              <ul className="text-[#a0a0a0] text-sm space-y-1 mb-4">
                <li className="flex items-center gap-2">
                  <FaBolt className="text-tp" /> 20,000 {SIMPLE} per session
                </li>
                <li className="flex items-center gap-2">
                  <FaClock className="text-tp" /> Every 8 hours
                </li>
                <li className="flex items-center gap-2">
                  <FaInfoCircle className="text-tp" /> Permanent access
                </li>
              </ul>
              <div className="bg-[#101010] rounded-lg p-3 mb-4 text-center">
                <div className="text-white font-semibold text-lg flex items-center justify-center gap-1">
                  1 <Image src="/toncoin.svg" alt="TON" width={16} height={16} />
                  <span className="mx-2">or</span> 
                  400 <Image src="/stars.svg" alt="Stars" width={16} height={16} />
                </div>
                {userAddress && (
                  <div className="text-sm text-[#a0a0a0] mt-1 text-center">
                    Wallet Balance: <span className="text-white">{Number(walletBalance).toFixed(2)} TON</span>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <motion.div whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => handleSubscribe("ton")}
                    disabled={isProcessing}
                    className="w-full fire-gradient text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                  >
                    {processingMethod === "ton" ? (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : (
                      <>
                        <span>Pay 1</span>
                        <Image src="/toncoin.svg" alt="TON" width={20} height={20} />
                      </>
                    )}
                  </Button>
                </motion.div>
                <motion.div whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => handleSubscribe("stars")}
                    disabled={isProcessing}
                    className="w-full fire-gradient text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                  >
                    {processingMethod === "stars" ? (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : (
                      <>
                        <span>Pay 400</span>
                        <Image src="/stars.svg" alt="Stars" width={20} height={20} />
                      </>
                    )}
                  </Button>
                </motion.div>
              </div>
            </div>

            {!isFreePlanActive && (
              <div className={cn(
                "dark-bg border border-[#45aef5] rounded-2xl p-4",
                isFreePlanActive && "opacity-50 pointer-events-none" 
              )}>
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-white font-bold">Free Plan</h3>
                  <Badge variant="secondary" className="bg-[#45aef5] text-white">
                    Free
                  </Badge>
                </div>
                <ul className="text-[#a0a0a0] text-sm space-y-1 mb-4">
                  <li className="flex items-center gap-2">
                    <FaBolt className="text-[#45aef5]" /> 5,000 {SIMPLE} per session
                  </li>
                  <li className="flex items-center gap-2">
                    <FaClock className="text-[#45aef5]" /> Every 12 hours
                  </li>
                  <li className="flex items-center gap-2">
                    <FaInfoCircle className="text-[#45aef5]" /> Permanent access
                  </li>
                </ul>
                <motion.div whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => handleSubscribe("free")}
                    disabled={isProcessing && processingMethod !== null}
                    className="w-full bg-[#45aef5] hover:bg-[#3a9de0] text-white font-semibold rounded-xl h-12"
                  >
                    {isProcessing && processingMethod === null ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Activating...</span>
                      </div>
                    ) : (
                      "Start Free Plan"
                    )}
                  </Button>
                </motion.div>
              </div>
            )}
          </div>
        </DialogBody>

        <DialogFooter className="px-6 pb-6 shrink-0">
          <motion.div whileTap={{ scale: 0.98 }} className="w-full">
            <Button
              onClick={() => onOpenChange(false)}
              variant="outline"
              className="w-full border-[#1A1A1A] text-[#a0a0a0] hover:bg-[#1a1a1a] rounded-xl h-10"
            >
              Cancel
            </Button>
          </motion.div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { motion } from "framer-motion"
import { FaTicketAlt, FaShoppingCart } from "react-icons/fa"
import { TICKET_PACKAGES } from "@/lib/data"
import Image from "next/image"

interface TicketPackagesProps {
  onPackageSelect: (pkg: any) => void
  userTickets?: number
}

export function TicketPackages({ onPackageSelect, userTickets = 0 }: TicketPackagesProps) {
  return (
    <div className="space-y-4">
      <div className="dark-bg rounded-xl p-4 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FaTicketAlt className="w-4 h-4 text-tp" />
            <span className="text-sm text-[#a0a0a0]">Your Tickets</span>
          </div>
          <div className="text-lg font-bold">
            {userTickets} Tickets
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {TICKET_PACKAGES.map((pkg) => (
          <motion.div
            key={pkg.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="cursor-pointer"
            onClick={() => onPackageSelect(pkg)}
          >
            <div className="dark-bg rounded-2xl overflow-hidden hover:border-[#ff6b35]/50 transition-all">
              <div className="p-4">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-2">
                    <FaTicketAlt className="w-4 h-4 text-tp" />
                    <h3 className="text-white font-bold text-sm">{pkg.title}</h3>
                  </div>
                </div>

                <div className="text-center mb-3">
                  <div className="flex items-center justify-center gap-1">
                    <span className="text-xl font-bold fire-text">{pkg.tickets}</span>
                    <span className="text-[#a0a0a0] text-sm">tickets</span>
                  </div>
                  {pkg.bonus && (
                    <div className="text-green-400 text-xs mt-1">
                      +{pkg.bonus} bonus
                    </div>
                  )}
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-[#a0a0a0]">TON</span>
                    <div className="flex items-center">
                      <span className="font-medium">{pkg.tonPrice}</span>
                      <Image 
                        src="/toncoin.svg" 
                        alt="TON" 
                        width={12} 
                        height={12} 
                        className="ml-1"
                      />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#a0a0a0]">Stars</span>
                    <div className="flex items-center">
                      <span className="font-medium">{pkg.starsPrice}</span>
                      <Image 
                        src="/stars.svg" 
                        alt="Stars" 
                        width={12} 
                        height={12} 
                        className="ml-1"
                      />
                    </div>
                  </div>
                </div>

                <Button className="w-full mt-3 fire-gradient rounded-xl text-xs h-8">
                  <FaShoppingCart className="w-4 h-4 mr-2 text-white" />
                  Buy Now
                </Button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { FaCrown, FaCopy, FaTicketAlt, FaUsers, FaTasks, FaCoins } from "react-icons/fa"
import Image from "next/image"
import { motion } from "framer-motion"
import { useToast } from "@/components/ui/use-toast"
import { formatBalance, format } from "@/lib/utils"

interface UserInfoDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  user: any
  userPhoto: string
  userName: string
}

export function UserInfoDialog({ open, onOpenChange, user, userPhoto, userName }: UserInfoDialogProps) {
  const { toast } = useToast()
  const [isCopying, setIsCopying] = useState(false)

  const copyUserId = async () => {
    if (!user?.telegram_id) return

    setIsCopying(true)
    try {
      await navigator.clipboard.writeText(user.telegram_id)
      toast({
        title: "Copied!",
        description: "ID copied successfully",
      })
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Error occurred while copying ID",
        variant: "destructive",
      })
    } finally {
      setTimeout(() => setIsCopying(false), 1000)
    }
  }

  const isPremiumUser = user?.premium || false
  const balance = user?.balance || 0
  const ticketsBalance = user?.tickets_balance || 0
  const referralsCount = user?.referrals?.length || 0
  const completedTasksCount = user?.completed_tasks?.filter((task: any) => task.completed)?.length || 0

  const statsItems = [
    {
      icon: FaCoins,
      value: formatBalance(balance),
      isCurrency: true,
      bgColor: "bg-[#ff6b35]/10",
      borderColor: "border-[#ff6b35]/20",
      iconColor: "text-[#ff6b35]"
    },
    {
      icon: FaTicketAlt,
      value: ticketsBalance,
      isCurrency: false,
      bgColor: "bg-blue-500/10",
      borderColor: "border-blue-500/20",
      iconColor: "text-blue-500"
    },
    {
      icon: FaUsers,
      value: referralsCount,
      isCurrency: false,
      bgColor: "bg-green-500/10",
      borderColor: "border-green-500/20",
      iconColor: "text-green-500"
    },
    {
      icon: FaTasks,
      value: completedTasksCount,
      isCurrency: false,
      bgColor: "bg-purple-500/10",
      borderColor: "border-purple-500/20",
      iconColor: "text-purple-500"
    }
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95%] max-w-md mx-auto max-h-[70vh] gradient-dark rounded-3xl">
        <DialogHeader className="text-center">
          <DialogTitle className="fire-text text-xl font-bold">Your Information</DialogTitle>
          <DialogDescription className="text-[#a0a0a0] text-sm">Your account details</DialogDescription>
        </DialogHeader>

        <DialogBody className="space-y-4 px-6 py-4 overflow-y-auto">
          <div className="flex items-center gap-4 mb-4">
            <div className="relative">
              {userPhoto ? (
                <Image
                  src={userPhoto || "/placeholder.svg"}
                  alt={userName}
                  width={70}
                  height={70}
                  className={`rounded-2xl border-2 ${isPremiumUser ? "tp-border" : "border-[#1A1A1A]"}`}
                />
              ) : (
                <div
                  className={`w-[65px] h-[65px] rounded-2xl border ${isPremiumUser ? "tp-border" : "border-[#1A1A1A]"} dark-bg flex items-center justify-center`}
                >
                  <span className="text-white text-xl font-bold">{userName.charAt(0).toUpperCase()}</span>
                </div>
              )}
              {isPremiumUser && (
                <div className="absolute -top-2 -right-2 bg-[#ff6b35] rounded-full p-1">
                  <FaCrown className="w-3 h-3 text-white" />
                </div>
              )}
            </div>
            
            <div className="flex-1 bg-overlay rounded-xl p-2">
              <div className="text-white font-semibold text-sm mb-1 truncate">{userName}</div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <span className="text-[#a0a0a0] text-xs">ID:</span>
                  <span className="text-white text-xs">{user?.telegram_id}</span>
                </div>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={copyUserId}
                  disabled={isCopying}
                  className="p-1 rounded-lg dark-bg hover:bg-[#2a2a2a] transition-colors border border-[#1A1A1A]"
                >
                  <FaCopy className={`w-3 h-3 ${isCopying ? "text-[#ff6b35]" : "text-[#a0a0a0]"}`} />
                </motion.button>
              </div>
              <div className="flex items-center gap-1 mt-1">
                <span className="text-[#a0a0a0] text-xs">Balance:</span>
                <span className="text-white font-bold text-sm">{format(balance)}</span>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            {statsItems.map((item, index) => (
              <div key={index} className="dark-bg rounded-xl p-3">
                <div className="flex flex-col items-center gap-2">
                  <div className={`${item.bgColor} p-2 rounded-lg border ${item.borderColor}`}>
                    <item.icon className={`w-4 h-4 ${item.iconColor}`} />
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-white font-bold text-sm">{item.value}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="dark-bg rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div
                  className={`p-2 rounded-lg border ${isPremiumUser ? "bg-[#ff6b35]/10 border-[#ff6b35]/20" : "bg-gray-500/10 border-gray-500/20"}`}
                >
                  <FaCrown className={`w-4 h-4 ${isPremiumUser ? "text-[#ff6b35]" : "text-gray-500"}`} />
                </div>
                <span className="text-[#a0a0a0] text-sm">Status</span>
              </div>
              <Badge
                variant={isPremiumUser ? "default" : "secondary"}
                className={isPremiumUser ? "bg-[#ff6b35] text-white" : "bg-gray-600 text-white"}
              >
                {isPremiumUser ? "Premium" : "Regular"}
              </Badge>
            </div>
          </div>
        </DialogBody>

        <DialogFooter className="px-6 pb-6">
          <motion.div whileTap={{ scale: 0.98 }} className="w-full">
            <Button
              onClick={() => onOpenChange(false)}
              variant="outline"
              className="w-full border-[#1A1A1A] text-[#a0a0a0] hover:dark-bg rounded-xl h-10 dark-bg"
            >
              Close
            </Button>
          </motion.div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

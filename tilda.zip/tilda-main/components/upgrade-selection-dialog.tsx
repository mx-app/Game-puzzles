import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogBody, DialogFooter } from "@/components/ui/dialog"
import { FaBolt, FaClock } from "react-icons/fa"
import { motion } from "framer-motion"
import { SIMPLE, NAME } from "@/lib/config"

export function UpgradeSelectionDialog({
  open,
  onOpenChange,
  onUpgradeSelect,
  upgrades,
  miningRate,
  miningDuration
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  onUpgradeSelect: (type: "rate" | "time") => void
  upgrades: any
  miningRate: number
  miningDuration: number
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95%] max-w-md mx-auto gradient-dark rounded-3xl">
        <DialogHeader className="text-center">
          <DialogTitle className="fire-text text-xl font-bold">Mining Upgrades</DialogTitle>
          <DialogDescription className="text-[#a0a0a0] text-sm">
            Choose an upgrade to improve your mining
          </DialogDescription>
        </DialogHeader>

        <DialogBody className="space-y-4 px-6 py-4">
          <motion.div whileTap={{ scale: 0.98 }}>
            <Button
              onClick={() => onUpgradeSelect("rate")}
              className="w-full bg-[#0f0f0f] hover:bg-[#1a1a1a] border border-[#1A1A1A] rounded-xl p-4 h-auto flex flex-col items-start gap-2"
            >
              <div className="flex items-center gap-3 w-full">
                <div className="w-10 h-10 bg-[#ff6b35]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <FaBolt className="w-5 h-5 text-[#ff6b35]" />
                </div>
                <div className="text-left">
                  <div className="text-white font-semibold">Rate Boost</div>
                  <div className="text-[#a0a0a0] text-xs">
                    Increase tokens per mining session
                  </div>
                </div>
              </div>
              <div className="w-full mt-2">
                <Badge className="bg-[#ff6b35]/10 text-[#ff6b35] border-[#ff6b35]/20 text-xs">
                  Level {upgrades.rateBoost || 0}/5 • Current: {miningRate} {SIMPLE}
                </Badge>
              </div>
            </Button>
          </motion.div>

          <motion.div whileTap={{ scale: 0.98 }}>
            <Button
              onClick={() => onUpgradeSelect("time")}
              className="w-full bg-[#0f0f0f] hover:bg-[#1a1a1a] border border-[#1A1A1A] rounded-xl p-4 h-auto flex flex-col items-start gap-2"
            >
              <div className="flex items-center gap-3 w-full">
                <div className="w-10 h-10 bg-green-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <FaClock className="w-5 h-5 text-green-400" />
                </div>
                <div className="text-left">
                  <div className="text-white font-semibold">Time Reduction</div>
                  <div className="text-[#a0a0a0] text-xs">
                    Reduce time between mining session
                  </div>
                </div>
              </div>
              <div className="w-full mt-2">
                <Badge className="bg-green-500/10 text-green-400 border-green-500/20 text-xs">
                  Level {upgrades.timeReduction || 0}/5 • Current: {miningDuration}h
                </Badge>
              </div>
            </Button>
          </motion.div>
        </DialogBody>

        <DialogFooter className="px-6 pb-6">
          <motion.div whileTap={{ scale: 0.98 }} className="w-full">
            <Button
              onClick={() => onOpenChange(false)}
              variant="outline"
              className="w-full border-[#1A1A1A] text-[#a0a0a0] hover:bg-[#1a1a1a] rounded-xl h-10"
            >
              Close
            </Button>
          </motion.div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

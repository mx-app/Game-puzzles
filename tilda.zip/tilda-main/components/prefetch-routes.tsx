"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"

export function PrefetchRoutes() {
  const router = useRouter()

  useEffect(() => {
    router.prefetch("/")
    router.prefetch("/tasks")
    router.prefetch("/referrals")
    router.prefetch("/premium")
    router.prefetch("/market")
    router.prefetch("/leaders")
    router.prefetch("/games")
    router.prefetch("/drop")
  }, [router])

  return null
}

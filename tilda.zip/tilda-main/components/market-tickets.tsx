"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "@/components/ui/dialog"
import { motion } from "framer-motion"
import Image from "next/image"
import { createInvoiceLink, openTelegramInvoice } from "@/lib/payment-service"
import { useToast } from "@/components/ui/use-toast"
import { useTonAddress, useTonConnectUI } from "@tonconnect/ui-react"
import { WALLET_ADDRESS } from "@/lib/wallet-config"
import { walletService } from "@/lib/wallet-service"
import { TICKET_PACKAGES } from "@/lib/data"
import { FaTicketAlt } from "react-icons/fa"

interface TicketPurchaseDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onPurchaseSuccess: (newTickets: number) => void
  selectedPackage?: any
}

export function TicketPurchaseDialog({ 
  open, 
  onOpenChange, 
  onPurchaseSuccess, 
  selectedPackage 
}: TicketPurchaseDialogProps) {
  const { toast } = useToast()
  const [tonConnectUI] = useTonConnectUI()
  const userAddress = useTonAddress()
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingMethod, setProcessingMethod] = useState<"TON" | "STARS" | null>(null)
  const [walletBalance, setWalletBalance] = useState<string>("0")
  const [internalSelectedPackage, setInternalSelectedPackage] = useState<any>(selectedPackage || TICKET_PACKAGES[3])

  useEffect(() => {
    if (selectedPackage) {
      setInternalSelectedPackage(selectedPackage)
    }
  }, [selectedPackage])

  useEffect(() => {
    const fetchWalletBalance = async () => {
      if (!userAddress) {
        setWalletBalance("0")
        return
      }

      try {
        const balanceData = await walletService.checkTonWalletBalance(userAddress)
        
        if (balanceData.success) {
          setWalletBalance(balanceData.balance)
        } else {
          console.error("Failed to fetch wallet balance:", balanceData.error)
          setWalletBalance("0")
        }
      } catch (error) {
        console.error("Error fetching wallet balance:", error)
        setWalletBalance("0")
      }
    }

    fetchWalletBalance()
  }, [userAddress])

  const handleBuyTickets = async (paymentMethod: "TON" | "STARS") => {
    if (!internalSelectedPackage) return
    
    setIsProcessing(true)
    setProcessingMethod(paymentMethod)
    
    try {
      const totalTickets = internalSelectedPackage.tickets + (internalSelectedPackage.bonus || 0)

      if (paymentMethod === "TON") {
        if (!userAddress) {
          onOpenChange(false)
          await tonConnectUI.openModal()
          return
        }

        const balanceCheck = await walletService.hasEnoughBalance(
          userAddress,
          internalSelectedPackage.tonPrice
        )

        if (!balanceCheck.sufficient) {
          throw new Error(
            `Insufficient balance in your wallet. You need ${internalSelectedPackage.tonPrice} TON but you have ${balanceCheck.currentBalance.toFixed(2)} TON`
          )
        }

        const tonAmount = BigInt(Math.floor(internalSelectedPackage.tonPrice * 1000000000))

        const result = await tonConnectUI.sendTransaction({
          validUntil: Math.floor(Date.now() / 1000) + 600,
          messages: [
            {
              address: WALLET_ADDRESS,
              amount: tonAmount.toString(),
            },
          ],
        })

        if (!result?.boc) {
          throw new Error("Transaction failed")
        }
      } else {
        const invoiceLink = await createInvoiceLink(
          internalSelectedPackage.starsPrice,
          `Tickets - ${internalSelectedPackage.title}`,
          `Buy ${totalTickets} tickets`,
        )

        const status = await openTelegramInvoice(invoiceLink)
        if (status !== "paid") {
          throw new Error("Payment not completed")
        }
      }
      
      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "add_tickets",
          initData: window.Telegram.WebApp.initData,
          ticketsAmount: totalTickets,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to update tickets in database")
      }

      onPurchaseSuccess(totalTickets)
      
      toast({
        title: "Purchase successful!",
        description: `Added ${totalTickets} tickets to your balance.`,
      })
      setInternalSelectedPackage(null)
      onOpenChange(false)
    } catch (error) {
      console.error("Purchase error:", error)
      toast({
        title: "Purchase failed",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
      setProcessingMethod(null)
    }
  }

  return (
    <Dialog open={open} onOpenChange={(open) => {
      onOpenChange(open)
      if (!open) {
        setInternalSelectedPackage(selectedPackage || TICKET_PACKAGES[3])
      }
    }}>
      <DialogContent className="w-[95%] max-w-md mx-auto gradient-dark rounded-3xl">
        <DialogHeader className="text-center">
          <DialogTitle className="fire-text text-xl font-bold">Buy Tickets</DialogTitle>
          <DialogDescription className="text-[#a0a0a0] text-sm">
            Choose your preferred payment method
          </DialogDescription>
        </DialogHeader>

        <DialogBody className="space-y-4 px-6 py-4">
          {internalSelectedPackage && (
            <>
              <div className="dark-bg rounded-xl p-4 text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <FaTicketAlt className="w-6 h-6 text-tp" />
                  <span className="text-md font-bold fire-text">
                    {internalSelectedPackage.tickets}
                    {internalSelectedPackage.bonus > 0 && ` + ${internalSelectedPackage.bonus}`} tickets
                  </span>
                </div>
                <div className="text-sm text-[#a0a0a0]">
                  {internalSelectedPackage.title}
                </div>
              </div>

              {userAddress && (
                <div className="text-center text-sm text-[#a0a0a0]">
                  Wallet Balance: <span className="text-white">{Number(walletBalance).toFixed(2)} TON</span>
                </div>
              )}

              <motion.div whileTap={{ scale: 0.98 }}>
                <Button
                  onClick={() => handleBuyTickets("TON")}
                  disabled={isProcessing || (userAddress && Number(walletBalance) < internalSelectedPackage.tonPrice)}
                  className="w-full fire-gradient text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                >
                  {processingMethod === "TON" ? (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    </div>
                  ) : (
                    <>
                      <Image src="/toncoin.svg" alt="TON" width={20} height={20} />
                      <span>
                        {!userAddress
                          ? "Connect Wallet"
                          : Number(walletBalance) < internalSelectedPackage.tonPrice
                            ? `Need ${(internalSelectedPackage.tonPrice - Number(walletBalance)).toFixed(2)} TON more`
                            : `Pay ${internalSelectedPackage.tonPrice} TON`}
                      </span>
                    </>
                  )}
                </Button>
              </motion.div>

              <motion.div whileTap={{ scale: 0.98 }}>
                <Button
                  onClick={() => handleBuyTickets("STARS")}
                  disabled={isProcessing} 
                  className="w-full fire-gradient text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                >
                  {processingMethod === "STARS" ? (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    </div>
                  ) : (
                    <>
                      <Image src="/stars.svg" alt="Stars" width={20} height={20} />
                      <span>
                        Pay {internalSelectedPackage.starsPrice} Stars
                      </span>
                    </>
                  )}
                </Button>
              </motion.div>
            </>
          )}
        </DialogBody>

        <DialogFooter className="px-6 pb-6">
          <motion.div whileTap={{ scale: 0.98 }} className="w-full">
            <Button
              onClick={() => onOpenChange(false)}
              variant="outline"
              className="w-full border-[#1A1A1A] text-[#a0a0a0] hover:bg-[#1a1a1a] rounded-xl h-10"
            >
              Cancel
            </Button>
          </motion.div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

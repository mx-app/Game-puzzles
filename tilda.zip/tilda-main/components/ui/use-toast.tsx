import { useToast as useToastOriginal } from "@/hooks/use-toast"
import { ToastAction } from "@/components/ui/toast"
import { toast } from "@/hooks/use-toast"

export { ToastAction }
export { toast }

export const useToast = useToastOriginal

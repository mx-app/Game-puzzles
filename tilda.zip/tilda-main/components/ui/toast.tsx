"use client"

import * as React from "react"
import * as ToastPrimitives from "@radix-ui/react-toast"
import { cva, type VariantProps } from "class-variance-authority"
import { X, CheckCircle2, AlertCircle, Info, AlertTriangle } from "lucide-react"

import { cn } from "@/lib/utils"

const ToastProvider = ToastPrimitives.Provider

const ToastViewport = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Viewport>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Viewport>
>(({ className, ...props }, ref) => (
  <ToastPrimitives.Viewport
    ref={ref}
    className={cn(
      "fixed top-[6px] left-1/2 transform -translate-x-1/2 z-[100] flex max-h-screen w-[90%] flex-col-reverse p-0 sm:bottom-auto sm:right-0 sm:top-0 sm:flex-col md:max-w-[420px]",
      className,
    )}
    {...props}
  />
))
ToastViewport.displayName = ToastPrimitives.Viewport.displayName

const toastVariants = cva(
  "group pointer-events-auto relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-2xl border p-4 pr-6 transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-top-full backdrop-blur-xl",
  {
    variants: {
      variant: {
        default: "border-[#0f0f0f] dark-bg text-white",
        success: "border-[#0f0f0f] dark-bg text-[#45aef5]",
        destructive: "border-[#0f0f0f] dark-bg text-red-400",
        info: "border-blue-500/30 dark-bg text-blue-400",
        warning: "border-yellow-500/30 dark-bg text-yellow-400",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
)

const Toast = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Root>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Root> & VariantProps<typeof toastVariants>
>(({ className, variant, ...props }, ref) => {
  return <ToastPrimitives.Root ref={ref} className={cn(toastVariants({ variant }), className)} {...props} />
})
Toast.displayName = ToastPrimitives.Root.displayName

const ToastAction = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Action>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Action>
>(({ className, ...props }, ref) => (
  <ToastPrimitives.Action
    ref={ref}
    className={cn(
      "inline-flex h-7 shrink-0 items-center justify-center rounded-2xl border bg-transparent px-3 text-xs font-medium ring-offset-background transition-colors hover:bg-[#1a1a1a] focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-red-500/40 group-[.destructive]:hover:border-red-500/60 group-[.destructive]:hover:bg-red-500/10 group-[.destructive]:hover:text-red-300 group-[.destructive]:focus:ring-red-500 group-[.success]:border-green-500/40 group-[.success]:hover:border-green-500/60 group-[.success]:hover:bg-green-500/10 group-[.success]:hover:text-green-300 group-[.success]:focus:ring-green-500 group-[.info]:border-blue-500/40 group-[.info]:hover:border-blue-500/60 group-[.info]:hover:bg-blue-500/10 group-[.info]:hover:text-blue-300 group-[.info]:focus:ring-blue-500 group-[.warning]:border-yellow-500/40 group-[.warning]:hover:border-yellow-500/60 group-[.warning]:hover:bg-yellow-500/10 group-[.warning]:hover:text-yellow-300 group-[.warning]:focus:ring-yellow-500",
      className,
    )}
    {...props}
  />
))
ToastAction.displayName = ToastPrimitives.Action.displayName

const ToastClose = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Close>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Close>
>(({ className, ...props }, ref) => (
  <ToastPrimitives.Close
    ref={ref}
    className={cn(
      "absolute right-1 top-1 rounded-2xl p-1 text-foreground/50 opacity-0 transition-opacity hover:text-foreground focus:opacity-100 focus:outline-none focus:ring-0 group-hover:opacity-100 group-[.destructive]:text-red-300 group-[.destructive]:hover:text-red-100 group-[.success]:text-green-300 group-[.success]:hover:text-green-100 group-[.info]:text-blue-300 group-[.info]:hover:text-blue-100 group-[.warning]:text-yellow-300 group-[.warning]:hover:text-yellow-100",
      className,
    )}
    toast-close=""
    {...props}
  >
    <X className="h-3 w-3" />
  </ToastPrimitives.Close>
))
ToastClose.displayName = ToastPrimitives.Close.displayName

const ToastIcon = ({ variant }: { variant?: "default" | "success" | "destructive" | "info" | "warning" }) => {
  switch (variant) {
    case "success":
      return <CheckCircle2 className="h-4 w-4 text-tp" />
    case "destructive":
      return <AlertCircle className="h-4 w-4 text-red-400" />
    case "info":
      return <Info className="h-4 w-4 text-blue-400" />
    case "warning":
      return <AlertTriangle className="h-4 w-4 text-yellow-400" />
    default:
      return <Info className="h-4 w-4 text-white" />
  }
}

const ToastTitle = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Title>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Title> & {
    variant?: "default" | "success" | "destructive" | "info" | "warning"
  }
>(({ className, variant, ...props }, ref) => (
  <div className="flex items-start gap-2">
    <ToastIcon variant={variant} />
    <ToastPrimitives.Title ref={ref} className={cn("text-xs font-semibold flex-1", className)} {...props} />
  </div>
))
ToastTitle.displayName = ToastPrimitives.Title.displayName

const ToastDescription = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Description>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Description>
>(({ className, ...props }, ref) => (
  <ToastPrimitives.Description ref={ref} className={cn("text-xs opacity-90 pl-6", className)} {...props} />
))
ToastDescription.displayName = ToastPrimitives.Description.displayName

type ToastProps = React.ComponentPropsWithoutRef<typeof Toast>

type ToastActionElement = React.ReactElement<typeof ToastAction>

export {
  type ToastProps,
  type ToastActionElement,
  ToastProvider,
  ToastViewport,
  Toast,
  ToastTitle,
  ToastDescription,
  ToastClose,
  ToastAction,
  }

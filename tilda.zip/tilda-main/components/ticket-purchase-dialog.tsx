"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "@/components/ui/dialog"
import { motion } from "framer-motion"
import Image from "next/image"
import { createInvoiceLink, openTelegramInvoice } from "@/lib/payment-service"
import { useToast } from "@/components/ui/use-toast"
import { useTonAddress, useTonConnectUI } from "@tonconnect/ui-react"
import { WALLET_ADDRESS } from "@/lib/wallet-config"
import { walletService } from "@/lib/wallet-service"
import { TICKET_PACKAGES4 } from "@/lib/data"

interface TicketPurchaseDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onPurchaseSuccess: (newTickets: number) => void
}

export function TicketPurchaseDialog({ open, onOpenChange, onPurchaseSuccess }: TicketPurchaseDialogProps) {
  const { toast } = useToast()
  const [tonConnectUI] = useTonConnectUI()
  const userAddress = useTonAddress()
  const [selectedPackage, setSelectedPackage] = useState<any>(TICKET_PACKAGES4[3])
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingMethod, setProcessingMethod] = useState<"wallet" | "stars" | null>(null)
  const [walletBalance, setWalletBalance] = useState<string>("0")

  useEffect(() => {
    const fetchWalletBalance = async () => {
      if (!userAddress) {
        setWalletBalance("0")
        return
      }

      try {
        const balanceData = await walletService.checkTonWalletBalance(userAddress)
        
        if (balanceData.success) {
          setWalletBalance(balanceData.balance)
        } else {
          console.error("Failed to fetch wallet balance:", balanceData.error)
          setWalletBalance("0")
        }
      } catch (error) {
        console.error("Error fetching wallet balance:", error)
        setWalletBalance("0")
      }
    }

    fetchWalletBalance()
  }, [userAddress])

  const handleBuyTickets = async (packageData: any, paymentMethod: "wallet" | "stars") => {
    setIsProcessing(true)
    setProcessingMethod(paymentMethod)
    
    try {
      const totalTickets = packageData.tickets + (packageData.bonus || 0)

      if (paymentMethod === "wallet") {
        if (!userAddress) {
          onOpenChange(false)
          await tonConnectUI.openModal()
          return
        }

        const balanceCheck = await walletService.hasEnoughBalance(
          userAddress,
          packageData.tonPrice
        )

        if (!balanceCheck.sufficient) {
          throw new Error(
            `Insufficient balance in your wallet. You need ${packageData.tonPrice} TON but you have ${balanceCheck.currentBalance.toFixed(2)} TON`
          )
        }

        const tonAmount = BigInt(Math.floor(packageData.tonPrice * 1000000000))

        const result = await tonConnectUI.sendTransaction({
          validUntil: Math.floor(Date.now() / 1000) + 600,
          messages: [
            {
              address: WALLET_ADDRESS,
              amount: tonAmount.toString(),
            },
          ],
        })

        if (!result?.boc) {
          throw new Error("Transaction failed")
        }
      } else {
        const invoiceLink = await createInvoiceLink(
          packageData.starsPrice,
          `Tickets - ${packageData.title}`,
          `Buy ${totalTickets} tickets`,
        )

        const status = await openTelegramInvoice(invoiceLink)
        if (status !== "paid") {
          throw new Error("Payment not completed")
        }
      }
      
      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "add_tickets",
          initData: window.Telegram.WebApp.initData,
          ticketsAmount: totalTickets,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to update tickets in database")
      }

      onPurchaseSuccess(totalTickets)
      
      toast({
        title: "Purchase successfully",
        description: `Added ${totalTickets} to your balance.`,
      })
      setSelectedPackage(null)
      onOpenChange(false)
    } catch (error) {
      console.error("Purchase error:", error)
      toast({
        title: "Purchase failed",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
      setProcessingMethod(null)
    }
  }

  return (
    <Dialog open={open} onOpenChange={(open) => {
      onOpenChange(open)
      if (!open) {
        setSelectedPackage(null)
      }
    }}>
      <DialogContent className="w-[95%] max-w-md mx-auto gradient-dark rounded-3xl">
        <DialogHeader className="text-center">
          <DialogTitle className="fire-text text-xl font-bold">Buy Tickets</DialogTitle>
          <DialogDescription className="text-[#a0a0a0] text-sm">
            Choose a ticket package to continue playing
          </DialogDescription>
        </DialogHeader>

        <DialogBody className="space-y-3 px-4 py-4 max-h-96 overflow-y-auto">
          <div className="grid grid-cols-2 gap-3">
            {TICKET_PACKAGES4.map((pkg) => (
              <motion.div
                key={pkg.id}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedPackage(pkg)}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  selectedPackage?.id === pkg.id
                    ? "border-[#ff6b35] bg-[#ff6b35]/10"
                    : "border-[#1A1A1A] bg-[#0f0f0f] hover:bg-[#1a1a1a]"
                }`}
              >
                <div className="flex flex-col h-full">
                  <div className="flex-grow">
                    <h3 className="font-semibold text-white text-sm">{pkg.title}</h3>
                    <div className="flex items-center gap-1 mt-1 text-xs text-[#a0a0a0]">
                      <span>{pkg.tickets} tickets</span>
                      {pkg.bonus && pkg.bonus > 0 && (
                        <Badge className="bg-green-500/20 text-green-400 text-[10px] px-1">+{pkg.bonus}</Badge>
                      )}
                    </div>
                  </div>
                  <div className="mt-2">
                    <div className="text-xs text-[#a0a0a0]">{pkg.tonPrice} TON</div>
                    <div className="text-xs text-[#a0a0a0]">{pkg.starsPrice} Stars</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {selectedPackage && (
            <div className="space-y-2 pt-4 border-t border-[#1A1A1A]">
              {userAddress && (
                <div className="text-sm text-[#a0a0a0] mb-2 text-center">
                  Wallet Balance: <span className="text-white">{Number(walletBalance).toFixed(2)} TON</span>
                </div>
              )}
              
              <motion.div whileTap={{ scale: 0.98 }}>
                <Button
                  onClick={() => handleBuyTickets(selectedPackage, "wallet")}
                  disabled={isProcessing}
                  className="w-full fire-gradient hover:bg-[#3a9de0] text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                >
                  {isProcessing && processingMethod === "wallet" ? (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    </div>
                  ) : (
                    <>
                      <Image src="/toncoin.svg" alt="TON" width={20} height={20} />
                      <span>Pay {selectedPackage.tonPrice} TON</span>
                    </>
                  )}
                </Button>
              </motion.div>

              <motion.div whileTap={{ scale: 0.98 }}>
                <Button
                  onClick={() => handleBuyTickets(selectedPackage, "stars")}
                  disabled={isProcessing}
                  className="w-full fire-gradient hover:from-yellow-500 hover:to-yellow-700 text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                >
                  {isProcessing && processingMethod === "stars" ? (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    </div>
                  ) : (
                    <>
                      <Image src="/stars.svg" alt="Stars" width={20} height={20} />
                      <span>Pay {selectedPackage.starsPrice} Stars</span>
                    </>
                  )}
                </Button>
              </motion.div>
            </div>
          )}
        </DialogBody>

        <DialogFooter className="px-6 pb-6">
          <Button
            onClick={() => {
              onOpenChange(false)
              setSelectedPackage(null)
            }}
            variant="outline"
            className="w-full border-[#1A1A1A] text-[#a0a0a0] hover:bg-[#1a1a1a] rounded-xl h-10"
          >
            Cancel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

"use client"

import { useEffect, useState } from "react"

interface LoadingProps {
  progress?: number
}

export function Loading({ progress }: LoadingProps) {
  const [animationProgress, setAnimationProgress] = useState(0)
  const [visible, setVisible] = useState(true)

  useEffect(() => {
    const interval = setInterval(() => {
      setAnimationProgress((prev) => (prev >= 100 ? 0 : prev + 1))
    }, 30)

    const timeout = setTimeout(() => {
      setVisible(false)
    }, 3000)

    return () => {
      clearInterval(interval)
      clearTimeout(timeout)
    }
  }, [])

  if (!visible) return null

  const displayProgress = progress !== undefined ? progress : animationProgress
  const radius = 40
  const strokeWidth = 6
  const circumference = 2 * Math.PI * radius
  const offset = circumference * (1 - displayProgress / 100)

  return (
    <div className="fixed inset-0 bg-[#000]/70 flex items-center justify-center z-50">
      <div className="relative w-24 h-24">
        <svg
          width="100"
          height="100"
          viewBox="0 0 100 100"
          className="absolute top-0 left-0"
        >
          <circle
            cx="50"
            cy="50"
            r={radius}
            stroke="#1A1A1A"
            strokeWidth={strokeWidth + 2}
            fill="none"
          />
          <circle
            cx="50"
            cy="50"
            r={radius}
            stroke="#ff6b35"
            strokeWidth={strokeWidth}
            fill="none"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            style={{
              transition: "stroke-dashoffset 0.2s ease",
              transformOrigin: "50% 50%",
              transform: "rotate(-90deg)",
            }}
          />
        </svg>
      </div>
    </div>
  )
}

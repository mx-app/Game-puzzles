"use client"

import { useTelegramInit } from "@/lib/telegram-init"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import { useEffect, useState, Suspense } from "react"
import { useRouter } from "next/navigation"
import BannedScreen from "@/components/banned-screen"
import { LoadingScreen } from "@/components/loading-screen"

export default function ClientContent({ children }: { children: React.ReactNode }) {
  useTelegramInit()
  const [isBanned, setIsBanned] = useState<boolean | null>(null)

  useEffect(() => {
    const checkBanStatus = async () => {
      try {
        if (typeof window !== "undefined" && window.Telegram?.WebApp?.initData) {
          const response = await fetch("/api/user", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              action: "check_ban_status",
              initData: window.Telegram.WebApp.initData,
            }),
          })

          if (response.ok) {
            const data = await response.json()
            setIsBanned(data.isBanned)
          } else {
            setIsBanned(false)
          }
        } else {
          setIsBanned(false)
        }
      } catch (error) {
        console.error("Ban check error:", error)
        setIsBanned(false)
      }
    }

    checkBanStatus()
  }, [])

  if (isBanned === null) {
    return <LoadingScreen /> 
  }

  if (isBanned) {
    return <BannedScreen />
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
      <Suspense fallback={<LoadingScreen />}>
        {children}
      </Suspense>
      <Toaster />
    </ThemeProvider>
  )
}

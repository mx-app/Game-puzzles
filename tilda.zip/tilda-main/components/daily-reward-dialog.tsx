"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogBody, DialogFooter } from "@/components/ui/dialog"
import { FaCalendarDay, FaCoins } from "react-icons/fa"
import Image from "next/image"
import { motion } from "framer-motion"
import { useToast } from "@/components/ui/use-toast"
import { createInvoiceLink, openTelegramInvoice } from "@/lib/payment-service"
import { useTonAddress, useTonConnectUI } from "@tonconnect/ui-react"
import { WalletDialog } from "@/components/wallet-dialog"
import { walletService } from "@/lib/wallet-service"
import { WALLET_ADDRESS } from "@/lib/wallet-config"
import { SIMPLE, NAME } from "@/lib/config"

interface DailyRewardDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onClaim: (double: boolean) => Promise<void>
  lastClaimedDate?: string | null
}

export function DailyRewardDialog({ 
  open, 
  onOpenChange,
  onClaim,
  lastClaimedDate,
}: DailyRewardDialogProps) {
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingMethod, setProcessingMethod] = useState<"claim" | "ton" | "stars" | null>(null)
  const [walletDialogOpen, setWalletDialogOpen] = useState(false)
  const [walletBalance, setWalletBalance] = useState<string>("0")
  const { toast } = useToast()
  const [tonConnectUI] = useTonConnectUI()
  const userAddress = useTonAddress()
  
  useEffect(() => {
    const fetchWalletBalance = async () => {
      if (!userAddress) {
        setWalletBalance("0")
        return
      }

      try {
        const balanceData = await walletService.checkTonWalletBalance(userAddress)
        
        if (balanceData.success) {
          setWalletBalance(balanceData.balance)
        } else {
          console.error("Failed to fetch wallet balance:", balanceData.error)
          setWalletBalance("0")
        }
      } catch (error) {
        console.error("Error fetching wallet balance:", error)
        setWalletBalance("0")
      }
    }

    fetchWalletBalance()
  }, [userAddress])
  

  const parseDatabaseDate = (dateStr: string): Date | null => {
   if (!dateStr) return null;
   if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    const [year, month, day] = dateStr.split("-").map(Number);
    return new Date(Date.UTC(year, month - 1, day));
  }
    const parsed = new Date(dateStr);
    return isNaN(parsed.getTime()) ? null : parsed;
  };

  const isSameDay = (date1: Date | null, date2: Date | null): boolean => {
    if (!date1 || !date2) return false;

    return (
      date1.getUTCFullYear() === date2.getUTCFullYear() &&
      date1.getUTCMonth() === date2.getUTCMonth() &&
      date1.getUTCDate() === date2.getUTCDate()
    );
  };

  const formatDate = (dateString?: string | null) => {
   if (!dateString) return "Never claimed";

    const date = parseDatabaseDate(dateString);
    if (!date || isNaN(date.getTime())) return "Invalid date";

    return date.toLocaleDateString('en-GB', {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      timeZone: 'UTC' 
    });
  };
  
  const getTodayDate = (): Date => {
    const now = new Date();
    return new Date(Date.UTC(
      now.getUTCFullYear(),
      now.getUTCMonth(),
      now.getUTCDate()
    ));
  };
  
  const today = getTodayDate();
  const lastClaimed = parseDatabaseDate(lastClaimedDate || '');
  const isClaimedToday = isSameDay(lastClaimed, today);

  const handleClaim = async (double: boolean, paymentMethod: "ton" | "stars" = "ton") => {
    try {
      if (double && paymentMethod === "ton") {
        if (!userAddress) {
          onOpenChange(false)
          await tonConnectUI.openModal()
          return
        }

        const balanceCheck = await walletService.hasEnoughBalance(
          userAddress,
          0.2 
        )

        if (!balanceCheck.sufficient) {
          throw new Error(
            `Insufficient balance in your wallet. You need 0.2 TON but you have ${balanceCheck.currentBalance.toFixed(2)} TON`
          )
        }
      }

      setProcessingMethod(double ? paymentMethod : "claim")

      if (double) {
        if (paymentMethod === "ton") {
          const tonAmount = BigInt(Math.floor(0.2 * 1000000000))

          const result = await tonConnectUI.sendTransaction({
            validUntil: Math.floor(Date.now() / 1000) + 600,
            messages: [
              {
                address: WALLET_ADDRESS,
                amount: tonAmount.toString(),
              },
            ],
          })

          if (!result?.boc) {
            throw new Error("Transaction failed")
          }
        } else {
          const invoiceLink = await createInvoiceLink(
            80,
            "Double Daily Reward", 
            "Double your daily reward by paying with stars"
          );

          const status = await openTelegramInvoice(invoiceLink);
          if (status !== "paid") {
            throw new Error("Payment not completed");
          }
        }
      }

      await onClaim(double);
      
      toast({
        title: "Reward Claimed!",
        description: `You received ${double ? "double" : ""} daily reward (${double ? "1000" : "500"} ${SIMPLE})`,
      });
      onOpenChange(false);
    } catch (error) {
      console.error("Claim error:", error);
      toast({
        title: "Claim Failed",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
      setProcessingMethod(null);
    }
  };

  const canDoubleClaimWithTon = userAddress && Number(walletBalance) >= 0.2;
  const STARS_COST = 80;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="w-[95%] max-w-md mx-auto max-h-[80vh] gradient-dark rounded-3xl">
          <DialogHeader className="text-center">
            <DialogTitle className="fire-text text-xl font-bold">Daily Reward</DialogTitle>
            <DialogDescription className="text-[#a0a0a0] text-sm">
              Claim your daily reward for logging in
            </DialogDescription>
          </DialogHeader>

          <DialogBody className="space-y-4 px-6 py-4 overflow-y-auto">
            <div className="bg-[#1A1A1A] rounded-xl p-4 text-center">
              <div className="flex justify-center mb-3">
                <div className="bg-[#ff6b35]/10 p-4 rounded-lg border border-[#ff6b35]/20">
                  <FaCalendarDay className="w-8 h-8 text-[#ff6b35]" />
                </div>
              </div>
              
              <div className="text-white font-semibold text-lg mb-1">
                Today: {today.toLocaleDateString('en-GB')}
              </div>
              <div className="text-[#a0a0a0] text-sm mb-3">
                Last claimed: {formatDate(lastClaimedDate)}
              </div>
              
              {isClaimedToday ? (
                <div className="text-[#ff6b35] text-sm mt-2">
                  You've already claimed today's reward
                </div>
              ) : (
                <div className="text-[#a0a0a0] text-sm mt-2">
                  Claim your 500 {SIMPLE} daily reward
                </div>
              )}
            </div>

            {!isClaimedToday ? (
              <>
                {userAddress && (
                  <div className="text-sm mt-2 text-[#a0a0a0] text-center">
                    Wallet Balance: <span className="text-white">{Number(walletBalance).toFixed(2)} TON</span>
                  </div>
                )}
                <motion.div whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => handleClaim(false)}
                    disabled={isProcessing}
                    className="w-full fire-gradient text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                  >
                    {processingMethod === "claim" ? (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : (
                      <>
                        <FaCoins className="w-5 h-5" />
                        <span>Claim 500 {SIMPLE}</span>
                      </>
                    )}
                  </Button>
                </motion.div>

                <motion.div whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => handleClaim(true, "ton")}
                    disabled={processingMethod !== null || (userAddress && !canDoubleClaimWithTon)}
                    className="w-full dark-bg hover:bg-[#3a9de0]/60 text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                  >
                    {processingMethod === "ton" ? (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : (
                      <>
                        <Image src="/toncoin.svg" alt="TON" width={20} height={20} />
                        <span className="ml-2">Double Reward (0.2 TON)</span>
                      </>
                    )}
                  </Button>
                </motion.div>

                <motion.div whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => handleClaim(true, "stars")}
                    disabled={processingMethod !== null}
                    className="w-full dark-bg hover:bg-[#eab308]/60 text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                  >
                    {processingMethod === "stars" ? (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : (
                      <>
                        <Image src="/stars.svg" alt="Stars" width={20} height={20} />
                        <span className="ml-2">Double Reward ({STARS_COST} Stars)</span>
                      </>
                    )}
                  </Button>
                </motion.div>
               </>
             ) : null } 
           </DialogBody>

           <DialogFooter className="px-6 pb-6">
             <motion.div whileTap={{ scale: 0.98 }} className="w-full">
              <Button
                onClick={() => onOpenChange(false)}
                variant="outline"
                className="w-full border-[#1A1A1A] text-[#a0a0a0] hover:bg-[#1a1a1a] rounded-xl h-10"
              >
                Close
              </Button>
            </motion.div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

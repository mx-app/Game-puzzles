"use client"

import { Button } from "@/components/ui/button"
import { FaBan } from "react-icons/fa"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"
import { useEffect, useState } from "react"
import { SIMPLE, NAME, SUPPORT_BOT } from "@/lib/config"

export default function BannedScreen() {
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    toast({
      title: "Account Banned",
      description: "Your account has been suspended",
      variant: "destructive",
    })
  }, [toast])

  return (
    <div className="min-h-screen bg-[#000] text-white flex flex-col items-center justify-center p-6 text-center">
      <div className="mb-8">
        <div className="bg-red-500/20 p-6 rounded-full inline-block">
          <FaBan className="w-16 h-16 text-red-500" />
        </div>
      </div>
      
      <h1 className="text-2xl font-bold mb-4">Account Suspended</h1>
      <p className="text-[#a0a0a0] mb-8 max-w-md">
        Your account has been banned due to violation of our terms of service.
        If you believe this is a mistake, please contact support.
      </p>

      <div className="flex flex-col gap-3 w-full max-w-xs">
        <Button 
          variant="outline" 
          className="border-red-500 text-red-500 hover:bg-red-500/10 rounded-2xl"
          onClick={() => window.open(SUPPORT_BOT, "_blank")}
        >
          Contact Support
        </Button>
        
        <div className="flex items-center justify-center gap-2 mt-8">
          <Image src="/logo.svg" alt="BLIX" width={20} height={20} />
          <span className="text-sm text-[#a0a0a0]">{NAME}</span>
        </div>
      </div>
    </div>
  )
}

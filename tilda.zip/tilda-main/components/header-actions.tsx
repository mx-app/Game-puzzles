"use client"

import { Button } from "@/components/ui/button"
import { FaCalendarDay, FaCrown, FaBolt, FaTicketAlt, FaPlus, FaShoppingCart } from "react-icons/fa"
import { useRouter } from "next/navigation"
import { MdRocketLaunch, MdMenu } from "react-icons/md"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { FaSquareXTwitter, FaTelegram } from "react-icons/fa6"
import { FiPlusCircle } from "react-icons/fi"
import { formatBalance } from "@/lib/utils"
import { CHANNEL_URL } from "@/lib/config"

export function HeaderActions({
  router,
  setShowDailyRewardDialog,
  setShowWalletDialog,
  setShowUpgradeDialog,
  isSubscriptionActive,
  isPremiumUser,
  tickets = 0,
  setShowTicketDialog
}: {
  router: any
  setShowDailyRewardDialog: (open: boolean) => void
  setShowWalletDialog: (open: boolean) => void
  setShowUpgradeDialog: (open: boolean) => void
  isSubscriptionActive: boolean
  isPremiumUser: boolean
  tickets?: number
  setShowTicketDialog?: (open: boolean) => void
}) {
  return (
    <div className="flex justify-between items-center p-6 gap-2 pt-4">
      <div className="flex items-center gap-2">
        <Button 
          onClick={() => setShowTicketDialog && setShowTicketDialog(true)}
          className="rounded-2xl dark-bg hover:bg-[#2a2a2a] h-10 px-3 flex items-center gap-2"
        >
          <FaTicketAlt className="w-4 h-4 text-tp" />
          <span className="font-medium">{formatBalance(tickets)}</span>
          <FiPlusCircle className="w-2.5 h-2.5 text-[#fff]" />
        </Button>
      </div>

      <div className="flex gap-2">
       <Button 
          onClick={() => router.push("/premium")}
          className="rounded-2xl dark-bg hover:bg-[#2a2a2a] h-10 px-3"
        >
          <FaCrown className="w-5 h-5 text-[#fff]" />
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button 
              className="rounded-2xl dark-bg hover:bg-[#2a2a2a] h-10 px-3"
            >
              <MdMenu className="w-5 h-5 text-[#fff]" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent 
            className="w-56 dark-bg backdrop-blur-md rounded-2xl gap-2"
            sideOffset={5} 
            align="end"
          >
            <DropdownMenuItem 
              onClick={() => setShowWalletDialog(true)}
              className="flex items-center rounded-xl gap-3 cursor-pointer hover:bg-[#2a2a2a] px-4 py-3 mb-1 border-b border-[#1A1A1A]"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M21.1009 8.00353C21.0442 7.99996 20.9825 7.99998 20.9186 8L20.9026 8.00001H18.3941C16.3264 8.00001 14.5572 9.62757 14.5572 11.75C14.5572 13.8724 16.3264 15.5 18.3941 15.5H20.9026L20.9186 15.5C20.9825 15.5 21.0442 15.5001 21.1009 15.4965C21.9408 15.4434 22.6835 14.7862 22.746 13.8682C22.7501 13.808 22.75 13.7431 22.75 13.683L22.75 13.6667V9.83334L22.75 9.81702C22.75 9.75688 22.7501 9.69199 22.746 9.6318C22.6835 8.71381 21.9408 8.05657 21.1009 8.00353ZM18.1717 12.75C18.704 12.75 19.1355 12.3023 19.1355 11.75C19.1355 11.1977 18.704 10.75 18.1717 10.75C17.6394 10.75 17.2078 11.1977 17.2078 11.75C17.2078 12.3023 17.6394 12.75 18.1717 12.75Z"
                  fill="#fff"
                />
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M20.9179 17C21.067 16.9961 21.1799 17.1342 21.1394 17.2778C20.9387 17.9902 20.62 18.5975 20.1088 19.1088C19.3604 19.8571 18.4114 20.1892 17.239 20.3469C16.0998 20.5 14.6442 20.5 12.8064 20.5H10.6936C8.85583 20.5 7.40019 20.5 6.26098 20.3469C5.08856 20.1892 4.13961 19.8571 3.39124 19.1088C2.64288 18.3604 2.31076 17.4114 2.15314 16.239C1.99997 15.0998 1.99998 13.6442 2 11.8064V11.6936C1.99998 9.85583 1.99997 8.40019 2.15314 7.26098C2.31076 6.08856 2.64288 5.13961 3.39124 4.39124C4.13961 3.64288 5.08856 3.31076 6.26098 3.15314C7.40019 2.99997 8.85582 2.99998 10.6936 3L12.8064 3C14.6442 2.99998 16.0998 2.99997 17.239 3.15314C18.4114 3.31076 19.3604 3.64288 20.1088 4.39124C20.62 4.90252 20.9386 5.50974 21.1394 6.22218C21.1799 6.36575 21.067 6.50387 20.9179 6.5L18.394 6.50001C15.5574 6.50001 13.0571 8.74091 13.0571 11.75C13.0571 14.7591 15.5574 17 18.394 17L20.9179 17ZM5.75 7C5.33579 7 5 7.33579 5 7.75C5 8.16421 5.33579 8.5 5.75 8.5H9.75C10.1642 8.5 10.5 8.16421 10.5 7.75C10.5 7.33579 10.1642 7 9.75 7H5.75Z"
                  fill="#fff"
                />
              </svg>
              <span>Wallet</span>
            </DropdownMenuItem>

            <DropdownMenuItem 
              onClick={() => router.push("/market")}
              className="flex items-center rounded-xl gap-3 cursor-pointer hover:bg-[#2a2a2a] px-4 py-3 mb-1 border-b border-[#1A1A1A]"
            >
              <FaShoppingCart className="w-4 h-4" />
              <span>Market</span>
            </DropdownMenuItem>
            
            <DropdownMenuItem 
              onClick={() => isSubscriptionActive && setShowUpgradeDialog(true)}
              disabled={!isSubscriptionActive}
              className={`flex items-center rounded-xl gap-3 px-4 py-3 mb-1 border-b border-[#1A1A1A] ${!isSubscriptionActive ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:bg-[#2a2a2a]'}`}
            >
              <FaBolt className="w-4 h-4" />
              <span>Mining Upgrades</span>
            </DropdownMenuItem>
            
            <DropdownMenuItem 
              onClick={() => setShowDailyRewardDialog(true)}
              className="flex items-center rounded-xl gap-3 cursor-pointer hover:bg-[#2a2a2a] px-4 py-3 mb-1 border-b border-[#1A1A1A]"
            >
              <FaCalendarDay className="w-4 h-4" />
              <span>Daily Rewards</span>
            </DropdownMenuItem>

            <DropdownMenuItem 
              onClick={() => window.open(CHANNEL_URL, "_blank")}
              className="flex items-center rounded-xl gap-3 cursor-pointer hover:bg-[#2a2a2a] px-4 py-3"
            >
              <FaTelegram className="w-4 h-4" />
              <span>Telegram Channel</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )
}

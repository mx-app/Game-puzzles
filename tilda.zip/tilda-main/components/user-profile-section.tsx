"use client"

import Image from "next/image"
import { motion } from "framer-motion"
import { formatBalance } from "@/lib/utils"
import { useState } from "react"
import { FaCrown } from "react-icons/fa"

interface UserProfileSectionProps {
  userPhoto: string
  userName: string
  displayName: string
  isPremiumUser: boolean
  Balance: number
  router: any
  user?: any
  onImageClick?: () => void
}

export function UserProfileSection({
  userPhoto,
  userName,
  displayName,
  isPremiumUser,
  Balance,
  router,
  user,
  onImageClick,
}: UserProfileSectionProps) {

  return (
    <>
      <div className="flex-1 flex flex-col items-center justify-center pt-4">
        <div className="relative mb-4" onClick={onImageClick}>
          {userPhoto ? (
            <motion.div whileTap={{ scale: 0.95 }}>
              <Image
                src={userPhoto || "/placeholder.svg"}
                alt={userName}
                width={120}
                height={120}
                className={`rounded-3xl border-2 cursor-pointer ${isPremiumUser ? "tp-border" : "border-[#1A1A1A]"}`}
              />
            </motion.div>
          ) : (
            <div>No Image</div>
          )}
          
          {isPremiumUser && (
            <div className="absolute -top-2 -right-2 tp-bg rounded-full p-2">
              <FaCrown className="w-5 h-5 text-white" />
            </div>
          )}
        </div>

        <div className="flex flex-col items-center gap-1 mb-6">
          <div className="flex items-center justify-center gap-2">
            <div className="text-4xl font-bold text-white">{formatBalance(Balance)}</div>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="35" height="35">
              <circle cx="50" cy="50" r="45" fill="#0a0a0a" stroke="#1A1A1A" strokeWidth="2" />
              <g transform="translate(50, 50)">
                <text
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fontFamily="sans-serif"
                  fontSize="100"
                  fill="white"
                  dy="2"
                >
                  ~
                </text>
              </g>
            </svg>
          </div>

          <motion.div whileTap={{ scale: 0.95 }} className="flex justify-center mb-6 mt-4">
            <button
              onClick={() => router.push("/market")}
              className="bg-[#ff6b35]/10 text-[#ff6b35] border border-[#ff6b35]/20 hover:bg-[#ff6b35]/20 transition-colors rounded-3xl px-4 py-1.5 text-sm flex items-center gap-1"
            >
              <span>Boost Your Journey</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M9 18L15 12L9 6"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
          </motion.div>
        </div>
      </div>
    </>
  )
}

"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AppLayout } from "@/components/app-layout"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FaUserFriends, FaLink, FaShare, FaCopy, FaGift, FaCheckCircle, FaSpinner } from "react-icons/fa"
import { BottomNavigation } from "@/components/bottom-navigation"
import Image from "next/image"
import { Skeleton } from "@/components/ui/skeleton"
import { motion } from "framer-motion"
import { formatBalance } from "@/lib/utils"
import { formatNumber } from "@/lib/utils"
import { SIMPLE, NAME, MINI_APP } from "@/lib/config"

export default function ReferralsPage() {
  const { toast } = useToast()

  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isFriendsLoading, setIsFriendsLoading] = useState(true)
  const [webAppReferralLink, setWebAppReferralLink] = useState("")
  const [telegramShareLink, setTelegramShareLink] = useState("")
  const [claimingTasks, setClaimingTasks] = useState<Record<string, boolean>>({})

  const fetchUserData = useCallback(async () => {
    try {
      if (typeof window === "undefined" || !window.Telegram?.WebApp?.initData) {
        return
      }

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_or_create_user",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setUser(data.user)

        const referralLink = `${MINI_APP}?startapp=${data.user.telegram_id}`
        const shareLink = `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(`Join me on ${NAME} and we’ll get rewards together!`)}`
        
        setWebAppReferralLink(referralLink)
        setTelegramShareLink(shareLink)
      }
    } catch (error) {
      console.error("Error fetching user data:", error)
    } finally {
      setIsLoading(false)
      setIsFriendsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUserData()
  }, [fetchUserData])

  const copyReferralLink = () => {
    if (webAppReferralLink) {
      navigator.clipboard.writeText(webAppReferralLink)
      toast({
        title: "Link copied",
        description: "Referral link copied to clipboard",
      })
    }
  }

  const shareReferralLink = () => {
    if (telegramShareLink) {
      window.open(telegramShareLink, "_blank")
    }
  }

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  const truncateText = (text: string, maxLength: number) => {
    return text.length > maxLength ? `${text.substring(0, maxLength)}...` : text
  }

  const referralTasks = [
    {
      id: "invite_1_friend",
      title: "Invite 1 Friend",
      reward: 10000,
      progress: 1,
    },
    {
      id: "invite_10_friends",
      title: "Invite 10 Friends",
      reward: 100000,
      progress: 10,
    },
    {
      id: "invite_100_friends",
      title: "Invite 100 Friends",
      reward: 1000000,
      progress: 100,
    }
  ]

  const isTaskCompleted = (taskId: string) => {
    if (!user?.completed_tasks) return false
    return user.completed_tasks.some((t: any) => t.taskId === taskId && t.completed)
  }

  const claimTaskReward = async (taskId: string, rewardAmount: number) => {
    setClaimingTasks(prev => ({ ...prev, [taskId]: true }))
    
    try {
      const startResponse = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "start_static_task",
          initData: window.Telegram.WebApp.initData,
          taskId: taskId,
        }),
      })

      if (!startResponse.ok) {
        throw new Error("Failed to start task")
      }

      const completeResponse = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "complete_static_task",
          initData: window.Telegram.WebApp.initData,
          taskId: taskId,
          rewardAmount: rewardAmount,
        }),
      })

      if (completeResponse.ok) {
        const data = await completeResponse.json()
        setUser(data.user)
        toast({
          title: "Reward claimed!",
          description: `You've received ${rewardAmount} ${SIMPLE}`,
        })
      }
    } catch (error) {
      console.error("Error claiming reward:", error)
      toast({
        title: "Failed to claim reward",
        description: "Please try again",
        variant: "destructive",
      })
    } finally {
      setClaimingTasks(prev => ({ ...prev, [taskId]: false }))
    }
  }

  const renderReferralTasks = () => {
    if (!user) return null
    
    const referralCount = user?.referrals?.length || 0
    const updatedTasks = referralTasks.map(task => ({
      ...task,
      current: referralCount,
      completed: isTaskCompleted(task.id),
      canClaim: referralCount >= task.progress && !isTaskCompleted(task.id)
    }))

    return (
      <div className="space-y-3">
        {updatedTasks.map((task) => (
          <motion.div 
            key={task.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="bg-[#1a1a1a] border-[#1A1A1A] rounded-xl w-full">
              <CardContent className="p-3">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-tp border border-tp rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                    <FaUserFriends className="w-5 h-5 text-tp" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-white font-medium text-sm truncate mb-2">
                      {task.title}
                    </h3>
                    <div className="flex justify-between items-center">
                      <Badge className="bg-tp text-tp tp-border text-xs">
                        +{formatBalance(task.reward)}
                      </Badge>
                      <span className="text-[#a0a0a0] text-xs">
                        {Math.min(task.current, task.progress)}/{task.progress}
                      </span>
                    </div>
                  </div>
                  <Button
                    onClick={() => claimTaskReward(task.id, task.reward)}
                    disabled={!task.canClaim || claimingTasks[task.id]}
                    className={`h-8 text-xs rounded-xl ${task.completed ? 
                      'bg-green-500/10 text-green-400 border-green-500/20 hover:bg-green-500/20' : 
                      'fire-gradient'}`}
                  >
                    {claimingTasks[task.id] ? (
                      <div className="flex items-center justify-center">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : task.completed ? (
                      <>
                        <FaCheckCircle className="w-3 h-3 mr-1" />
                        Done
                      </>
                    ) : (
                      "Claim"
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    )
  }

  const HeaderSection = () => (
    <div className="text-center mb-6">
      <h1 className="text-2xl font-bold fire-text mb-1">Invite Friends</h1>
      <div className="flex justify-center items-center space-x-2">
        <FaUserFriends className="w-4 h-4 text-tp" />
        {isFriendsLoading ? (
          <Skeleton className="h-4 w-20 bg-[#1A1A1A] rounded" />
        ) : (
          <span className="text-[#a0a0a0] text-sm">
            {user?.referrals?.length || 0} {user?.referrals?.length === 1 ? 'friend' : 'friends'} joined
          </span>
        )}
      </div>
    </div>
  )

  const TabSwitcher = () => (
    <TabsList className="grid w-full grid-cols-2 dark-bg h-12 rounded-2xl p-1 mb-4">
      <TabTrigger value="invite" icon={<FaLink className="text-tp" />} label="Invite" />
      <TabTrigger value="friends" icon={<FaUserFriends className="text-tp" />} label="Friends" />
    </TabsList>
  )

  const TabTrigger = ({ value, icon, label }: { value: string, icon: React.ReactNode, label: string }) => (
    <TabsTrigger
      value={value}
      className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
    >
      <div className="flex items-center justify-center space-x-2 z-10 relative">
        {icon}
        <span>{label}</span>
      </div>
      <div className="absolute inset-0 data-[state=active]:bg-[#2a2a2a] data-[state=active]:rounded-xl z-0" />
    </TabsTrigger>
  )

  const ReferralLinksCard = () => (
    <Card className="dark-bg rounded-2xl w-full">
      <CardContent className="p-4 space-y-4">
        <div>
          <h4 className="text-white font-semibold mb-3">Your Referral Link</h4>
          {webAppReferralLink ? (
            <div className="bg-[#1a1a1a] rounded-xl p-3 text-sm text-[#a0a0a0] break-all font-mono">
              {webAppReferralLink}
            </div>
          ) : (
            <Skeleton className="w-full h-12 bg-[#2a2a2a] rounded-xl" />
          )}
          <div className="grid grid-cols-2 gap-3 mt-4">
            <Button
              onClick={copyReferralLink}
              className="dark-bg hover:bg-[#3a3a3a] tp-border h-11 rounded-xl"
              disabled={!webAppReferralLink}
            >
              <FaCopy className="w-4 h-4 mr-2 text-tp" />
              Copy
            </Button>
            <Button
              onClick={shareReferralLink}
              className="fire-gradient h-11 rounded-xl"
              disabled={!webAppReferralLink}
            >
              <FaShare className="w-4 h-4 mr-2 text-white" />
              Share
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const HowItWorksCard = () => (
    <Card className="dark-bg rounded-2xl bg-overlay w-full">
      <CardContent className="p-4">
        <h4 className="text-white font-semibold mb-3">How It Works</h4>
        <div className="space-y-4">
          {[
            {
              step: 1,
              title: "Share your link",
              description: "Send your referral link to friends",
              color: "bg-tp tp-border"
            },
            {
              step: 2,
              title: "Friend joins",
              description: `They click your link and start using ${SIMPLE}`,
              color: "bg-tp tp-border"
            },
            {
              step: 3,
              title: "Both earn rewards",
              description: `You and your friend each get 5000 ${SIMPLE}, and you (the inviter) also get a 1 ticket`,
              color: "bg-green-500"
            }
          ].map((item) => (
            <div key={item.step} className="flex items-start space-x-4">
              <div className={`${item.color} w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold mt-0.5 flex-shrink-0`}>
                {item.step}
              </div>
              <div>
                <div className="fire-text text-sm font-medium">{item.title}</div>
                <div className="text-[#a0a0a0] text-xs mt-1">{item.description}</div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )

  const TasksCard = () => (
    <Card className="dark-bg rounded-2xl w-full">
      <CardContent className="p-4">
        <h4 className="text-white font-semibold mb-3">Referral Tasks</h4>
        {renderReferralTasks()}
      </CardContent>
    </Card>
  )

  const FriendsListSkeleton = () => (
    <div className="space-y-3">
      {[...Array(5)].map((_, index) => (
        <Card key={index} className="bg-[#1a1a1a] border-[#1A1A1A] rounded-xl w-full">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3 min-w-0">
                <Skeleton className="w-10 h-10 rounded-lg bg-[#2a2a2a]" />
                <div className="min-w-0 space-y-2">
                  <Skeleton className="h-4 w-24 bg-[#2a2a2a]" />
                  <Skeleton className="h-3 w-16 bg-[#2a2a2a]" />
                </div>
              </div>
              <Skeleton className="h-6 w-12 bg-[#2a2a2a]" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )

  const EmptyFriendsState = () => (
    <Card className="dark-bg rounded-2xl w-full">
      <CardContent className="p-6 text-center">
        <div className="w-16 h-16 mx-auto mb-4 bg-[#2a2a2a] rounded-2xl flex items-center justify-center">
          <FaUserFriends className="w-7 h-7 text-[#a0a0a0]" />
        </div>
        <h3 className="fire-text text-lg font-semibold mb-2">No Friends Yet</h3>
        <p className="text-[#a0a0a0] text-sm">
          Invite friends to see them here and earn {SIMPLE} together!
        </p>
      </CardContent>
    </Card>
  )

  const FriendItem = ({ referral }: { referral: any }) => (
    <Card className="bg-[#1a1a1a] border-[#1A1A1A] rounded-xl">
      <CardContent className="p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 min-w-0">
            <div className="w-10 h-10 bg-tp/10 rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
              {referral.photo_url ? (
                <Image
                  src={referral.photo_url}
                  alt={referral.first_name}
                  width={40}
                  height={40}
                  className="object-cover"
                />
              ) : (
                <div className="text-tp font-bold">
                  {referral.first_name?.charAt(0) || referral.username?.charAt(0) || "?"}
                </div>
              )}
            </div>
            <div className="min-w-0">
              <div className="fire-text font-medium text-sm truncate">
                {truncateText(`${referral.first_name || ''} ${referral.last_name || ''}`.trim(), 20)}
              </div>
              <div className="text-[#a0a0a0] text-xs truncate">
                {referral.username && `@${truncateText(referral.username, 10)} • `}
                {formatDate(referral.joined_at)}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const FriendsList = () => {
    const friendsCount = user?.referrals?.length || 0

    return (
      <div className="space-y-3">
        <div className="dark-bg rounded-2xl p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-medium">Your Friends</h3>
            <Badge className="bg-tp/10 text-tp tp-border">
              {friendsCount} friend{friendsCount !== 1 ? 's' : ''}
            </Badge>
          </div>
          <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
            {user?.referrals?.map((referral: any) => (
              <FriendItem key={referral.telegram_id} referral={referral} />
            ))}
          </div>
        </div>
      </div>
    )
  }

  const ReferralStats = () => {
    const friendsCount = user?.referrals?.length || 0;
    const coinsEarned = friendsCount * 5000;
    const ticketsEarned = friendsCount;

    return (
      <Card className="dark-bg rounded-2xl w-full">
        <CardContent className="p-4">
          <h4 className="text-white font-semibold mb-4">Referral Stats</h4>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#1a1a1a] border border-[#1A1A1A] rounded-xl p-3 text-center">
              <div className="text-tp text-sm font-medium mb-1">{SIMPLE}</div>
              <div className="fire-text font-bold text-lg">
                {formatNumber(coinsEarned)}
              </div>
            </div>
            <div className="bg-[#1a1a1a] border border-[#1A1A1A] rounded-xl p-3 text-center">
              <div className="text-tp text-sm font-medium mb-1">TICKET</div>
              <div className="fire-text font-bold text-lg">
                {formatNumber(ticketsEarned)}
              </div>
            </div>
          </div>
          <div className="mt-4 text-[#a0a0a0] text-xs text-center">
            Each successful referral 5000 {SIMPLE} + 1 Ticket
          </div>
        </CardContent>
      </Card>
    )
  }

  const FriendsTabContent = () => {
    if (isFriendsLoading) {
      return <FriendsListSkeleton />
    }

    return user?.referrals?.length === 0 ? <EmptyFriendsState /> : <FriendsList />
  }

  if (isLoading) {
  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full">
        <div className="pb-24 pt-4 w-[90%] mx-auto max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold fire-text mb-1">Invite Friends</h1>
            <div className="flex justify-center items-center space-x-2">
              <FaUserFriends className="w-4 h-4 text-tp" />
              <span className="text-[#a0a0a0] text-sm">Loading friends...</span>
            </div>
          </div>

          <Tabs defaultValue="invite" className="w-full">
            <TabsList className="grid w-full grid-cols-2 dark-bg h-12 rounded-2xl p-1 mb-4">
              <TabTrigger value="invite" icon={<FaLink className="text-tp" />} label="Invite" />
              <TabTrigger value="friends" icon={<FaUserFriends className="text-tp" />} label="Friends" />
            </TabsList>

            <TabsContent value="invite" className="space-y-5">
              <Card className="dark-bg rounded-2xl w-full">
                <CardContent className="p-4 space-y-4">
                  <div>
                    <Skeleton className="h-5 w-32 mb-3 bg-[#2a2a2a]" />
                    <Skeleton className="w-full h-12 rounded-xl bg-[#2a2a2a]" />
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <Skeleton className="h-11 rounded-xl bg-[#2a2a2a]" />
                      <Skeleton className="h-11 rounded-xl bg-[#2a2a2a]" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="dark-bg rounded-2xl w-full">
                <CardContent className="p-4">
                  <Skeleton className="h-5 w-32 mb-3 bg-[#2a2a2a]" />
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="flex items-start space-x-4">
                        <Skeleton className="w-6 h-6 rounded-full bg-[#2a2a2a]" />
                        <div className="flex-1 space-y-2">
                          <Skeleton className="h-4 w-28 bg-[#2a2a2a]" />
                          <Skeleton className="h-3 w-40 bg-[#2a2a2a]" />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              <Card className="dark-bg rounded-2xl w-full">
                <CardContent className="p-4">
                  <Skeleton className="h-5 w-32 mb-3 bg-[#2a2a2a]" />
                  <div className="space-y-3">
                    {[...Array(3)].map((_, i) => (
                      <Card key={i} className="bg-[#1a1a1a] rounded-xl">
                        <CardContent className="p-3 flex items-center space-x-3">
                          <Skeleton className="w-10 h-10 rounded-lg bg-[#2a2a2a]" />
                          <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-28 bg-[#2a2a2a]" />
                            <Skeleton className="h-3 w-16 bg-[#2a2a2a]" />
                          </div>
                          <Skeleton className="h-8 w-16 rounded-xl bg-[#2a2a2a]" />
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="friends" className="space-y-4">
              <FriendsListSkeleton />
              <Card className="dark-bg rounded-2xl w-full">
                <CardContent className="p-4">
                  <Skeleton className="h-5 w-32 bg-[#2a2a2a] mb-4" />
                  <div className="grid grid-cols-2 gap-3">
                    <Skeleton className="h-16 bg-[#2a2a2a] rounded-xl" />
                    <Skeleton className="h-16 bg-[#2a2a2a] rounded-xl" />
                  </div>
                  <Skeleton className="h-3 w-40 bg-[#2a2a2a] mt-4 mx-auto" />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
        <BottomNavigation />
      </div>
    </AppLayout>
   )
 }
  
  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full">
        <div className="pb-24 pt-4 w-[90%] mx-auto max-w-md">
          <HeaderSection />
          
          <Tabs defaultValue="invite" className="w-full">
            <TabSwitcher />
            
            <TabsContent value="invite" className="space-y-5">
              <ReferralLinksCard />
              <HowItWorksCard />
              <TasksCard />
            </TabsContent>

            <TabsContent value="friends" className="space-y-4">
              <FriendsTabContent />
              <ReferralStats />
            </TabsContent>
          </Tabs>
        </div>
        <BottomNavigation />
      </div>
    </AppLayout>
  )
}

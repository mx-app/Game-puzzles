import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { action } = body

    switch (action) {
      case "get_tasks": {
        const { data: tasks, error } = await supabase
          .from("tasks")
          .select("*")
          .eq("is_active", true)
          .order("created_at", { ascending: false })

        if (error) throw error

        return NextResponse.json({
          success: true,
          tasks: tasks || [],
        })
      }

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }
  } catch (error) {
    console.error("Tasks API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

import { type NextRequest, NextResponse } from "next/server"
import { ADMIN_ID } from "@/lib/config"

type PurchaseRequest = {
  userId: string
  username?: string
  walletAddress?: string
  productId: string
  productType: "tp" | "nft"
  paymentMethod: "ton" | "stars"
  amount: number
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      userId,
      username,
      walletAddress,
      productId,
      productType,
      paymentMethod,
      amount,
    } = body as PurchaseRequest

    if (!userId || !productId || !productType || !paymentMethod || amount == null) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      )
    }

    if (productType === "nft" && !walletAddress) {
      return NextResponse.json(
        { error: "Wallet address is required for NFT purchases" },
        { status: 400 }
      )
    }

    const message =
      `<b>🛒 New Purchase Notification</b>\n\n` +
      `<b>🔹 Product Type:</b> ${productType.toUpperCase()}\n` +
      `<b>🔹 Product ID:</b> ${productId}\n\n` +
      `<b>👤 User Information:</b>\n` +
      `- ID: <code>${userId}</code>\n` +
      `- Username: ${username ? `<code>${username}</code>` : "Not provided"}\n\n` +
      `<b>💳 Purchase Details:</b>\n` +
      `- Payment Method: ${paymentMethod.toUpperCase()}\n` +
      `- Amount: ${amount} ${paymentMethod === "ton" ? "TON" : "Stars"}\n\n` +
      (productType === "nft" && walletAddress
        ? `<b>📦 Delivery Information:</b>\n` +
          `- Wallet Address: <code>${walletAddress}</code>\n\n` +
          `Please process this NFT delivery to the specified wallet address.`
        : `The Coins have been automatically added to the user's balance.`)

    const botToken = process.env.TELEGRAM_BOT_TOKEN
    if (!botToken) {
      return NextResponse.json(
        { error: "Server configuration error" },
        { status: 500 }
      )
    }

    const telegramResponse = await fetch(
      `https://api.telegram.org/bot${botToken}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: ADMIN_ID,
          text: message,
          parse_mode: "HTML"
        }),
      }
    )

    if (!telegramResponse.ok) {
      const error = await telegramResponse.json()
      return NextResponse.json(
        {
          success: false,
          error: "Failed to send purchase notification",
          details: error.description || "Unknown Telegram API error"
        },
        { status: 502 }
      )
    }

    return NextResponse.json({
      success: true,
      notified: true,
      message: "Purchase recorded and notification sent"
    })

  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Internal server error",
        details: error instanceof Error ? error.message : "Unknown error"
      },
      { status: 500 }
    )
  }
}

export async function OPTIONS() {
  return new NextResponse(null, {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  })
}

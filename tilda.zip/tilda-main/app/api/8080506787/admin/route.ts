import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

const ADMIN_SECRET = process.env.ADMIN_SECRET || ""

function verifyAdminAuth(password: string): boolean {
  return password === ADMIN_SECRET
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, adminPassword, ...data } = body

    if (!verifyAdminAuth(adminPassword)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    switch (action) {
      case "get_dashboard_stats": {
        const [usersResult, balanceResult, tasksResult] = await Promise.all([
          supabase.from("wallets").select("id", { count: "exact" }),
          supabase.from("wallets").select("balance"),
          supabase.from("tasks").select("id", { count: "exact" }),
        ])

        const totalUsers = usersResult.count || 0
        const totalBalance = balanceResult.data?.reduce((sum, user) => sum + Number(user.balance || 0), 0) || 0
        const totalTasks = tasksResult.count || 0

        return NextResponse.json({
          success: true,
          stats: {
            totalUsers,
            totalBalance,
            totalTasks,
          },
        })
      }

      case "get_all_users": {
        const { data: users, error } = await supabase
          .from("wallets")
          .select("*")
          .order("created_at", { ascending: false })

        if (error) throw error

        return NextResponse.json({
          success: true,
          users: users || [],
        })
      }

      case "get_user_by_id": {
        const { userId } = data
        const { data: user, error } = await supabase.from("wallets").select("*").eq("telegram_id", userId).single()

        if (error) throw error

        return NextResponse.json({
          success: true,
          user,
        })
      }

      case "update_user": {
        const { userId, updates } = data
        const { data: updatedUser, error } = await supabase
          .from("wallets")
          .update(updates)
          .eq("telegram_id", userId)
          .select()
          .single()

        if (error) throw error

        return NextResponse.json({
          success: true,
          user: updatedUser,
        })
      }

      case "search_users": {
        const { query } = data
        let searchQuery = supabase.from("wallets").select("*")

        if (query) {
          searchQuery = searchQuery.or(`telegram_id.ilike.%${query}%,telegram_username.ilike.%${query}%`)
        }

        const { data: users, error } = await searchQuery.limit(50)

        if (error) throw error

        return NextResponse.json({
          success: true,
          users: users || [],
        })
      }

      case "get_all_tasks": {
        const { data: tasks, error } = await supabase
          .from("tasks")
          .select("*")
          .order("created_at", { ascending: false })

        if (error) throw error

        return NextResponse.json({
          success: true,
          tasks: tasks || [],
        })
      }

      case "create_task": {
        const { taskData } = data
        const { data: newTask, error } = await supabase.from("tasks").insert([taskData]).select().single()

        if (error) throw error

        return NextResponse.json({
          success: true,
          task: newTask,
        })
      }

      case "update_task": {
        const { taskId, updates } = data
        const { data: updatedTask, error } = await supabase
          .from("tasks")
          .update(updates)
          .eq("id", taskId)
          .select()
          .single()

        if (error) throw error

        return NextResponse.json({
          success: true,
          task: updatedTask,
        })
      }

      case "delete_task": {
        const { taskId } = data
        const { error } = await supabase.from("tasks").delete().eq("id", taskId)

        if (error) throw error

        return NextResponse.json({
          success: true,
        })
      }

      case "get_leaderboard": {
        const { type } = data

        if (type === "balance") {
          const { data: leaderboard, error } = await supabase.rpc("get_top_users_by_balance", { limit_count: 100 })

          if (error) throw error

          return NextResponse.json({
            success: true,
            leaderboard: leaderboard || [],
          })
        } else if (type === "referrals") {
          const { data: leaderboard, error } = await supabase.rpc("get_top_users_by_referrals", { limit_count: 100 })

          if (error) throw error

          return NextResponse.json({
            success: true,
            leaderboard: leaderboard || [],
          })
        }

        return NextResponse.json({ error: "Invalid leaderboard type" }, { status: 400 })
      }

      case "ban_user": {
        const { userId, banned } = data
        const { data: updatedUser, error } = await supabase
          .from("wallets")
          .update({ is_banned: banned })
          .eq("telegram_id", userId)
          .select()
          .single()

        if (error) throw error

        return NextResponse.json({
          success: true,
          user: updatedUser,
        })
      }

      case "add_mining_subscription": {
        const { userId, plan } = data
        
        const subscriptionData = {
          isActive: true,
          plan: plan,
          startTime: Date.now(),
          lastClaimTime: Date.now()
        }

        const { data: updatedUser, error } = await supabase
          .from("wallets")
          .update({ mining_subscription: subscriptionData })
          .eq("telegram_id", userId)
          .select()
          .single()

        if (error) throw error

        return NextResponse.json({
          success: true,
          user: updatedUser,
        })
      }

      case "remove_mining_subscription": {
        const { userId } = data
        const { data: updatedUser, error } = await supabase
          .from("wallets")
          .update({ mining_subscription: null })
          .eq("telegram_id", userId)
          .select()
          .single()

        if (error) throw error

        return NextResponse.json({
          success: true,
          user: updatedUser,
        })
      }

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }
  } catch (error) {
    console.error("Admin API error:", error)
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "Internal server error",
      },
      { status: 500 },
    )
  }
}

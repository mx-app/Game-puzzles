import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"
import crypto from "crypto"

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || ""

function verifyTelegramWebAppData(initData: string): { isValid: boolean; data?: any } {
  try {
    const urlParams = new URLSearchParams(initData)
    const hash = urlParams.get("hash")
    urlParams.delete("hash")

    const dataCheckString = Array.from(urlParams.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([key, value]) => `${key}=${value}`)
      .join("\n")

    const secretKey = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest()
    const calculatedHash = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex")

    if (calculatedHash !== hash) {
      return { isValid: false }
    }
    
    const userParam = urlParams.get("user")
    if (!userParam) {
      return { isValid: false }
    }

    const userData = JSON.parse(decodeURIComponent(userParam))
    const defaultUsername = `user_${userData.id}`

    return {
      isValid: true,
      data: {
        telegram_id: userData.id.toString(),
        telegram_username: userData.username || defaultUsername,
        first_name: userData.first_name || "",
        last_name: userData.last_name || "",
        photo_url: userData.photo_url || "",
      },
    }
  } catch (error) {
    console.error("Error verifying Telegram data:", error)
    return { isValid: false }
  }
}

async function createUser(userData: any, referrerId?: string) {
  try {
    console.log(`Creating new user - ID: ${userData.telegram_id}, Username: ${userData.telegram_username}, Referrer: ${referrerId || 'None'}`)
    
    const finalUsername = userData.telegram_username || `user_${userData.telegram_id}`
    
    const newUser = {
      telegram_id: userData.telegram_id,
      telegram_username: finalUsername,
      user_photo_url: userData.photo_url || "",
      balance: referrerId ? 1000 : 500,
      tickets_balance: 0,
      mining_subscription: {},
      mining_upgrades: {},
      completed_tasks: [],
      referrals: [],
      last_daily_reward: null,
    }
    
    const { data, error } = await supabase.from("wallets").insert([newUser]).select().single()

    if (error) throw error

    if (referrerId) {
      console.log(`Processing referral for referrer ID: ${referrerId} by new user ID: ${userData.telegram_id}`)
      await processReferral(referrerId, userData)
    }

    console.log(`User created successfully - ID: ${userData.telegram_id}, Username: ${userData.telegram_username}`)
    return data
  } catch (error) {
    console.error(`Error creating user ID: ${userData.telegram_id}:`, error)
    throw error
  }
}

async function processReferral(referrerId: string, newUserData: any) {
  try {
    console.log(`Starting referral processing - Referrer: ${referrerId}, New User: ${newUserData.telegram_id}`)
    
    const { data: referrer, error: referrerError } = await supabase
      .from("wallets")
      .select("*")
      .eq("telegram_id", referrerId)
      .single()

    if (referrerError || !referrer) {
      console.log(`Referrer not found: ${referrerId}`)
      return
    }
  
    const { data: updatedReferrer, error: updateError } = await supabase
      .rpc('award_reward', {
        p_telegram_id: referrerId,
        p_reward: 5000
      })

    if (updateError) {
      console.error(`Error updating referrer balance - ID: ${referrerId}:`, updateError)
      return
    }
    
    const { error: ticketError } = await supabase
      .rpc("update_tickets_balance", {
        p_telegram_id: referrerId,
        p_tickets_amount: 1,
      });

    if (ticketError) {
      console.error(`Error updating referrer tickets - ID: ${referrerId}:`, ticketError)
      return
    }

    const currentReferrals = referrer.referrals || []

    const newReferral = {
      telegram_id: newUserData.telegram_id,
      username: newUserData.telegram_username,
      first_name: newUserData.first_name,
      last_name: newUserData.last_name,
      photo_url: newUserData.photo_url,
      joined_at: Date.now(),
      reward_given: true,
    }

    currentReferrals.push(newReferral)

    const { error: referralUpdateError } = await supabase
      .from("wallets")
      .update({
        referrals: currentReferrals,
      })
      .eq("telegram_id", referrerId)

    if (referralUpdateError) {
      console.error(`Error updating referrer referrals - ID: ${referrerId}:`, referralUpdateError)
    } else {
      console.log(`Referral processed successfully - Referrer: ${referrerId}, New User: ${newUserData.telegram_id}`)
    }
  } catch (error) {
    console.error(`Error processing referral for referrer ID: ${referrerId}:`, error)
  }
}

async function getUserByTelegramId(telegramId: string) {
  try {
    console.log(`Fetching user by Telegram ID: ${telegramId}`)
    
    if (!/^\d+$/.test(telegramId)) {
      throw new Error("Invalid Telegram ID: must be a valid integer");
    }

    const { data, error } = await supabase
      .from("wallets")
      .select("*")
      .eq("telegram_id", telegramId)
      .single();

    if (error && error.code !== "PGRST116") {
      throw error;
    }

    if (data) {
      console.log(`User found - ID: ${telegramId}, Username: ${data.telegram_username}`)
    } else {
      console.log(`User not found - ID: ${telegramId}`)
    }

    return data;
  } catch (error) {
    console.error(`Error getting user ID: ${telegramId}:`, error);
    throw error;
  }
}

async function deductBalance(telegramId: string, amount: number) {
  try {
    console.log(`Deducting balance - User ID: ${telegramId}, Amount: ${amount}`)
    
    const { data: newBalance, error } = await supabase
      .rpc('deduct_balance', {
        p_telegram_id: telegramId,
        p_amount: amount
      })

    if (error) throw error

    const { data: user } = await supabase
      .from("wallets")
      .select("*")
      .eq("telegram_id", telegramId)
      .single()

    console.log(`Balance deducted successfully - User ID: ${telegramId}, New Balance: ${user?.balance}`)
    return user
  } catch (error) {
    console.error(`Error deducting balance for user ID: ${telegramId}:`, error)
    throw error
  }
}

async function getTopUsersByBalance() {
  try {
    console.log("Fetching top users by balance")
    const { data, error } = await supabase.rpc('get_top_users_by_balance', {
      limit_count: 50
    });

    if (error) throw error;
    
    console.log(`Retrieved ${data.length} top users by balance`)
    return data;
  } catch (error) {
    console.error("Error getting top users by balance:", error);
    throw error;
  }
}

async function getTopUsersByReferrals() {
  try {
    console.log("Fetching top users by referrals")
    const { data, error } = await supabase.rpc('get_top_users_by_referrals', {
      limit_count: 50
    });

    if (error) throw error;
    
    console.log(`Retrieved ${data.length} top users by referrals`)
    return data;
  } catch (error) {
    console.error("Error getting top users by referrals:", error);
    throw error;
  }
}

async function updateMiningSubscription(telegramId: string, subscriptionData: any) {
  try {
    console.log(`Updating mining subscription - User ID: ${telegramId}, Data: ${JSON.stringify(subscriptionData)}`)
    
    const updatedSubscription = {
      ...subscriptionData
    }

    const { data, error } = await supabase
      .from("wallets")
      .update({ mining_subscription: updatedSubscription })
      .eq("telegram_id", telegramId)
      .select()
      .single()

    if (error) throw error
    
    console.log(`Mining subscription updated successfully - User ID: ${telegramId}`)
    return data
  } catch (error) {
    console.error(`Error updating mining subscription for user ID: ${telegramId}:`, error)
    throw error
  }
}

async function updateMiningUpgrades(telegramId: string, upgradesData: any) {
  try {
    console.log(`Updating mining upgrades - User ID: ${telegramId}, Data: ${JSON.stringify(upgradesData)}`)
    
    const { data, error } = await supabase
      .from("wallets")
      .update({ mining_upgrades: upgradesData })
      .eq("telegram_id", telegramId)
      .select()
      .single()

    if (error) throw error
    
    console.log(`Mining upgrades updated successfully - User ID: ${telegramId}`)
    return data
  } catch (error) {
    console.error(`Error updating mining upgrades for user ID: ${telegramId}:`, error)
    throw error
  }
}

async function updateBalance(telegramId: string, rewardAmount: number) {
  try {
    console.log(`Updating balance - User ID: ${telegramId}, Amount: ${rewardAmount}`)
    
    const { data: newBalance, error } = await supabase
      .rpc('award_reward', {
        p_telegram_id: telegramId,
        p_reward: rewardAmount
      })

    if (error) throw error

    const { data: user } = await supabase
      .from("wallets")
      .select("*")
      .eq("telegram_id", telegramId)
      .single()

    console.log(`Balance updated successfully - User ID: ${telegramId}, New Balance: ${user?.balance}`)
    return user
  } catch (error) {
    console.error(`Error updating balance for user ID: ${telegramId}:`, error)
    throw error
  }
}

async function updateDailyReward(telegramId: string) {
  try {
    console.log(`Updating daily reward - User ID: ${telegramId}`)
    
    const getUTCDateOnlyString = () => {
      const now = new Date();
      return now.toISOString().split('T')[0]; 
    };

    const dateToStore = getUTCDateOnlyString();

    const { data, error } = await supabase
      .from("wallets")
      .update({ 
        last_daily_reward: dateToStore,
        updated_at: new Date().toISOString()
      })
      .eq("telegram_id", telegramId)
      .select()
      .single();

    if (error) {
      throw new Error(`Database error: ${error.message}`);
    }

    if (!data) {
      throw new Error("No data returned after update");
    }

    console.log(`Daily reward updated successfully - User ID: ${telegramId}, Date: ${dateToStore}`)
    return data;
  } catch (error) {
    console.error(`Error updating daily reward for user ID: ${telegramId}:`, error);
    throw error;
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, initData, walletData, miningData, referralId } = body

    console.log(`Received request - Action: ${action}`)

    if (!initData) {
      console.error("Missing initData in request")
      return NextResponse.json({ error: "Missing initData" }, { status: 400 })
    }

    const verification = verifyTelegramWebAppData(initData)
    if (!verification.isValid || !verification.data) {
      console.error("Invalid Telegram data verification")
      return NextResponse.json({ error: "Invalid Telegram data" }, { status: 401 })
    }

    const userData = verification.data
    console.log(`Processing request for user - ID: ${userData.telegram_id}, Username: ${userData.telegram_username}`)

    let extractedReferrerId = null
    if (initData.includes("start_param")) {
      const urlParams = new URLSearchParams(initData)
      const startParam = urlParams.get("start_param")
      if (startParam) {
        extractedReferrerId = startParam
        console.log(`Extracted referrer ID from start_param: ${extractedReferrerId}`)
      }
    }

    switch (action) {
      case "get_or_create_user": {
        console.log(`Action: get_or_create_user - User ID: ${userData.telegram_id}`)
        let user = await getUserByTelegramId(userData.telegram_id)

        if (!user) {
          const finalReferrerId = referralId || extractedReferrerId
          console.log(`Creating new user with referrer ID: ${finalReferrerId || 'None'}`)
          user = await createUser(userData, finalReferrerId)
        }
      
        return NextResponse.json({
          success: true,
          user: {
            id: user.id,
            telegram_id: user.telegram_id,
            telegram_username: user.telegram_username,
            user_photo_url: user.user_photo_url || "",
            balance: user.balance || 0,
            tickets_balance: user.tickets_balance || 0,
            last_daily_reward: user.last_daily_reward || "", 
            isBanned: user.is_banned || false, 
            premium: user.premium || false, 
            completed_tasks: user.completed_tasks || [],
            mining_subscription: user.mining_subscription || {},
            mining_upgrades: user.mining_upgrades || {},
            referrals: user.referrals || []
          },
        })
      }

      case "add_tickets": {
        console.log(`Action: add_tickets - User ID: ${userData.telegram_id}, Amount: ${body.ticketsAmount}`)
        if (body.ticketsAmount === undefined || body.ticketsAmount <= 0) {
          console.error("Invalid tickets amount")
          return NextResponse.json({ error: "Invalid tickets amount" }, { status: 400 });
        }

        const { data: newBalance, error } = await supabase.rpc("update_tickets_balance", {
          p_telegram_id: userData.telegram_id,
          p_tickets_amount: body.ticketsAmount,
        });

        if (error) {
          console.error(`Error adding tickets for user ID: ${userData.telegram_id}:`, error);
          return NextResponse.json({ error: "Failed to add tickets" }, { status: 500 });
        }

        console.log(`Tickets added successfully - User ID: ${userData.telegram_id}, New Balance: ${newBalance}`)
        return NextResponse.json({
          success: true,
          new_tickets_balance: newBalance,
        });
      }

      case "use_ticket": {
        console.log(`Action: use_ticket - User ID: ${userData.telegram_id}`)
        const { data: success, error } = await supabase.rpc("use_ticket", {
          p_telegram_id: userData.telegram_id,
        })

        if (error || !success) {
          console.error(`Error using ticket for user ID: ${userData.telegram_id}:`, error)
          return NextResponse.json({ error: "Insufficient tickets or failed to use ticket" }, { status: 400 })
        }

        console.log(`Ticket used successfully - User ID: ${userData.telegram_id}`)
        return NextResponse.json({
          success: true,
        })
      }
        
      case "get_leaderboard": {
        console.log(`Action: get_leaderboard - Type: ${body.leaderboardType}`)
        const leaderboardType = body.leaderboardType;
        
        if (leaderboardType === 'balance') {
          const topUsers = await getTopUsersByBalance();
          return NextResponse.json({
            success: true,
            leaderboard: topUsers,
            type: 'balance'
          });
        } else if (leaderboardType === 'referrals') {
          const topUsers = await getTopUsersByReferrals();
          return NextResponse.json({
            success: true,
            leaderboard: topUsers,
            type: 'referrals'
          });
        } else {
          console.error("Invalid leaderboard type")
          return NextResponse.json({ error: "Invalid leaderboard type" }, { status: 400 });
        }
      }

      case "claim_daily_reward": {
        console.log(`Action: claim_daily_reward - User ID: ${userData.telegram_id}, Double: ${body.double}`)
        const user = await getUserByTelegramId(userData.telegram_id);
        if (!user) {
          console.error(`User not found - ID: ${userData.telegram_id}`)
          return NextResponse.json({ error: "User not found" }, { status: 404 });
        }
        
        const isSameUTCDay = (date1: Date, date2: Date) => {
          return (
            date1.getUTCFullYear() === date2.getUTCFullYear() &&
            date1.getUTCMonth() === date2.getUTCMonth() &&
            date1.getUTCDate() === date2.getUTCDate()
          );
        };
        
        const today = new Date();
        const todayUTC = new Date(Date.UTC(
          today.getUTCFullYear(),
          today.getUTCMonth(),
          today.getUTCDate()
        ));
        
        const lastClaimed = user.last_daily_reward 
          ? new Date(user.last_daily_reward) 
          : null;

        if (lastClaimed && isSameUTCDay(lastClaimed, todayUTC)) {
          console.error(`Daily reward already claimed today - User ID: ${userData.telegram_id}`)
          return NextResponse.json({ error: "Daily reward already claimed" }, { status: 400 });
        }

        const shouldDouble = body.double === true;
        const baseReward = shouldDouble ? 1000 : 500;

        const updatedUser = await updateBalance(userData.telegram_id, baseReward);
        await updateDailyReward(userData.telegram_id);

        console.log(`Daily reward claimed successfully - User ID: ${userData.telegram_id}, Reward: ${baseReward}`)
        return NextResponse.json({
          success: true,
          reward: baseReward,
          new_balance: updatedUser.balance,
        });
      }
        
      case "update_mining_subscription": {
        console.log(`Action: update_mining_subscription - User ID: ${userData.telegram_id}`)
        if (!miningData) {
          console.error("Missing mining data")
          return NextResponse.json({ error: "Missing mining data" }, { status: 400 })
        }

        const subscriptionData = {
          ...miningData
        }

        const updatedUser = await updateMiningSubscription(userData.telegram_id, subscriptionData)

        return NextResponse.json({
          success: true,
          mining_subscription: updatedUser.mining_subscription,
        })
      }

      case "update_mining_upgrades": {
        console.log(`Action: update_mining_upgrades - User ID: ${userData.telegram_id}`)
        if (!miningData) {
          console.error("Missing mining data")
          return NextResponse.json({ error: "Missing mining data" }, { status: 400 })
        }

        const updatedUser = await updateMiningUpgrades(userData.telegram_id, miningData)

        return NextResponse.json({
          success: true,
          mining_upgrades: updatedUser.mining_upgrades,
        })
      }

      case "update_balance": {
        console.log(`Action: update_balance - User ID: ${userData.telegram_id}, Amount: ${miningData?.newBalance}`)
        if (miningData?.newBalance === undefined) {
          console.error("Missing balance data")
          return NextResponse.json({ error: "Missing balance data" }, { status: 400 })
        }

        const updatedUser = await updateBalance(userData.telegram_id, miningData.newBalance)

        return NextResponse.json({
          success: true,
          balance: updatedUser.balance,
        })
      }

      case "check_ban_status": {
        console.log(`Action: check_ban_status - User ID: ${userData.telegram_id}`)
        const user = await getUserByTelegramId(userData.telegram_id);
        if (!user) {
          console.log(`User not found - ID: ${userData.telegram_id}, returning not banned`)
          return NextResponse.json({
            success: true,
            isBanned: false
          });
        }

        console.log(`Ban status checked - User ID: ${userData.telegram_id}, IsBanned: ${user.is_banned || false}`)
        return NextResponse.json({
          success: true,
          isBanned: user.is_banned || false
        });
      }

      case "claim_mining_reward": {
       console.log(`Action: claim_mining_reward - User ID: ${userData.telegram_id}`)
       try {
        const user = await getUserByTelegramId(userData.telegram_id)
         if (!user) {
             console.error(`User not found - ID: ${userData.telegram_id}`)
             return NextResponse.json({ error: "User not found" }, { status: 404 })
         }

         const subscription = user.mining_subscription || {}
         const upgrades = user.mining_upgrades || {}

         if (!subscription.isActive) {
             console.error(`No active mining subscription - User ID: ${userData.telegram_id}`)
             return NextResponse.json({ error: "No active mining subscription" }, { status: 400 })
         }
        
         const lastClaimTime = subscription.lastClaimTime || subscription.startTime
         const isPremium = subscription.plan === 'premium'
         const baseMiningDuration = isPremium ? 8 : 12 // ساعات
         const miningDurationHours = Math.max(1, baseMiningDuration - (upgrades.timeReduction || 0)) // لا تقل عن ساعة واحدة
         const miningDurationMs = miningDurationHours * 60 * 60 * 1000

         const now = Date.now()
         if (now - lastClaimTime < miningDurationMs) {
             const remainingTime = miningDurationMs - (now - lastClaimTime)
             console.error(`Mining not ready yet - User ID: ${userData.telegram_id}, Remaining: ${remainingTime}ms`)
             return NextResponse.json({ 
                 error: "Mining not ready yet",
                 remaining_time: remainingTime
             }, { status: 400 })
         }

         const baseReward = isPremium ? 20000 : 5000
         const rateMultiplier = 1 + (upgrades.rateBoost || 0) * 1
         const reward = Math.floor(baseReward * rateMultiplier)

         const [updatedUser] = await Promise.all([
             updateBalance(userData.telegram_id, reward),
             updateMiningSubscription(userData.telegram_id, {
                 ...subscription,
                 lastClaimTime: now,
             })
         ])

         console.log(`Mining reward claimed successfully - User ID: ${userData.telegram_id}, Reward: ${reward}`)
        
         return NextResponse.json({
            success: true,
            reward,
            base_reward: baseReward,
            rate_multiplier: rateMultiplier,
            mining_duration_hours: miningDurationHours,
            new_balance: updatedUser.balance,
            next_claim_time: now + miningDurationMs,
            upgrades_applied: {
                time_reduction: upgrades.timeReduction || 0,
                rate_boost: upgrades.rateBoost || 0
            }
        })

        } catch (error) {
          console.error(`Error in claim_mining_reward for user ${userData.telegram_id}:`, error)
          return NextResponse.json({ 
             error: "Internal server error",
             details: error instanceof Error ? error.message : String(error)
          }, { status: 500 })
        }
      }

      case "complete_task": {
        console.log(`Action: complete_task - User ID: ${userData.telegram_id}, Task ID: ${body.taskId}, Reward: ${body.rewardAmount}`)
        if (!body.taskId || body.rewardAmount === undefined) {
          console.error("Missing task data")
          return NextResponse.json({ error: "Missing task data" }, { status: 400 })
        }

        const user = await getUserByTelegramId(userData.telegram_id)
        if (!user) {
          console.error(`User not found - ID: ${userData.telegram_id}`)
          return NextResponse.json({ error: "User not found" }, { status: 404 })
        }

        const completedTasks = user.completed_tasks || []
        const updatedTasks = completedTasks.map((t: any) => 
          t.taskId === body.taskId ? { ...t, completed: true, completedAt: new Date().toISOString() } : t
        )

        const updatedUser = await updateBalance(userData.telegram_id, body.rewardAmount)

        const { data: task, error: taskError } = await supabase
          .from("tasks")
          .select("*")
          .eq("id", body.taskId)
          .single()

        if (!taskError && task) {
          await supabase
            .from("tasks")
            .update({ completed_count: (task.completed_count || 0) + 1 })
            .eq("id", body.taskId)
        }

        const { error: updateError } = await supabase
          .from("wallets")
          .update({ 
            completed_tasks: updatedTasks
          })
          .eq("telegram_id", userData.telegram_id)

        if (updateError) throw updateError

        console.log(`Task completed successfully - User ID: ${userData.telegram_id}, Task ID: ${body.taskId}`)
        return NextResponse.json({
          success: true,
          user: {
            ...updatedUser,
            completed_tasks: updatedTasks
          },
        })
      }

      case "start_task": {
        console.log(`Action: start_task - User ID: ${userData.telegram_id}, Task ID: ${body.taskId}`)
        if (!body.taskId) {
          console.error("Missing task ID")
          return NextResponse.json({ error: "Missing task ID" }, { status: 400 })
        }

        const user = await getUserByTelegramId(userData.telegram_id)
        if (!user) {
          console.error(`User not found - ID: ${userData.telegram_id}`)
          return NextResponse.json({ error: "User not found" }, { status: 404 })
        }

        const completedTasks = user.completed_tasks || []
        
        if (!completedTasks.some((t: any) => t.taskId === body.taskId)) {
          completedTasks.push({
            taskId: body.taskId,
            completed: false,
            startedAt: new Date().toISOString()
          })
        }

        const { data: updatedUser, error: updateError } = await supabase
          .from("wallets")
          .update({ completed_tasks: completedTasks })
          .eq("telegram_id", userData.telegram_id)
          .select()
          .single()

        if (updateError) throw updateError

        console.log(`Task started successfully - User ID: ${userData.telegram_id}, Task ID: ${body.taskId}`)
        return NextResponse.json({
          success: true,
          user: updatedUser,
        })
      }

      case "deduct_balance": {
        console.log(`Action: deduct_balance - User ID: ${userData.telegram_id}, Amount: ${body.amount}`)
        if (typeof body.amount !== "number" || body.amount <= 0) {
          console.error("Invalid amount")
          return NextResponse.json({ error: "Invalid amount" }, { status: 400 })
        }

        try {
          const updatedUser = await deductBalance(userData.telegram_id, body.amount)

          return NextResponse.json({
            success: true,
            balance: updatedUser.balance,
          })
        } catch (error) {
          console.error(`Error deducting balance for user ID: ${userData.telegram_id}:`, error)
          return NextResponse.json({ error: "Failed to deduct balance" }, { status: 500 })
        }
      }

      case "update_premium_status": {
        console.log(`Action: update_premium_status - User ID: ${userData.telegram_id}, Status: ${body.premiumStatus}`)
        if (typeof body.premiumStatus !== 'boolean') {
          console.error("Missing or invalid premium status")
          return NextResponse.json({ error: "Missing or invalid premium status" }, { status: 400 });
        }
        
        const { data, error } = await supabase
          .rpc('update_premium_status', {
            p_telegram_id: userData.telegram_id,
            p_premium_status: body.premiumStatus
          });

        if (error) {
          console.error(`Error updating premium status for user ID: ${userData.telegram_id}:`, error);
          return NextResponse.json({ error: "Failed to update premium status" }, { status: 500 });
        }
        
        const updatedUser = await getUserByTelegramId(userData.telegram_id);
        if (!updatedUser) {
          console.error(`User not found after update - ID: ${userData.telegram_id}`)
          return NextResponse.json({ error: "User not found after update" }, { status: 404 });
        }
        
        console.log(`Premium status updated successfully - User ID: ${userData.telegram_id}, New Status: ${updatedUser.premium || false}`)
        return NextResponse.json({
          success: true,
          premium: updatedUser.premium || false
        });
      }

      case "start_static_task": {
        console.log(`Action: start_static_task - User ID: ${userData.telegram_id}, Task ID: ${body.taskId}`)
  
        if (!body.taskId) {
         return NextResponse.json({ error: "Missing task ID" }, { status: 400 })
        }

        const user = await getUserByTelegramId(userData.telegram_id)
          if (!user) {
          return NextResponse.json({ error: "User not found" }, { status: 404 })
         }
 
         const completedTasks = user.completed_tasks || []
  
         if (!completedTasks.some((t: any) => t.taskId === body.taskId)) {
         completedTasks.push({
          taskId: body.taskId,
          completed: false,
          startedAt: new Date().toISOString()
        })
      }

       const { data: updatedUser, error: updateError } = await supabase
        .from("wallets")
        .update({ completed_tasks: completedTasks })
        .eq("telegram_id", userData.telegram_id)
        .select()
        .single()

        if (updateError) throw updateError

        return NextResponse.json({
          success: true,
          user: updatedUser,
       })
     }

     case "complete_static_task": {
        console.log(`Action: complete_static_task - User ID: ${userData.telegram_id}, Task ID: ${body.taskId}, Reward: ${body.rewardAmount}`)
   
       if (!body.taskId || body.rewardAmount === undefined) {
        return NextResponse.json({ error: "Missing task data" }, { status: 400 })
       }

        const user = await getUserByTelegramId(userData.telegram_id)
         if (!user) {
          return NextResponse.json({ error: "User not found" }, { status: 404 })
        }

         const completedTasks = user.completed_tasks || []
         const updatedTasks = completedTasks.map((t: any) => 
           t.taskId === body.taskId ? { ...t, completed: true, completedAt: new Date().toISOString() } : t
         )

         const updatedUser = await updateBalance(userData.telegram_id, body.rewardAmount)

         const { error: updateError } = await supabase
          .from("wallets")
          .update({ 
           completed_tasks: updatedTasks
          })
           .eq("telegram_id", userData.telegram_id)

           if (updateError) throw updateError

           return NextResponse.json({
            success: true,
            user: {
            ...updatedUser,
            completed_tasks: updatedTasks
         },
        })
       }

      default:
        console.error(`Invalid action: ${action}`)
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }
  } catch (error) {
    console.error(`User API error for action: ${action}:`, error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

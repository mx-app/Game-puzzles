import { type NextRequest, NextResponse } from "next/server"
import { APP_ICON } from "@/lib/config"

export const dynamic = "force-dynamic"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { amount, label, description } = body

    if (!amount || !label || !description) {
      console.error("Missing required fields")
      return NextResponse.json({ error: "Missing required fields: amount, label, description" }, { status: 400 })
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN
    if (!botToken) {
      console.error("TELEGRAM_BOT_TOKEN environment variable not configured")
      return NextResponse.json({ error: "Server configuration error" }, { status: 500 })
    }

    const response = await fetch(`https://api.telegram.org/bot${botToken}/createInvoiceLink`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: `${label}`,
        description: description,
        payload: JSON.stringify({ service: "Game" }),
        provider_token: "", 
        currency: "XTR",
        prices: [{ amount: amount, label: label }],
        photo_url: APP_ICON,
        photo_width: 600,
        photo_height: 400,
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("Telegram API request failed:", errorData.description || errorData)
      return NextResponse.json({ error: "Payment service unavailable. Please try again later." }, { status: 502 })
    }

    const { result: invoiceLink } = await response.json()
    return NextResponse.json({ invoiceLink })
  } catch (error) {
    console.error("Unexpected error during invoice creation:", error)
    return NextResponse.json({ error: "Internal server error. Contact support if issue persists." }, { status: 500 })
  }
}

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 204,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Max-Age": "86400",
    },
  })
}

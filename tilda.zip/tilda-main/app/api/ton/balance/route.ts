import { type NextRequest, NextResponse } from "next/server"

const TONAPI_KEY = "AHV2RR4FNB73GWYAAAAFH2D3SGOVLDRFF6EWEQUO6NBVOVH23WV32QG5BHZJMWVJYZ6MZNI"
const TONAPI_ENDPOINT = "https://tonapi.io/v2/accounts"
const TONCENTER_ENDPOINT = "https://toncenter.com/api/v2/getAddressInformation"
const CHAINSTACK_ENDPOINT = "https://ton-mainnet.core.chainstack.com/92afb4db0b7d52781bb4a904278e93da/api/v2/getAddressInformation"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const address = searchParams.get("address")

    if (!address) {
      return NextResponse.json({ error: "Wallet address is required" }, { status: 400 })
    }

    let data
    let source = "tonapi"

    try {
      const response = await fetch(`${TONAPI_ENDPOINT}/${address}`, {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${TONAPI_KEY}`,
        },
      })

      if (!response.ok) {
        throw new Error(`TON API error: ${response.statusText}`)
      }

      data = await response.json()
    } catch (tonapiError) {
      console.error("Error using Tonapi, falling back to Toncenter:", tonapiError)
      source = "toncenter"
      
      try {
        const toncenterResponse = await fetch(`${TONCENTER_ENDPOINT}?address=${address}`, {
          headers: {
            Accept: "application/json",
          },
        })

        if (!toncenterResponse.ok) {
          throw new Error(`Toncenter error: ${toncenterResponse.statusText}`)
        }

        const toncenterData = await toncenterResponse.json()
    
        data = {
          balance: toncenterData.result.balance,
          status: toncenterData.result.status,
          last_activity: toncenterData.result.last_activity,
        }
      } catch (toncenterError) {
        console.error("Error using Toncenter, falling back to Chainstack:", toncenterError)
        source = "chainstack"
        
        const chainstackResponse = await fetch(`${CHAINSTACK_ENDPOINT}?address=${address}`, {
          headers: {
            Accept: "application/json",
          },
        })

        if (!chainstackResponse.ok) {
          throw new Error(`Chainstack error: ${chainstackResponse.statusText}`)
        }

        const chainstackData = await chainstackResponse.json()
    
        data = {
          balance: chainstackData.result.balance,
          status: chainstackData.result.status,
          last_activity: chainstackData.result.last_activity,
        }
      }
    }

    const tonBalance = (data.balance || 0) / 1_000_000_000

    return NextResponse.json({
      balance: tonBalance,
      status: data.status,
      last_activity: data.last_activity,
      data_source: source
    })
  } catch (error) {
    console.error("Error in get-balance route:", error)
    return NextResponse.json({ error: "Failed to fetch wallet balance from all available sources" }, { status: 500 })
  }
}

import { type NextRequest, NextResponse } from "next/server";

const TONAPI_KEY = "AHV2RR4FNB73GWYAAAAFH2D3SGOVLDRFF6EWEQUO6NBVOVH23WV32QG5BHZJMWVJYZ6MZNI"
const TIMEOUT_MS     = 3000;
let   cachePrice     = 0;    

const providers = [
  {
    name: "TonAPI",
    url: "https://tonapi.io/v2/rates?tokens=ton&currencies=usd",
    headers: { Accept: "application/json", Authorization: `Bearer ${TONAPI_KEY}` },
    extractor: (json: any) => json.rates?.TON?.prices?.USD,
  },
  {
    name: "CoinGecko",
    url: "https://api.coingecko.com/api/v3/simple/price?ids=the-open-network&vs_currencies=usd",
    extractor: (json: any) => json["the-open-network"]?.usd,
  },
  {
    name: "Binance",
    url: "https://api.binance.com/api/v3/ticker/price?symbol=TONUSDT",
    extractor: (json: any) => Number(json.price),
  },
  {
    name: "CryptoCompare",
    url: "https://min-api.cryptocompare.com/data/price?fsym=TON&tsyms=USD",
    extractor: (json: any) => json.USD,
  },
  {
    name: "MEXC",
    url: "https://api.mexc.com/api/v3/ticker/price?symbol=TONUSDT",
    extractor: (json: any) => Number(json.price),
  },
];

async function fetchWithTimeout(url: string, opt?: RequestInit) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { ...opt, signal: controller.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(id);
  }
}

export async function GET(_req: NextRequest) {
  try {
    const price = await Promise.any(
      providers.map(async (p) => {
        const data = await fetchWithTimeout(p.url, { headers: p.headers });
        const value = p.extractor(data);
        if (!value || isNaN(value)) throw new Error(`${p.name}: invalid`);
        return Number(value);
      }),
    );

    cachePrice = price;
    return NextResponse.json({ success: true, price });
  } catch (err) {
    console.error("All providers failed:", err);
    return NextResponse.json({
      success: cachePrice > 0,
      price: cachePrice,
      warning: "Returned cached price; live fetch failed",
    });
  }
}

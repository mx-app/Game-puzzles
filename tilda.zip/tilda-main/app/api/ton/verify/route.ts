import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const sender = searchParams.get("sender")
  const amount = searchParams.get("amount")

  if (!sender || !amount) {
    return NextResponse.json({ 
      success: false, 
      error: "Sender أو Amount مفقود" 
    }, { status: 400 })
  }

  try {
    const res = await fetch(`https://check-ton.vercel.app/api/verify-payment?sender=${encodeURIComponent(sender)}&amount=${amount}`)
    const data = await res.json()
    return NextResponse.json(data)
  } catch (err: any) {
    return NextResponse.json({ 
      success: false, 
      error: err.message 
    }, { status: 500 })
  }
}

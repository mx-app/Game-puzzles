import { type NextRequest, NextResponse } from "next/server"
import { CHANNEL_USERNAME } from "@/lib/config"

export const dynamic = "force-dynamic"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { user_id } = body

    if (!user_id) {
      return NextResponse.json({ error: "Missing user_id" }, { status: 400 })
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN
    if (!botToken) {
      return NextResponse.json({ error: "Bot token not configured" }, { status: 500 })
    }

    const apiUrl = `https://api.telegram.org/bot${botToken}/getChatMember?chat_id=${encodeURIComponent(
      CHANNEL_USERNAME
    )}&user_id=${user_id}`

    const tgRes = await fetch(apiUrl)
    const data = await tgRes.json()

    if (!data.ok) {
      console.error("Telegram API Error:", data.description || data)
      return NextResponse.json(
        { error: "Failed to check membership", telegramError: data.description || data },
        { status: 400 }
      )
    }

    return NextResponse.json({
      user_id,
      status: data.result.status,
      user: data.result.user,
    })
  } catch (error) {
    console.error("Unexpected error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 204,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Max-Age": "86400",
    },
  })
}

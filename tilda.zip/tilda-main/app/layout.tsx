import type { Metadata } from "next"
import "./globals.css"
import ClientContent from "@/components/client-content"
import { Providers } from "./providers"
import { PrefetchRoutes } from "@/components/prefetch-routes"
import { SIMPLE, NAME } from "@/lib/config"

export const metadata: Metadata = {
  title: NAME,
  description: "Turn your phone and time into real value and win with us what you deserve",
  generator: "Mr. M",
  icons: {
    icon: "/logo.svg",
  },
}

export const viewport = {
  width: "device-width",
  initialScale: 1.0,
  maximumScale: 1.0,
  userScalable: false,
}

const telegramAnalyticsInit = `
  window.addEventListener("load", function () {
    if (window.telegramAnalytics) {
      window.telegramAnalytics.init({
        token: 'eyJhcHBfbmFtZSI6InRpbGRhIiwiYXBwX3VybCI6Imh0dHBzOi8vdC5tZS9UaWxkYUFwcEJvdCIsImFwcF9kb21haW4iOiJodHRwczovL3RpbGRhLm1yLW0ueHl6In0=!MnZM4l+HWNowhq17a1CKQ645vjgVe5dn0umBTXIvKbU=',
        appName: 'tilda'
      });
    }
  });
`

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap"
          rel="stylesheet"
        />
        <meta name="robots" content="noindex, nofollow" />
        <meta httpEquiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
        <meta httpEquiv="Pragma" content="no-cache" />
      
        <script src="https://tganalytics.xyz/index.js" async></script>
        <script dangerouslySetInnerHTML={{ __html: telegramAnalyticsInit }} />
        <script src="https://telegram.org/js/telegram-web-app.js"></script>
      </head>
      <body className="font-inter">
        <Providers>
          <ClientContent>
            {children}
          </ClientContent>
         <PrefetchRoutes />
        </Providers>
      </body>
    </html>
  )
}

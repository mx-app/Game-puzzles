"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { AppLayout } from "@/components/app-layout"
import { useToast } from "@/components/ui/use-toast"
import { FaTasks, FaCheckCircle, FaExternalLinkAlt, FaSpinner, FaTelegram, FaCoins, FaUsers, FaWallet, FaExchangeAlt, FaTelegramPlane, FaTicketAlt } from "react-icons/fa"
import { LuPickaxe, LuLoaderCircle } from "react-icons/lu"
import Image from "next/image"
import { motion } from "framer-motion"
import { useTonAddress, useTonConnectUI } from "@tonconnect/ui-react"
import { WALLET_ADDRESS } from "@/lib/wallet-config"
import { walletService } from "@/lib/wallet-service"
import { Skeleton } from "@/components/ui/skeleton"
import { formatBalance } from "@/lib/utils"

type AirdropTask = {
  id: string
  title: string
  reward_amount: number
  completed: boolean
  locked: boolean
  progress?: {
    current: number
    target: number
  }
  action?: () => Promise<void>
  requiresCompletion?: boolean
  icon: JSX.Element
}

export default function AirdropPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [tonConnectUI] = useTonConnectUI()
  const userAddress = useTonAddress()
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [tasks, setTasks] = useState<AirdropTask[]>([])
  const [processingTasks, setProcessingTasks] = useState<Record<string, boolean>>({})
  const [walletBalance, setWalletBalance] = useState("0")

  const fetchUserData = useCallback(async () => {
    try {
      if (typeof window === "undefined" || !window.Telegram?.WebApp?.initData) {
        return
      }

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_or_create_user",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setUser(data.user)
        initializeTasks(data.user)
      }
    } catch (error) {
      console.error("Error fetching user data:", error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUserData()
  }, [fetchUserData])

  useEffect(() => {
    const fetchWalletBalance = async () => {
      if (!userAddress) {
        setWalletBalance("0")
        return
      }

      try {
        const balanceData = await walletService.checkTonWalletBalance(userAddress)
        if (balanceData.success) {
          setWalletBalance(balanceData.balance)
        } else {
          console.error("Failed to fetch wallet balance:", balanceData.error)
          setWalletBalance("0")
        }
      } catch (error) {
        console.error("Error fetching wallet balance:", error)
        setWalletBalance("0")
      }
    }

    fetchWalletBalance()
  }, [userAddress])

  const initializeTasks = (userData: any) => {
    const completedTasks = userData.completed_tasks || []
    const isTaskCompleted = (taskId: string) => {
      return completedTasks.some((t: any) => t.taskId === taskId && t.completed)
    }

    const taskOrder = [
      "airdrop_balance_task",
      "airdrop_tickets_task", 
      "airdrop_referral_task", 
      "airdrop_transaction_task",
      "airdrop_channel_task"
    ]

    const newTasks: AirdropTask[] = [
      {
        id: "airdrop_balance_task",
        title: "Hold 100.0K TP",
        reward_amount: 0,
        completed: isTaskCompleted("airdrop_balance_task"),
        locked: false,
        requiresCompletion: true,
        progress: {
          current: Math.min(userData.balance || 0, 100000),
          target: 100000
        },
        icon: <FaCoins className="w-4 h-4 text-tp" />
      },
      {
        id: "airdrop_referral_task",
        title: "Invite 1 Friend",
        reward_amount: 0,
        completed: isTaskCompleted("airdrop_referral_task"),
        locked: !isTaskCompleted("airdrop_balance_task"),
        requiresCompletion: true,
        progress: {
          current: Math.min(userData.referrals?.length || 0, 1),
          target: 1
        },
        icon: <FaUsers className="w-4 h-4 text-tp" />
      },
      {
        id: "airdrop_tickets_task",
        title: "Own 5 Tickets",
        reward_amount: 0,
        completed: isTaskCompleted("airdrop_tickets_task"),
        locked: !isTaskCompleted("airdrop_referral_task"),
        requiresCompletion: true,
        progress: {
          current: Math.min(userData.tickets_balance || 0, 5),
          target: 5
        },
        icon: <FaTicketAlt className="w-4 h-4 text-tp" />
      },
      {
        id: "airdrop_transaction_task",
        title: "Send Transaction",
        reward_amount: 0,
        completed: isTaskCompleted("airdrop_transaction_task"),
        locked: !isTaskCompleted("airdrop_tickets_task"),
        action: async () => {
          if (!userAddress) {
            toast({
              title: "Wallet not connected",
              description: "Please connect your wallet first",
              variant: "destructive",
            })
            await tonConnectUI.openModal()
            return
          }

          try {
            const tonAmount = BigInt(1 * 1000000000)
            const result = await tonConnectUI.sendTransaction({
              validUntil: Math.floor(Date.now() / 1000) + 600,
              messages: [
                {
                  address: WALLET_ADDRESS,
                  amount: tonAmount.toString(),
                },
              ],
            })

            if (!result?.boc) {
              throw new Error("Transaction failed")
            }

            await completeTask("airdrop_transaction_task")
          } catch (error) {
            console.error("Transaction error:", error)
            toast({
              title: "Transaction failed",
              description: error instanceof Error ? error.message : "Please try again",
              variant: "destructive",
            })
          }
        },
        icon: <FaExchangeAlt className="w-4 h-4 text-tp" />
      }, 
      {
        id: "airdrop_channel_task",
        title: "Join Telegram Channel",
        reward_amount: 0,
        completed: isTaskCompleted("airdrop_channel_task"),
        locked: !isTaskCompleted("airdrop_transaction_task"),
        action: async () => {
          try {
            const response = await fetch("/api/verify-joining-channel", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                user_id: userData.telegram_id,
              }),
            })

            if (!response.ok) {
              throw new Error("Failed to verify channel membership")
            }

            const data = await response.json()
            if (data.status === "member" || data.status === "administrator" || data.status === "creator") {
              await completeTask("airdrop_channel_task")
              toast({
                title: "Verification successful",
                description: "You've successfully joined our channel!",
              })
            } else {
              toast({
                title: "Not a member",
                description: "Please join our Telegram channel first",
                variant: "destructive",
              })
              window.open(`https://t.me/TP_Farming`, "_blank")
            }
          } catch (error) {
            console.error("Verification error:", error)
            toast({
              title: "Verification failed",
              description: error instanceof Error ? error.message : "Please try again",
              variant: "destructive",
            })
          }
        },
        icon: <FaTelegramPlane className="w-4 h-4 text-tp" />
      }
    ]

    const sortedTasks = taskOrder.map(taskId => 
      newTasks.find(task => task.id === taskId)!
    )

    setTasks(sortedTasks)
  }

  const startTask = async (taskId: string) => {
    try {
      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "start_static_task",
          initData: window.Telegram.WebApp.initData,
          taskId: taskId,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to start task")
      }

      const data = await response.json()
      setUser(data.user)
    } catch (error) {
      console.error("Error starting task:", error)
      toast({
        title: "Error",
        description: "Failed to start task",
        variant: "destructive",
      })
    }
  }

  const completeTask = async (taskId: string) => {
    setProcessingTasks(prev => ({ ...prev, [taskId]: true }))
    
    try {
      await startTask(taskId)

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "complete_static_task",
          initData: window.Telegram.WebApp.initData,
          taskId: taskId,
          rewardAmount: 0,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to complete task")
      }

      const data = await response.json()
      setUser(data.user)

      setTasks(prev => prev.map(task => 
        task.id === taskId ? { ...task, completed: true } : task
      ))
      
      const currentIndex = tasks.findIndex(t => t.id === taskId)
      if (currentIndex < tasks.length - 1) {
        setTasks(prev => prev.map((task, index) => 
          index === currentIndex + 1 ? { ...task, locked: false } : task
        ))
      }
    } catch (error) {
      console.error("Error completing task:", error)
      toast({
        title: "Error",
        description: "Failed to complete task",
        variant: "destructive",
      })
    } finally {
      setProcessingTasks(prev => ({ ...prev, [taskId]: false }))
    }
  }

  const handleTaskAction = async (task: AirdropTask) => {
    if (task.completed || task.locked) return

    if (task.requiresCompletion && task.progress && task.progress.current < task.progress.target) {
      return
    }

    setProcessingTasks(prev => ({ ...prev, [task.id]: true }))

    try {
      if (task.action) {
        await task.action()
      } else {
        await completeTask(task.id)
      }
    } finally {
      setProcessingTasks(prev => ({ ...prev, [task.id]: false }))
    }
  }

  const renderProgressBar = (current: number, target: number) => {
    const percentage = Math.min(100, (current / target) * 100)
    return (
      <div className="w-full bg-[#1A1A1A] rounded-full h-1.5 mt-2">
        <div 
          className="bg-[#ff6b35] h-1.5 rounded-full" 
          style={{ width: `${percentage}%` }}
        />
      </div>
    )
  }
  
  const renderTaskButton = (task: AirdropTask) => {
    if (task.completed) {
      return (
        <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-green-500/10">
          <FaCheckCircle className="w-4 h-4 text-green-400" />
        </div>
      )
    }

    if (task.locked) {
      return (
        <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-[#1A1A1A]">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            width="16" 
            height="16" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
            className="text-[#a0a0a0]"
          >
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
          </svg>
        </div>
      )
    }

    const isProcessing = processingTasks[task.id]
    const isDisabled = task.requiresCompletion && task.progress && task.progress.current < task.progress.target

    return (
      <Button 
        className={`w-auto h-8 px-3 ${isDisabled ? 'dark-bg text-[#a0a0a0]' : 'fire-gradient'} rounded-lg`}
        onClick={() => handleTaskAction(task)}
        disabled={isProcessing || isDisabled}
      >
        {isProcessing ? (
          <FaSpinner className="w-4 h-4 animate-spin text-white" />
        ) : (
          <>
            {task.id === "airdrop_transaction_task" && "Send"}
            {task.id === "airdrop_channel_task" && "Verify"}
            {(task.id === "airdrop_balance_task" || task.id === "airdrop_referral_task" || task.id === "airdrop_tickets_task") && 
              (task.progress?.current >= task.progress?.target ? "Done" : `${formatBalance(task.progress.current)}/${formatBalance(task.progress.target)}`)}
          </>
        )}
      </Button>
    )
  }

  const renderSkeletonLoader = () => (
    <Card className="dark-bg rounded-2xl overflow-hidden">
      {[...Array(5)].map((_, index) => (
        <div key={index}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Skeleton className="w-8 h-8 rounded-lg bg-[#2a2a2a]" />
                <Skeleton className="w-32 h-4 rounded-lg bg-[#2a2a2a]" />
              </div>
              <Skeleton className="w-8 h-8 rounded-lg bg-[#2a2a2a]" />
            </div>
          </CardContent>
          {index < 4 && <div className="border-t border-[#2a2a2a] mx-4" />}
        </div>
      ))}
    </Card>
  )

  const renderTaskItem = (task: AirdropTask, index: number) => (
    <div key={task.id}>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: task.locked ? 0.5 : 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className={`flex items-center justify-between p-4 min-h-[80px] ${task.locked ? 'opacity-50' : ''}`}
      >
        <div className="flex items-center space-x-3 flex-1">
          <div className="w-8 h-8 rounded-lg dark-bg flex items-center justify-center flex-shrink-0">
            {task.icon}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className={`text-sm font-medium ${task.completed ? 'text-green-400' : 'fire-text'} truncate`}>
              {task.title}
            </h3>
            {task.progress && (
              <div className="mt-1">
                <div className="text-xs text-[#a0a0a0]">
                 {formatBalance(task.progress.current)}/{formatBalance(task.progress.target)}
                </div>
                {renderProgressBar(task.progress.current, task.progress.target)}
              </div>
            )}
          </div>
        </div>
        <div className="ml-3 flex-shrink-0">
          {renderTaskButton(task)}
        </div>
      </motion.div>
      {index < tasks.length - 1 && <div className="border-t border-[#1A1A1A] mx-4" />}
    </div>
  )

  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full">
        <div className="pb-20 pt-4 w-[90%] mx-auto max-w-md">
          <div className="text-center mb-4">
            <h1 className="text-2xl font-bold fire-text mb-1">Airdrop</h1>
            <div className="flex justify-center items-center space-x-2">
              <FaTasks className="w-4 h-4 text-tp" />
              <span className="text-[#a0a0a0] text-sm">
                Complete tasks to qualify for the airdrop
              </span>
            </div>
          </div>

          {isLoading ? (
            renderSkeletonLoader()
          ) : (
            <Card className="dark-bg rounded-2xl overflow-hidden">
              {tasks.map((task, index) => renderTaskItem(task, index))}
            </Card>
          )}

          <div className="mt-4 dark-bg rounded-2xl p-4">
            <h3 className="fire-text font-semibold mb-3">About Airdrop</h3>
            <p className="text-xs text-[#a0a0a0] mb-3">
              Complete all tasks in sequence to qualify for the upcoming airdrop. 
              Each task must be fully completed before moving to the next one.
            </p>
            <ul className="text-xs text-[#a0a0a0] space-y-2">
              <li className="flex items-start">
                <span className="text-tp mr-2">•</span>
                <span>Tasks must be completed in the specified order</span>
              </li>
              <li className="flex items-start">
                <span className="text-tp mr-2">•</span>
                <span>Progress is tracked automatically</span>
              </li>
              <li className="flex items-start">
                <span className="text-tp mr-2">•</span>
                <span>You'll be notified when the airdrop is distributed</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}

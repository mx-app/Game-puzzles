"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"
import {
  FaArrowLeft,
  FaUser,
  FaCoins,
  FaBan,
  FaCrown,
  FaTicketAlt,
  FaGem,
  FaUsers,
  FaSave,
  FaPlus,
  FaTrash,
  FaTasks,
} from "react-icons/fa"
import { formatNumber } from "@/lib/utils"
import { motion } from "framer-motion"

interface User {
  id: string
  telegram_id: string
  telegram_username: string
  user_photo_url: string
  balance: number
  tickets_balance: number
  is_banned: boolean
  premium: boolean
  created_at: string
  updated_at: string
  referrals: any[]
  mining_subscription: {
    isActive: boolean
    plan: 'free' | 'premium'
    startTime: number
    lastClaimTime: number
  } | null
  mining_upgrades: any
  completed_tasks: any[]
  last_daily_reward: string
}

export default function AdminUserDetails() {
  const router = useRouter()
  const params = useParams()
  const { toast } = useToast()

  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [adminPassword, setAdminPassword] = useState("")
  const [balance, setBalance] = useState(0)
  const [ticketsBalance, setTicketsBalance] = useState(0)
  const [isBanned, setIsBanned] = useState(false)
  const [isPremium, setIsPremium] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<'free' | 'premium'>('free')
  
  useEffect(() => {
    const savedPassword = localStorage.getItem("admin_password")
    if (!savedPassword) {
      router.push("/mr8080506m")
      return
    }
    setAdminPassword(savedPassword)
    loadUser(savedPassword)
  }, [params.id])

  const loadUser = async (password: string) => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/8080506787/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_user_by_id",
          adminPassword: password,
          userId: params.id,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        const userData = data.user

        setUser(userData)
        setBalance(userData.balance || 0)
        setTicketsBalance(userData.tickets_balance || 0)
        setIsBanned(userData.is_banned || false)
        setIsPremium(userData.premium || false)
        
        if (userData.mining_subscription?.plan) {
          setSelectedPlan(userData.mining_subscription.plan)
        }
      } else {
        toast({
          title: "Error",
          description: "Failed to load user data",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while loading data",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const saveUserChanges = async () => {
    if (!user) return

    setIsSaving(true)
    try {
      const response = await fetch("/api/8080506787/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "update_user",
          adminPassword,
          userId: user.telegram_id,
          updates: {
            balance: balance,
            tickets_balance: ticketsBalance,
            is_banned: isBanned,
            premium: isPremium,
          },
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setUser(data.user)
        toast({
          title: "Saved Successfully",
          description: "User data updated",
        })
      } else {
        toast({
          title: "Error",
          description: "Failed to save changes",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while saving",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const addMiningSubscription = async () => {
    if (!user) return

    try {
      const response = await fetch("/api/8080506787/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "add_mining_subscription",
          adminPassword,
          userId: user.telegram_id,
          plan: selectedPlan,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setUser(data.user)
        toast({
          title: "Success",
          description: `${selectedPlan === 'premium' ? 'Premium' : 'Free'} subscription activated`,
        })
      } else {
        const errorData = await response.json()
        toast({
          title: "Error",
          description: errorData.error || "Failed to activate subscription",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while activating subscription",
        variant: "destructive",
      })
    }
  }

  const removeMiningSubscription = async () => {
    if (!user) return

    try {
      const response = await fetch("/api/8080506787/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "remove_mining_subscription",
          adminPassword,
          userId: user.telegram_id,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setUser(data.user)
        toast({
          title: "Success",
          description: "Mining subscription removed",
        })
      } else {
        const errorData = await response.json()
        toast({
          title: "Error",
          description: errorData.error || "Failed to remove subscription",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while removing subscription",
        variant: "destructive",
      })
    }
  }

  const formatDate = (dateString: string | number) => {
    if (!dateString) return "Not specified"
    const date = new Date(dateString)
    return date.toLocaleString("en-US")
  }
  
  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#000] flex items-center justify-center">
        <div className="w-14 h-14 border-2 border-[#ff6b35] border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen text-white p-4">
        <div className="max-w-md mx-auto text-center py-8">
          <p className="text-[#a0a0a0]">User not found</p>
          <Button onClick={() => router.push("/mr8080506m")} className="mt-4">
            Back to Users
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen text-white p-4">
      <div className="max-w-md mx-auto space-y-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mx-auto"
        >
          <Button
            onClick={() => router.push("/mr8080506m")}
            variant="ghost"
            size="sm"
            className="text-[#a0a0a0] hover:text-white justify-start"
          >
            <FaArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-xl text-center font-bold fire-text flex-1">Details</h1>
          <Button onClick={saveUserChanges} disabled={isSaving} size="sm" className="text-[#a0a0a0] justify-end hover:text-white">
            <FaSave className="w-4 h-4 mr-1" />
            {isSaving ? "Saving..." : "Save"}
          </Button>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="dark-bg border-[#2a2a2a]">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-tp/10 rounded-full flex items-center justify-center overflow-hidden">
                  {user.user_photo_url ? (
                    <img
                      src={user.user_photo_url || "/placeholder.svg"}
                      alt={user.telegram_username || "User"}
                      width={64}
                      height={64}
                      className="object-cover w-full h-full rounded-full"
                    />
                  ) : (
                    <FaUser className="w-8 h-8 text-tp" />
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold fire-text">
                      {user.telegram_username || `User ${user.telegram_id.slice(-4)}`}
                    </h2>
                    {user.premium && <FaCrown className="w-4 h-4 text-yellow-400" />}
                    {user.is_banned && <FaBan className="w-4 h-4 text-red-400" />}
                  </div>
                  <p className="text-sm text-[#a0a0a0] font-mono">ID: {user.telegram_id}</p>
                  <p className="text-xs text-[#a0a0a0]">Joined: {formatDate(user.created_at)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="dark-bg border-[#2a2a2a]">
            <CardHeader>
              <CardTitle className="fire-text text-lg flex items-center gap-2">
                <FaCoins className="w-5 h-5 text-tp" />
                Balances & Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm text-[#a0a0a0] mb-2 block">Balance</label>
                <Input
                  type="number"
                  value={balance}
                  onChange={(e) => setBalance(Number(e.target.value))}
                  className="dark-bg border-[#2a2a2a] text-white"
                />
              </div>

              <div>
                <label className="text-sm text-[#a0a0a0] mb-2 block">Tickets</label>
                <Input
                  type="number"
                  value={ticketsBalance}
                  onChange={(e) => setTicketsBalance(Number(e.target.value))}
                  className="dark-bg border-[#2a2a2a] text-white"
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-white">Premium Status</span>
                <Switch checked={isPremium} onCheckedChange={setIsPremium} />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-white">Ban User</span>
                <Switch checked={isBanned} onCheckedChange={setIsBanned} />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card className="dark-bg border-[#2a2a2a]">
            <CardHeader>
              <CardTitle className="fire-text text-lg">Mining Subscription</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {user.mining_subscription?.isActive ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Badge className={
                      user.mining_subscription.plan === 'premium' 
                        ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
                        : "bg-blue-500/10 text-blue-400 border-blue-500/20"
                    }>
                      {user.mining_subscription.plan === 'premium' ? 'Premium Subscription' : 'Free Subscription'}
                    </Badge>
                    <Button 
                      onClick={removeMiningSubscription}
                      variant="destructive"
                      size="sm"
                    >
                      <FaTrash className="w-3 h-3 mr-1" />
                      Remove
                    </Button>
                  </div>
                  
                  <div className="text-xs space-y-1">
                    <p className="text-white">Status: <span className="text-green-400">Active</span></p>
                    <p className="text-[#a0a0a0]">Start Date: {formatDate(user.mining_subscription.startTime)}</p>
                    <p className="text-[#a0a0a0]">Last Claim: {formatDate(user.mining_subscription.lastClaimTime)}</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <Badge className="bg-red-500/10 text-red-400 border-red-500/20">Not Active</Badge>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-3 dark-bg rounded-lg">
                      <input
                        type="radio"
                        id="freePlan"
                        checked={selectedPlan === 'free'}
                        onChange={() => setSelectedPlan('free')}
                        className="text-blue-400"
                      />
                      <label htmlFor="freePlan" className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-white">Free</span>
                          <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20">
                            5k 
                          </Badge>
                        </div>
                        <p className="text-xs text-[#a0a0a0]">Every 12 hours</p>
                      </label>
                    </div>

                    <div className="flex items-center gap-3 p-3 dark-bg rounded-lg">
                      <input
                        type="radio"
                        id="premiumPlan"
                        checked={selectedPlan === 'premium'}
                        onChange={() => setSelectedPlan('premium')}
                        className="text-yellow-400"
                      />
                      <label htmlFor="premiumPlan" className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-white">Premium</span>
                          <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20">
                            20k 
                          </Badge>
                        </div>
                        <p className="text-xs text-[#a0a0a0]">Every 8 hours</p>
                      </label>
                    </div>

                    <Button 
                      onClick={addMiningSubscription} 
                      className="fire-gradient w-full"
                    >
                      <FaPlus className="w-4 h-4 mr-1" />
                      Activate Subscription
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="dark-bg border-[#2a2a2a]">
            <CardHeader>
              <CardTitle className="fire-text text-lg">Completed Tasks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {user.completed_tasks && user.completed_tasks.length > 0 ? (
                  user.completed_tasks.map((task: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-3 dark-bg overflow-hidden rounded-lg">
                      <div className="flex items-center gap-3">
                        <FaTasks className="w-4 h-4 text-tp" />
                        <div>
                         <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate text-white">{task.taskId || `Task ${index + 1}`}</p>
                          <p className="text-xs text-[#a0a0a0]">
                            Completed: {task.completed ? "Yes" : "No"}
                          </p>
                         </div> 
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-[#a0a0a0] text-sm text-center py-4">No completed tasks</p>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="dark-bg border-[#2a2a2a]">
            <CardHeader>
              <CardTitle className="fire-text text-lg">Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <FaUsers className="w-6 h-6 text-white mx-auto mb-2" />
                  <p className="text-lg font-bold fire-text">{user.referrals?.length || 0}</p>
                  <p className="text-xs text-[#a0a0a0]">Referrals</p>
                </div>
                <div className="text-center">
                  <FaTicketAlt className="w-6 h-6 text-white mx-auto mb-2" />
                  <p className="text-lg font-bold fire-text">{formatNumber(user.tickets_balance)}</p>
                  <p className="text-xs text-[#a0a0a0]">Tickets</p>
                </div>
                <div className="text-center">
                  <FaCoins className="w-6 h-6 text-white mx-auto mb-2" />
                  <p className="text-lg font-bold fire-text">{formatNumber(user.balance)}</p>
                  <p className="text-xs text-[#a0a0a0]">Balance</p>
                </div>
                <div className="text-center">
                  <FaTasks className="w-6 h-6 text-white mx-auto mb-2" />
                  <p className="text-lg font-bold fire-text">{user.completed_tasks?.length || 0}</p>
                  <p className="text-xs text-[#a0a0a0]">Tasks Done</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card className="dark-bg border-[#2a2a2a]">
            <CardHeader>
              <CardTitle className="fire-text text-lg">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span className="text-[#a0a0a0] text-sm">Last Updated:</span>
                <span className="text-white text-xs">{formatDate(user.updated_at)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#a0a0a0] text-sm">Last Daily Reward:</span>
                <span className="text-white text-xs">{formatDate(user.last_daily_reward)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#a0a0a0] text-sm">Completed Tasks:</span>
                <span className="text-white text-xs">{user.completed_tasks?.length || 0}</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}

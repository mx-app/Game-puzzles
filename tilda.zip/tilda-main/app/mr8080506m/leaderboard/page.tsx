"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { FaArrowLeft, FaCrown, FaCoins, FaUsers, FaTrophy, FaMedal, FaGem } from "react-icons/fa"
import { motion } from "framer-motion"
import { formatNumber } from "@/lib/utils"

interface LeaderboardUser {
  telegram_id: string
  telegram_username: string
  user_photo_url: string
  balance?: number
  referrals_count?: number
  rank: number
}

export default function AdminLeaderboard() {
  const router = useRouter()
  const { toast } = useToast()

  const [balanceLeaderboard, setBalanceLeaderboard] = useState<LeaderboardUser[]>([])
  const [referralsLeaderboard, setReferralsLeaderboard] = useState<LeaderboardUser[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [adminPassword, setAdminPassword] = useState("")
  const [activeTab, setActiveTab] = useState("balance")

  useEffect(() => {
    const savedPassword = localStorage.getItem("admin_password")
    if (!savedPassword) {
      router.push("/mr8080506m")
      return
    }
    setAdminPassword(savedPassword)
    loadLeaderboards(savedPassword)
  }, [])

  const loadLeaderboards = async (password: string) => {
    setIsLoading(true)
    try {
      const [balanceResponse, referralsResponse] = await Promise.all([
        fetch("/api/8080506787/admin", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            action: "get_leaderboard",
            adminPassword: password,
            type: "balance",
          }),
        }),
        fetch("/api/8080506787/admin", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            action: "get_leaderboard",
            adminPassword: password,
            type: "referrals",
          }),
        }),
      ])

      if (balanceResponse.ok && referralsResponse.ok) {
        const balanceData = await balanceResponse.json()
        const referralsData = await referralsResponse.json()

        setBalanceLeaderboard(balanceData.leaderboard || [])
        setReferralsLeaderboard(referralsData.leaderboard || [])
      } else {
        toast({
          title: "Error",
          description: "Failed to load leaderboards",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while loading data",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const truncateUsername = (username?: string) => {
    if (!username) return "User"
    if (username.length <= 2) return username
    return username[0] + "***" + username[username.length - 1]
  }

  const getRankBadge = (rank: number) => {
    switch (rank) {
      case 1:
        return (
          <Badge className="bg-gradient-to-r from-[#FFD700] to-[#FFC000] text-black">
            <FaCrown className="w-3 h-3" />
          </Badge>
        )
      case 2:
        return (
          <Badge className="bg-gradient-to-r from-[#C0C0C0] to-[#A0A0A0] text-black">
            <FaMedal className="w-3 h-3" />
          </Badge>
        )
      case 3:
        return (
          <Badge className="bg-gradient-to-r from-[#CD7F32] to-[#B87333] text-black">
            <FaMedal className="w-3 h-3" />
          </Badge>
        )
      default:
        return <Badge className="dark-bg text-[#a0a0a0]">#{rank}</Badge>
    }
  }

  const getUserCardStyle = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-gradient-to-b from-[#FFD700]/10 to-dark-bg"
      case 2:
        return "bg-gradient-to-b from-[#C0C0C0]/10 to-dark-bg"
      case 3:
        return "bg-gradient-to-b from-[#CD7F32]/10 to-dark-bg"
      default:
        return "dark-bg"
    }
  }

  const renderLeaderboardList = (users: LeaderboardUser[], type: "balance" | "referrals") => {
    if (users.length === 0) {
      return (
        <div className="text-center py-8">
          <FaTrophy className="w-12 h-12 text-[#a0a0a0] mx-auto mb-4" />
          <p className="text-[#a0a0a0]">No data available</p>
        </div>
      )
    }

    return (
      <div className="space-y-3">
        {users.map((user, index) => (
          <motion.div
            key={`${type}-${user.telegram_id}`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <Card
              className={`${getUserCardStyle(user.rank)} cursor-pointer hover:opacity-80 transition-opacity`}
              onClick={() => router.push(`/mr8080506m/users/${user.telegram_id}`)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className="w-10 h-10 bg-tp/10 rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                      {user.user_photo_url ? (
                        <img
                          src={user.user_photo_url || "/placeholder.svg"}
                          alt={user.telegram_username || "User"}
                          width={40}
                          height={40}
                          className="object-cover w-full h-full rounded-lg"
                        />
                      ) : (
                        <div className="text-tp font-bold">{user.telegram_username?.charAt(0) || "?"}</div>
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="fire-text font-medium text-sm">{truncateUsername(user.telegram_username)}</div>
                      <div className="text-xs text-[#a0a0a0] font-mono">ID: {user.telegram_id}</div>
                      <div className="mt-1">{getRankBadge(user.rank)}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium fire-text">
                      {type === "balance"
                        ? formatNumber(user.balance || 0)
                        : formatNumber(user.referrals_count || 0)}
                    </span>
                    {type === "balance" ? (
                      <FaCoins className="w-4 h-4 text-tp" />
                    ) : (
                      <FaUsers className="w-4 h-4 text-green-400" />
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#000] flex items-center justify-center">
        <div className="w-14 h-14 border-2 border-[#ff6b35] border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="min-h-screen text-white p-4">
      <div className="max-w-md mx-auto space-y-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <Button
            onClick={() => router.push("/mr8080506m")}
            variant="ghost"
            size="sm"
            className="text-[#a0a0a0] hover:text-white"
          >
            <FaArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-xl font-bold fire-text">Leaders</h1>
          <div className="w-16"></div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 gap-3"
        >
          <Card className="dark-bg border-[#2a2a2a]">
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <FaCoins className="w-4 h-4 text-tp" />
                <div>
                  <p className="text-xs text-[#a0a0a0]">Balance Leaders</p>
                  <p className="text-lg font-bold fire-text">{formatNumber(balanceLeaderboard.length)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="dark-bg border-[#2a2a2a]">
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <FaUsers className="w-4 h-4 text-green-400" />
                <div>
                  <p className="text-xs text-[#a0a0a0]">Referral Leaders</p>
                  <p className="text-lg font-bold fire-text">{formatNumber(referralsLeaderboard.length)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 dark-bg h-12 rounded-2xl p-1 mb-4">
              <TabsTrigger
                value="balance"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
              >
                <div className="flex items-center justify-center space-x-2 z-10 relative">
                  <FaCoins className="w-4 h-4 text-tp" />
                  <span>Balance</span>
                </div>
              </TabsTrigger>
              <TabsTrigger
                value="referrals"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
              >
                <div className="flex items-center justify-center space-x-2 z-10 relative">
                  <FaUsers className="w-4 h-4 text-tp" />
                  <span>Referrals</span>
                </div>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="balance" className="mt-2">
              {renderLeaderboardList(balanceLeaderboard, "balance")}
            </TabsContent>

            <TabsContent value="referrals" className="mt-2">
              {renderLeaderboardList(referralsLeaderboard, "referrals")}
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  )
}

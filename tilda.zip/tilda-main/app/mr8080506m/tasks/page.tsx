"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"
import { FaArrowLeft, FaTasks, FaPlus, FaEdit, FaTrash, FaEye, FaSave, FaImage, FaGem, FaCoins } from "react-icons/fa"
import { motion } from "framer-motion"
import { formatNumber } from "@/lib/utils"

interface Task {
  id: string
  title: string
  image_url: string
  task_url: string
  reward_amount: number
  task_type: "main" | "partner"
  completed_count: number
  is_active: boolean
  created_at: string
  updated_at: string
}

export default function AdminTasks() {
  const router = useRouter()
  const { toast } = useToast()

  const [tasks, setTasks] = useState<Task[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [adminPassword, setAdminPassword] = useState("")
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [editingTask, setEditingTask] = useState<Task | null>(null)

  const [formData, setFormData] = useState({
    title: "",
    image_url: "",
    task_url: "",
    reward_amount: 0,
    task_type: "main" as "main" | "partner",
    is_active: true,
  })

  useEffect(() => {
    const savedPassword = localStorage.getItem("admin_password")
    if (!savedPassword) {
      router.push("/mr8080506m")
      return
    }
    setAdminPassword(savedPassword)
    loadTasks(savedPassword)
  }, [])

  const loadTasks = async (password: string) => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/8080506787/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_all_tasks",
          adminPassword: password,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setTasks(data.tasks)
      } else {
        toast({
          title: "Error",
          description: "Failed to load tasks",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while loading data",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateTask = async () => {
    if (!formData.title || !formData.image_url || !formData.task_url || !formData.reward_amount) {
      toast({
        title: "Error",
        description: "Please fill all required fields",
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch("/api/8080506787/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "create_task",
          adminPassword,
          taskData: formData,
        }),
      })

      if (response.ok) {
        await loadTasks(adminPassword)
        setShowCreateForm(false)
        setFormData({
          title: "",
          image_url: "",
          task_url: "",
          reward_amount: 0,
          task_type: "main",
          is_active: true,
        })
        toast({
          title: "Task Created",
          description: "Task created successfully",
        })
      } else {
        toast({
          title: "Error",
          description: "Failed to create task",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while creating task",
        variant: "destructive",
      })
    }
  }

  const handleUpdateTask = async () => {
    if (!editingTask) return

    try {
      const response = await fetch("/api/8080506787/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "update_task",
          adminPassword,
          taskId: editingTask.id,
          updates: formData,
        }),
      })

      if (response.ok) {
        await loadTasks(adminPassword)
        setEditingTask(null)
        setFormData({
          title: "",
          image_url: "",
          task_url: "",
          reward_amount: 0,
          task_type: "main",
          is_active: true,
        })
        toast({
          title: "Task Updated",
          description: "Task updated successfully",
        })
      } else {
        toast({
          title: "Error",
          description: "Failed to update task",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while updating task",
        variant: "destructive",
      })
    }
  }

  const handleDeleteTask = async (taskId: string) => {
    if (!confirm("Are you sure you want to delete this task?")) return

    try {
      const response = await fetch("/api/8080506787/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "delete_task",
          adminPassword,
          taskId,
        }),
      })

      if (response.ok) {
        await loadTasks(adminPassword)
        toast({
          title: "Task Deleted",
          description: "Task deleted successfully",
        })
      } else {
        toast({
          title: "Error",
          description: "Failed to delete task",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while deleting task",
        variant: "destructive",
      })
    }
  }

  const startEditing = (task: Task) => {
    setEditingTask(task)
    setFormData({
      title: task.title,
      image_url: task.image_url,
      task_url: task.task_url,
      reward_amount: task.reward_amount,
      task_type: task.task_type,
      is_active: task.is_active,
    })
    setShowCreateForm(true)
  }

  const cancelEditing = () => {
    setEditingTask(null)
    setShowCreateForm(false)
    setFormData({
      title: "",
      image_url: "",
      task_url: "",
      reward_amount: 0,
      task_type: "main",
      is_active: true,
    })
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#000] flex items-center justify-center">
        <div className="w-14 h-14 border-2 border-[#ff6b35] border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="min-h-screen text-white p-4">
      <div className="max-w-md mx-auto space-y-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <Button
            onClick={() => router.push("/mr8080506m")}
            variant="ghost"
            size="sm"
            className="text-[#a0a0a0] hover:text-white"
          >
            <FaArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-xl font-bold fire-text">Tasks</h1>
          <Button onClick={() => setShowCreateForm(true)} size="sm" className="text-[#a0a0a0] hover:text-white">
            <FaPlus className="w-4 h-4 mr-1" />
            Add
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 gap-3"
        >
          <Card className="dark-bg border-[#2a2a2a]">
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <FaTasks className="w-4 h-4 text-tp" />
                <div>
                  <p className="text-xs text-[#a0a0a0]">Total Tasks</p>
                  <p className="text-lg font-bold fire-text">{formatNumber(tasks.length)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="dark-bg border-[#2a2a2a]">
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <FaEye className="w-4 h-4 text-green-400" />
                <div>
                  <p className="text-xs text-[#a0a0a0]">Active Tasks</p>
                  <p className="text-lg font-bold fire-text">
                    {formatNumber(tasks.filter((task) => task.is_active).length)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {showCreateForm && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="dark-bg border-[#2a2a2a]">
              <CardHeader>
                <CardTitle className="fire-text text-lg">
                  {editingTask ? "Edit Task" : "Add New Task"}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm text-[#a0a0a0] mb-2 block">Task Title</label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Enter task title"
                    className="dark-bg border-[#2a2a2a] text-white"
                  />
                </div>

                <div>
                  <label className="text-sm text-[#a0a0a0] mb-2 block">Image URL</label>
                  <Input
                    value={formData.image_url}
                    onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                    className="dark-bg border-[#2a2a2a] text-white"
                  />
                </div>

                <div>
                  <label className="text-sm text-[#a0a0a0] mb-2 block">Task URL</label>
                  <Input
                    value={formData.task_url}
                    onChange={(e) => setFormData({ ...formData, task_url: e.target.value })}
                    placeholder="https://example.com/task"
                    className="dark-bg border-[#2a2a2a] text-white"
                  />
                </div>

                <div>
                  <label className="text-sm text-[#a0a0a0] mb-2 block">Reward Amount</label>
                  <Input
                    type="number"
                    value={formData.reward_amount}
                    onChange={(e) => setFormData({ ...formData, reward_amount: Number(e.target.value) })}
                    placeholder="500"
                    className="dark-bg border-[#2a2a2a] text-white"
                  />
                </div>

                <div>
                  <label className="text-sm text-[#a0a0a0] mb-2 block">Task Type</label>
                  <select
                    value={formData.task_type}
                    onChange={(e) => setFormData({ ...formData, task_type: e.target.value as "main" | "partner" })}
                    className="w-full dark-bg border border-[#2a2a2a] text-white rounded-md px-3 py-2"
                  >
                    <option value="main">Main</option>
                    <option value="partner">Partner</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-white">Task Active</span>
                  <Switch
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={editingTask ? handleUpdateTask : handleCreateTask}
                    className="flex-1 fire-gradient"
                  >
                    <FaSave className="w-4 h-4 mr-1" />
                    {editingTask ? "Update" : "Create"}
                  </Button>
                  <Button
                    onClick={cancelEditing}
                    variant="outline"
                    className="flex-1 border-[#2a2a2a] text-[#a0a0a0] hover:bg-[#2a2a2a] bg-transparent"
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-3"
        >
          {tasks.map((task, index) => (
            <motion.div
              key={task.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className={`dark-bg border-[#2a2a2a] ${!task.is_active ? "opacity-60" : ""}`}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 bg-[#2a2a2a] rounded-lg overflow-hidden flex-shrink-0">
                      {task.image_url ? (
                        <img
                          src={task.image_url || "/placeholder.svg"}
                          alt={task.title}
                          width={48}
                          height={48}
                          className="object-cover w-full h-full"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <FaImage className="w-6 h-6 text-[#a0a0a0]" />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="min-w-0 flex-1">
                          <h3 className="fire-text font-medium text-sm truncate">{task.title}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex items-center gap-1">
                              <span className="text-xs text-white">{formatNumber(task.reward_amount)}</span>
                              <FaCoins className="w-3 h-3 text-tp" />
                            </div>
                            <Badge
                              className={`text-xs ${
                                task.task_type === "main"
                                  ? "bg-blue-500/10 text-blue-400 border-blue-500/20"
                                  : "bg-purple-500/10 text-purple-400 border-purple-500/20"
                              }`}
                            >
                              {task.task_type === "main" ? "Main" : "Partner"}
                            </Badge>
                            {task.is_active ? (
                              <Badge className="bg-green-500/10 text-green-400 border-green-500/20 text-xs">Active</Badge>
                            ) : (
                              <Badge className="bg-red-500/10 text-red-400 border-red-500/20 text-xs">Inactive</Badge>
                            )}
                          </div>
                          <p className="text-xs text-[#a0a0a0] mt-1">Completed {formatNumber(task.completed_count)} times</p>
                        </div>

                        <div className="flex gap-1 ml-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => startEditing(task)}
                            className="p-1 h-6 w-6 text-[#a0a0a0] hover:text-white"
                          >
                            <FaEdit className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteTask(task.id)}
                            className="p-1 h-6 w-6 text-red-400 hover:text-red-300"
                          >
                            <FaTrash className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>

                      <div className="mt-2 text-xs text-[#a0a0a0]">Created: {formatDate(task.created_at)}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {tasks.length === 0 && !isLoading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-8">
            <FaTasks className="w-12 h-12 text-[#a0a0a0] mx-auto mb-4" />
            <p className="text-[#a0a0a0]">No tasks available</p>
            <Button onClick={() => setShowCreateForm(true)} className="mt-4 fire-gradient">
              Create First Task
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  )
}

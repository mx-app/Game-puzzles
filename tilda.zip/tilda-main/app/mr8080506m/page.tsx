"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { FaUsers, FaCoins, FaTasks, FaSearch, FaCrown, FaLock, FaGem } from "react-icons/fa"
import { motion } from "framer-motion"
import { formatNumber } from "@/lib/utils"

interface DashboardStats {
  totalUsers: number
  totalBalance: number
  totalTasks: number
}

export default function AdminDashboard() {
  const router = useRouter()
  const { toast } = useToast()

  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [adminPassword, setAdminPassword] = useState("")
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleLogin = async () => {
    if (!adminPassword.trim()) {
      toast({
        title: "Error",
        description: "Please enter the password",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch("/api/8080506787/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_dashboard_stats",
          adminPassword,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setStats(data.stats)
        setIsAuthenticated(true)
        localStorage.setItem("admin_password", adminPassword)
        toast({
          title: "Login Successful",
          description: "Welcome to Admin Dashboard",
        })
      } else {
        toast({
          title: "Authentication Error",
          description: "Incorrect password",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred during login",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const loadDashboardStats = async () => {
    const savedPassword = localStorage.getItem("admin_password")
    if (!savedPassword) return

    try {
      const response = await fetch("/api/8080506787/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_dashboard_stats",
          adminPassword: savedPassword,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setStats(data.stats)
        setIsAuthenticated(true)
        setAdminPassword(savedPassword)
      }
    } catch (error) {
      console.error("Error loading dashboard stats:", error)
    }
  }

  useEffect(() => {
    loadDashboardStats()
  }, [])
  
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen text-white flex items-center justify-center p-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
          <Card className="dark-bg border-[#2a2a2a]">
            <CardHeader className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-[#2a2a2a] rounded-full flex items-center justify-center">
                <FaLock className="w-8 h-8 text-tp" />
              </div>
              <CardTitle className="fire-text text-xl">Admin Panel</CardTitle>
              <p className="text-[#a0a0a0] text-sm">Please enter admin password</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                type="password"
                placeholder="Admin Password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                className="dark-bg border-[#2a2a2a] text-white"
                onKeyDown={(e) => e.key === "Enter" && handleLogin()}
              />
              <Button
                onClick={handleLogin}
                disabled={isLoading}
                className="w-full fire-gradient text-white"
              >
                {isLoading ? "Verifying..." : "Login"}
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen text-white p-4">
      <div className="max-w-md mx-auto space-y-6">
        <div className="text-center mb-6">
         <h1 className="text-2xl font-bold fire-text mb-1">Admin Dashboard</h1>
          <p className="text-[#a0a0a0] text-sm">
           Management and monitoring panel
          </p>
        </div>
        {stats && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="grid grid-cols-1 gap-4">
            <Card className="dark-bg border-[#2a2a2a]">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[#a0a0a0] text-sm">Total Users</p>
                    <p className="text-2xl font-bold fire-text">{formatNumber(stats.totalUsers)}</p>
                  </div>
                  <div className="w-12 h-12 bg-tp rounded-full flex items-center justify-center">
                    <FaUsers className="w-6 h-6 text-tp" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="dark-bg border-[#2a2a2a]">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[#a0a0a0] text-sm">Total Balance</p>
                    <p className="text-2xl font-bold fire-text flex items-center gap-2">
                      {formatNumber(stats.totalBalance)}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-tp rounded-full flex items-center justify-center">
                    <FaCoins className="w-6 h-6 text-tp" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="dark-bg border-[#2a2a2a]">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[#a0a0a0] text-sm">Total Tasks</p>
                    <p className="text-2xl font-bold fire-text">{formatNumber(stats.totalTasks)}</p>
                  </div>
                  <div className="w-12 h-12 bg-tp rounded-full flex items-center justify-center">
                    <FaTasks className="w-6 h-6 text-tp" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-3"
        >
          <Button
            onClick={() => router.push("/mr8080506m/tasks")}
            className="w-full dark-bg hover:bg-[#2a2a2a] text-white justify-start h-14"
          >
            <FaTasks className="w-5 h-5 mr-3 text-tp" />
            <div className="text-left flex-1">
              <div className="font-medium">Manage Tasks</div>
              <div className="text-xs text-[#a0a0a0]">Add, edit and delete tasks</div>
            </div>
          </Button>

          <Button
            onClick={() => router.push("/mr8080506m/search")}
            className="w-full dark-bg hover:bg-[#2a2a2a] text-white justify-start h-14"
          >
            <FaSearch className="w-5 h-5 mr-3 text-tp" />
            <div className="text-left flex-1">
              <div className="font-medium">Search Users</div>
              <div className="text-xs text-[#a0a0a0]">Search by ID or username</div>
            </div>
          </Button>

          <Button
            onClick={() => router.push("/mr8080506m/leaderboard")}
            className="w-full dark-bg hover:bg-[#2a2a2a] text-white justify-start h-14"
          >
            <FaCrown className="w-5 h-5 mr-3 text-tp" />
            <div className="text-left flex-1">
              <div className="font-medium">Leaders</div>
              <div className="text-xs text-[#a0a0a0]">View top performers</div>
            </div>
          </Button>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Button
            onClick={() => {
              localStorage.removeItem("admin_password")
              setIsAuthenticated(false)
              setAdminPassword("")
              setStats(null)
            }}
            variant="outline"
            className="w-full border-red-500/20 text-red-400 hover:bg-red-500/10"
          >
            Logout
          </Button>
        </motion.div>
      </div>
    </div>
  )
}

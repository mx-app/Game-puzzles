"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { FaArrowLeft, FaSearch, FaUser, FaCrown, FaBan, FaGem, FaCoins } from "react-icons/fa"
import { motion } from "framer-motion"
import { formatNumber } from "@/lib/utils"

interface User {
  id: string
  telegram_id: string
  telegram_username: string
  user_photo_url: string
  balance: number
  tickets_balance: number
  is_banned: boolean
  premium: boolean
  created_at: string
  referrals: any[]
}

export default function AdminSearch() {
  const router = useRouter()
  const { toast } = useToast()

  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<User[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [hasSearched, setHasSearched] = useState(false)
  const [adminPassword, setAdminPassword] = useState("")

  useEffect(() => {
    const savedPassword = localStorage.getItem("admin_password")
    if (!savedPassword) {
      router.push("/mr8080506m")
      return
    }
    setAdminPassword(savedPassword)
  }, [])

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      toast({
        title: "Error",
        description: "Please enter search query",
        variant: "destructive",
      })
      return
    }

    setIsSearching(true)
    setHasSearched(true)

    try {
      const response = await fetch("/api/8080506787/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "search_users",
          adminPassword,
          query: searchQuery.trim(),
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setSearchResults(data.users)
      } else {
        toast({
          title: "Error",
          description: "Search failed",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while searching",
        variant: "destructive",
      })
    } finally {
      setIsSearching(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  const getUserStatusBadge = (user: User) => {
    if (user.is_banned) {
      return <Badge className="bg-red-500/10 text-red-400 border-red-500/20">Banned</Badge>
    }
    if (user.premium) {
      return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20">Premium</Badge>
    }
    return <Badge className="bg-green-500/10 text-green-400 border-green-500/20">Active</Badge>
  }

  return (
    <div className="min-h-screen text-white p-4">
      <div className="max-w-md mx-auto space-y-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <Button
            onClick={() => router.push("/mr8080506m")}
            variant="ghost"
            size="sm"
            className="text-[#a0a0a0] hover:text-white"
          >
            <FaArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-xl font-bold fire-text">Search</h1>
          <div className="w-16"></div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
          <Card className="dark-bg border-[#2a2a2a]">
            <CardContent className="p-4 space-y-4">
              <div>
                <label className="text-sm text-[#a0a0a0] mb-2 block">Search by Telegram ID or Username</label>
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Enter ID or username..."
                  className="dark-bg border-[#2a2a2a] text-white"
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                />
              </div>

              <Button onClick={handleSearch} disabled={isSearching} className="w-full fire-gradient">
                <FaSearch className="w-4 h-4 mr-2" />
                {isSearching ? "Searching..." : "Search"}
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {hasSearched && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="space-y-3"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold fire-text">Search Results</h2>
              <Badge className="dark-bg text-white">{formatNumber(searchResults.length)} results</Badge>
            </div>

            {searchResults.length > 0 ? (
              <div className="space-y-3">
                {searchResults.map((user, index) => (
                  <motion.div
                    key={user.telegram_id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Card
                      className={`dark-bg border-[#2a2a2a] cursor-pointer hover:bg-[#2a2a2a] transition-colors ${
                        user.is_banned ? "border-red-500/20" : ""
                      }`}
                      onClick={() => router.push(`/mr8080506m/users/${user.telegram_id}`)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3 min-w-0 flex-1">
                            <div className="w-12 h-12 bg-tp/10 rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                              {user.user_photo_url ? (
                                <img
                                  src={user.user_photo_url || "/placeholder.svg"}
                                  alt={user.telegram_username || "User"}
                                  width={48}
                                  height={48}
                                  className="object-cover w-full h-full rounded-full"
                                />
                              ) : (
                                <FaUser className="w-6 h-6 text-tp" />
                              )}
                            </div>

                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <p className="fire-text font-medium text-sm truncate">
                                  {user.telegram_username || `User ${user.telegram_id.slice(-4)}`}
                                </p>
                                {user.premium && <FaCrown className="w-3 h-3 text-yellow-400" />}
                                {user.is_banned && <FaBan className="w-3 h-3 text-red-400" />}
                              </div>
                              <p className="text-[#a0a0a0] text-xs font-mono">ID: {user.telegram_id}</p>
                              <div className="flex items-center gap-2 mt-1">
                                <div className="flex items-center gap-1">
                                  <span className="text-xs text-white">{formatNumber(user.balance)}</span>
                                  <FaCoins className="w-3 h-3 text-tp" />
                                </div>
                                <span className="text-[#a0a0a0] text-xs">•</span>
                                <span className="text-xs text-[#a0a0a0]">{user.referrals?.length || 0} referrals</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-col items-end gap-1">
                            {getUserStatusBadge(user)}
                            <p className="text-xs text-[#a0a0a0]">{formatDate(user.created_at)}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            ) : (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-8">
                <FaSearch className="w-12 h-12 text-[#a0a0a0] mx-auto mb-4" />
                <p className="text-[#a0a0a0] mb-2">No search results found</p>
                <p className="text-sm text-[#666666]">Please check the ID or username</p>
              </motion.div>
            )}
          </motion.div>
        )}

        {!hasSearched && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Card className="dark-bg border-[#2a2a2a]">
              <CardContent className="p-4">
                <h3 className="fire-text font-medium mb-3">Search Tips:</h3>
                <ul className="space-y-2 text-sm text-[#a0a0a0]">
                  <li>• Search using full Telegram ID</li>
                  <li>• Or search using username</li>
                  <li>• Search supports partial text matching</li>
                  <li>• Results limited to 50 users maximum</li>
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  )
}

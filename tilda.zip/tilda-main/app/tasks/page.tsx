"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AppLayout } from "@/components/app-layout"
import { useToast } from "@/components/ui/use-toast"
import { LoadingScreen } from "@/components/loading-screen"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FaTasks, FaCheckCircle, FaExternalLinkAlt, FaSpinner, FaHandHoldingUsd, FaHandsHelping, FaCoins, FaLink } from "react-icons/fa"
import Image from "next/image"
import { Skeleton } from "@/components/ui/skeleton"
import { motion } from "framer-motion"
import { BottomNavigation } from "@/components/bottom-navigation"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "@/components/ui/dialog"
import { useTonAddress, useTonConnectUI } from "@tonconnect/ui-react"
import { walletService } from "@/lib/wallet-service"
import { WALLET_ADDRESS } from "@/lib/wallet-config"
import { createInvoiceLink, openTelegramInvoice } from "@/lib/payment-service"
import { SIMPLE, NAME } from "@/lib/config"

type Task = {
  id: string
  title: string
  image_url: string
  task_url: string
  reward_amount: number
  task_type: 'main' | 'partner'
  completed_count: number
  payment_amount?: number
  payment_currency?: 'TON' | 'STARS'
  stars_cost?: number
  is_static?: boolean
}

export default function TasksPage() {
  const { toast } = useToast()
  const [tonConnectUI] = useTonConnectUI()
  const userAddress = useTonAddress()
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [tasks, setTasks] = useState<Task[]>([])
  const [activeTab, setActiveTab] = useState<'main' | 'partner'>('main')
  const [claimingTasks, setClaimingTasks] = useState<Record<string, boolean>>({})
  const [startedTasks, setStartedTasks] = useState<Record<string, boolean>>({})
  const [processingTasks, setProcessingTasks] = useState<Record<string, boolean>>({})
  const [showPaymentDialog, setShowPaymentDialog] = useState(false)
  const [currentTask, setCurrentTask] = useState<Task | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingMethod, setProcessingMethod] = useState<'TON' | 'STARS' | null>(null)
  const [walletBalance, setWalletBalance] = useState<string>("0")

  const staticMainTasks: Task[] = [
    {
      id: "account_activation_task",
      title: "Account Activation",
      image_url: "/user.png",
      task_url: "",
      reward_amount: 500,
      task_type: 'main',
      completed_count: 0,
      payment_amount: 1,
      payment_currency: 'TON',
      stars_cost: 400,
      is_static: true
    }
  ]

  const fetchData = useCallback(async () => {
    try {
      setIsLoading(true);
  
      if (typeof window !== "undefined" && window.Telegram?.WebApp?.initData) {
        const userResponse = await fetch("/api/user", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "get_or_create_user",
            initData: window.Telegram.WebApp.initData,
          }),
        });

        if (userResponse.ok) {
          const userData = await userResponse.json();
          setUser(userData.user);
        }
      }
      
      const tasksResponse = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "get_tasks" }),
      });

      if (tasksResponse.ok) {
        const tasksData = await tasksResponse.json();
        setTasks([...staticMainTasks, ...tasksData.tasks]);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setTimeout(() => setIsLoading(false), 500);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    const fetchWalletBalance = async () => {
      if (!userAddress) {
        setWalletBalance("0")
        return
      }

      try {
        const balanceData = await walletService.checkTonWalletBalance(userAddress)
        
        if (balanceData.success) {
          setWalletBalance(balanceData.balance)
        } else {
          console.error("Failed to fetch wallet balance:", balanceData.error)
          setWalletBalance("0")
        }
      } catch (error) {
        console.error("Error fetching wallet balance:", error)
        setWalletBalance("0")
      }
    }

    fetchWalletBalance()
  }, [userAddress])

  const isTaskCompleted = (taskId: string) => {
    if (!user?.completed_tasks) return false
    return user.completed_tasks.some((t: any) => t.taskId === taskId && t.completed)
  }

  const startTask = async (task: Task) => {
    if (task.payment_amount || task.stars_cost) {
      setCurrentTask(task)
      setShowPaymentDialog(true)
      return
    }
    
    setProcessingTasks(prev => ({ ...prev, [task.id]: true }))
    
    try {
      const action = task.is_static ? "start_static_task" : "start_task"
      
      const startResponse = await fetch("/api/user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: action,
          initData: window.Telegram.WebApp.initData,
          taskId: task.id,
        }),
      })

      if (startResponse.ok) {
        const data = await startResponse.json()
        setUser(data.user)
        
        if (task.task_url) {
          window.open(task.task_url, "_blank")
        }

        setTimeout(() => {
          setStartedTasks(prev => ({ ...prev, [task.id]: true }))
          setProcessingTasks(prev => ({ ...prev, [task.id]: false }))
        }, 3000)
      }
    } catch (error) {
      console.error("Error starting task:", error)
      setProcessingTasks(prev => ({ ...prev, [task.id]: false }))
    }
  }

  const completeTask = async (task: Task) => {
    setClaimingTasks(prev => ({ ...prev, [task.id]: true }))
    
    try {
      const action = task.is_static ? "complete_static_task" : "complete_task"
      
      const completeResponse = await fetch("/api/user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: action,
          initData: window.Telegram.WebApp.initData,
          taskId: task.id,
          rewardAmount: task.reward_amount,
        }),
      })

      if (completeResponse.ok) {
        const data = await completeResponse.json()
        setUser(data.user)
        toast({
          title: "Reward claimed!",
          description: `You've received ${task.reward_amount} ${SIMPLE}`,
        })
      }
    } catch (error) {
      console.error("Error claiming reward:", error)
      toast({
        title: "Failed to claim reward",
        description: "Please try again",
        variant: "destructive",
      })
    } finally {
      setClaimingTasks(prev => ({ ...prev, [task.id]: false }))
    }
  }

  const handlePayment = async (paymentMethod: 'TON' | 'STARS') => {
    if (!currentTask) return
    
    setIsProcessing(true)
    setProcessingMethod(paymentMethod)
    
    try {
      if (paymentMethod === 'TON') {
        if (!userAddress) {
          setShowPaymentDialog(false)
          await tonConnectUI.openModal()
          return
        }

        const requiredAmount = currentTask.payment_amount || 0
        const balanceCheck = await walletService.hasEnoughBalance(
          userAddress,
          requiredAmount
        )

        if (!balanceCheck.sufficient) {
          throw new Error(
            `Insufficient balance. You need ${requiredAmount} TON but have ${balanceCheck.currentBalance.toFixed(2)} TON`
          )
        }

        const tonAmount = BigInt(Math.floor(requiredAmount * 1000000000))

        const result = await tonConnectUI.sendTransaction({
          validUntil: Math.floor(Date.now() / 1000) + 600,
          messages: [
            {
              address: WALLET_ADDRESS,
              amount: tonAmount.toString(),
            },
          ],
        })

        if (!result?.boc) {
          throw new Error("Transaction failed")
        }
      } else if (paymentMethod === 'STARS') {
        const starsCost = currentTask.stars_cost || 0
        
        const invoiceLink = await createInvoiceLink(
          starsCost,
          `Task Payment: ${currentTask.title}`,
          `Payment for ${currentTask.title} task using Stars`
        )

        const status = await openTelegramInvoice(invoiceLink)
        if (status !== "paid") {
          throw new Error("Payment not completed")
        }
      }

      const startAction = currentTask.is_static ? "start_static_task" : "start_task"
      
      const startResponse = await fetch("/api/user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: startAction,
          initData: window.Telegram.WebApp.initData,
          taskId: currentTask.id,
        }),
      })

      if (!startResponse.ok) {
        throw new Error("Failed to start task")
      }

      const startData = await startResponse.json()
      setUser(startData.user)

      const completeAction = currentTask.is_static ? "complete_static_task" : "complete_task"
      
      const completeResponse = await fetch("/api/user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: completeAction,
          initData: window.Telegram.WebApp.initData,
          taskId: currentTask.id,
          rewardAmount: currentTask.reward_amount,
        }),
      })

      if (completeResponse.ok) {
        const completeData = await completeResponse.json()
        setUser(completeData.user)
        setShowPaymentDialog(false)
        toast({
          title: "Payment successful!",
          description: `You've received ${currentTask.reward_amount} ${SIMPLE} as reward`,
        })
      }
    } catch (error) {
      console.error("Payment error:", error)
      toast({
        title: "Payment failed",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
      setProcessingMethod(null)
    }
  }

  const renderTaskButton = (task: Task) => {
    const isCompleted = isTaskCompleted(task.id)
    const isClaiming = claimingTasks[task.id]
    const isStarted = startedTasks[task.id] || 
      (user?.completed_tasks?.some((t: any) => t.taskId === task.id && !t.completed))
    const isProcessing = processingTasks[task.id]

    if (isCompleted) {
      return (
        <Button 
          className="h-8 rounded-xl bg-green-500/10 text-green-400 border-green-500/20 hover:bg-green-500/20 text-xs" 
          disabled
        >
          <FaCheckCircle className="w-3 h-3 mr-1 text-green-400" />
          Done
        </Button>
      )
    }

    if (isProcessing) {
      return (
        <Button 
          className="h-8 fire-gradient text-xs rounded-xl"
          disabled
        >
          <FaSpinner className="w-3 h-3 animate-spin text-white" />
        </Button>
      )
    }

    if (isStarted) {
      return (
        <Button 
          className="h-8 fire-gradient text-xs rounded-xl"
          onClick={() => completeTask(task)}
          disabled={isClaiming}
        >
          {isClaiming ? (
            <FaSpinner className="w-3 h-3 mr-1 animate-spin text-white" />
          ) : (
            <FaCheckCircle className="w-3 h-3 mr-1 text-white" />
          )}
          Claim
        </Button>
      )
    }

    return (
      <Button 
        className="h-8 fire-gradient text-xs rounded-xl"
        onClick={() => startTask(task)}
      >
        {task.payment_amount || task.stars_cost ? (
          <FaCoins className="w-3 h-3 mr-1 text-white" />
        ) : (
          <FaLink className="w-3 h-3 mr-1 text-white" />
        )}
        {task.payment_amount || task.stars_cost ? "Pay" : "Start"}
      </Button>
    )
  }

  const renderSkeletonLoader = () => (
    <div className="space-y-3">
      {[...Array(5)].map((_, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        >
          <Card className="dark-bg rounded-2xl">
            <CardContent className="p-3">
              <div className="flex items-center space-x-3">
                <Skeleton className="w-10 h-10 rounded-lg bg-[#1A1A1A]" />
                <div className="flex-1 min-w-0">
                  <Skeleton className="h-3 w-3/4 mb-2 bg-[#1A1A1A]" />
                  <Skeleton className="h-3 w-1/2 bg-[#1A1A1A]" />
                </div>
                <Skeleton className="w-16 h-8 bg-[#1A1A1A] rounded-lg" />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )

  const renderTaskItem = (task: Task) => (
    <motion.div
      key={task.id}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="dark-bg rounded-2xl">
        <CardContent className="p-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 dark-bg rounded-2xl flex items-center justify-center overflow-hidden flex-shrink-0">
              {task.image_url ? (
                <Image
                  src={task.image_url}
                  alt={task.title}
                  width={40}
                  height={40}
                  className="object-cover w-full h-full"
                />
              ) : (
                <FaTasks className="w-5 h-5 text-tp" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-white font-medium text-sm truncate mb-2">
                {task.title}
              </h3>
              <Badge className="bg-tp/10 text-tp tp-border text-xs">
                +{task.reward_amount} {SIMPLE}
              </Badge>
            </div>
            <div className="flex flex-col items-end">
              {renderTaskButton(task)}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
  
  const filteredTasks = tasks.filter(task => task.task_type === activeTab)

  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full">
        <div className="pb-24 pt-4 w-[90%] mx-auto max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold fire-text mb-1">Tasks & Earn</h1>
            <div className="flex justify-center items-center space-x-2">
              <FaTasks className="w-4 h-4 text-tp" />
              <span className="text-[#a0a0a0] text-sm">
                Complete Tasks and Earn {SIMPLE}
              </span>
            </div>
          </div>

          <Tabs defaultValue="main" className="w-full mb-4">
            <TabsList className="grid w-full grid-cols-2 dark-bg h-12 rounded-2xl p-1">
              <TabsTrigger
                value="main"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
                onClick={() => setActiveTab('main')}
              >
                <FaHandHoldingUsd className="w-4 h-4 mr-2 text-tp" />
                <span>Main</span> 
              </TabsTrigger>
              <TabsTrigger
                value="partner"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
                onClick={() => setActiveTab('partner')}
              >
                <FaHandsHelping className="w-4 h-4 mr-2 text-tp" />
                <span>Partner</span> 
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="space-y-3">
            {isLoading ? (
              renderSkeletonLoader()
            ) : filteredTasks.length === 0 ? (
              <Card className="dark-bg rounded-2xl">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-[#2a2a2a] rounded-2xl flex items-center justify-center">
                    <FaTasks className="w-7 h-7 text-[#a0a0a0]" />
                  </div>
                  <h3 className="fire-text text-lg font-semibold mb-2">No Tasks Available</h3>
                  <p className="text-[#a0a0a0] text-sm">
                    Check back later for new tasks to complete
                  </p>
                </CardContent>
              </Card>
            ) : (
              filteredTasks.map(renderTaskItem)
            )}
          </div>
        </div>
        <BottomNavigation />

        <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
          <DialogContent className="w-[95%] max-w-md mx-auto gradient-dark rounded-3xl">
            <DialogHeader className="text-center">
              <DialogTitle className="fire-text text-xl font-bold">Task Payment</DialogTitle>
              <DialogDescription className="text-[#a0a0a0] text-sm">
                Choose payment method to complete this task
              </DialogDescription>
            </DialogHeader>

            <DialogBody className="space-y-4 px-6 py-4">
              <div className="dark-bg rounded-xl p-4 text-center">
                <div className="text-[#a0a0a0] text-sm mb-1">Task Reward</div>
                <div className="fire-text font-semibold text-lg">
                  +{currentTask?.reward_amount} {SIMPLE}
                </div>
                <div className="text-[#a0a0a0] text-xs mt-2">
                  {currentTask?.title}
                </div>
              </div>

              {currentTask?.payment_amount && (
                <motion.div whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => handlePayment("TON")}
                    disabled={isProcessing || (userAddress && Number(walletBalance) < (currentTask?.payment_amount || 0))}
                    className="w-full fire-gradient text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                  >
                    {processingMethod === "TON" ? (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : (
                      <>
                        <Image src="/toncoin.svg" alt="TON" width={20} height={20} className="text-tp" />
                        <span>
                          {!userAddress
                            ? "Connect Wallet"
                            : Number(walletBalance) < (currentTask?.payment_amount || 0)
                              ? `Need ${((currentTask?.payment_amount || 0) - Number(walletBalance)).toFixed(2)} TON more`
                              : `Pay ${currentTask?.payment_amount} TON`}
                        </span>
                      </>
                    )}
                  </Button>
                </motion.div>
              )}

              {currentTask?.stars_cost && (
                <motion.div whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => handlePayment("STARS")}
                    disabled={isProcessing}
                    className="w-full fire-gradient text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                  >
                    {processingMethod === "STARS" ? (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : (
                      <>
                        <Image src="/stars.svg" alt="Stars" width={20} height={20} className="text-tp" />
                        <span>Pay {currentTask?.stars_cost} Stars</span>
                      </>
                    )}
                  </Button>
                </motion.div>
              )}
            </DialogBody>

            <DialogFooter className="px-6 pb-6">
              <motion.div whileTap={{ scale: 0.98 }} className="w-full">
                <Button
                  onClick={() => setShowPaymentDialog(false)}
                  variant="outline"
                  className="w-full border-[#1A1A1A] text-[#a0a0a0] hover:bg-[#1a1a1a] rounded-xl h-10"
                >
                  Cancel
                </Button>
              </motion.div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  )
}

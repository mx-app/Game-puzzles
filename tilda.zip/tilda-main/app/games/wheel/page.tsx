"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { AppLayout } from "@/components/app-layout"
import { useToast } from "@/components/ui/use-toast"
import { LoadingScreen } from "@/components/loading-screen"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "@/components/ui/dialog"
import Image from "next/image"
import { FaTicketAlt, FaGem } from "react-icons/fa"
import { motion } from "framer-motion"
import { TicketPurchaseDialog } from "@/components/ticket-purchase-dialog"
import { formatBalance } from "@/lib/utils"
import { SIMPLE, NAME } from "@/lib/config"
import { TICKET_PRIZES, TP_PRIZES } from "@/lib/data"

interface SpinResult {
  id: string
  type: "tp" | "tickets"
  amount: number
  timestamp: number
}

export default function GiftsPage() {
  const router = useRouter()
  const { toast } = useToast()

  const [isLoading, setIsLoading] = useState(true)
  const [showTicketDialog, setShowTicketDialog] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [isSpinning, setIsSpinning] = useState(false)
  const [spinResult, setSpinResult] = useState<SpinResult | null>(null)
  const [showResultDialog, setShowResultDialog] = useState(false)
  const [currentPrizes, setCurrentPrizes] = useState<any[]>([])
  const [ticketsBalance, setTicketsBalance] = useState(0)
  const [rotationDegrees, setRotationDegrees] = useState(0)
  const [winningSegmentIndex, setWinningSegmentIndex] = useState<number | null>(null)
  const [tpBalance, setTpBalance] = useState(0)

  const wheelRef = useRef<SVGSVGElement>(null)
  const spinAnimationRef = useRef<number | null>(null)

  const fetchUserData = useCallback(async () => {
    try {
      if (typeof window === "undefined" || !window.Telegram?.WebApp?.initData) {
        return
      }

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_or_create_user",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setTicketsBalance(data.user.tickets_balance || 0)
        setTpBalance(data.user.balance || 0)
      }
    } catch (error) {
      console.error("Error fetching user data:", error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUserData()
    generateNewPrizes()
  }, [fetchUserData])

  const generateNewPrizes = () => {
    const weightedTickets = [
      ...Array(5).fill(TICKET_PRIZES[0]), 
      ...Array(3).fill(TICKET_PRIZES[1]), 
      ...Array(2).fill(TICKET_PRIZES[2]), 
      TICKET_PRIZES[3], 
      TICKET_PRIZES[4],
    ]
    const shuffledTickets = [...weightedTickets].sort(() => Math.random() - 0.5).slice(0, 5)
    
    const weightedTp = [
      ...Array(3).fill(TP_PRIZES[0]), 
      ...Array(2).fill(TP_PRIZES[1]), 
      ...Array(2).fill(TP_PRIZES[2]), 
      TP_PRIZES[3], 
      TP_PRIZES[4],
      TP_PRIZES[5],
      TP_PRIZES[6],
    ]
    const shuffledTp = [...weightedTp].sort(() => Math.random() - 0.5).slice(0, 5)
    
    const allPrizes = []
    for (let i = 0; i < 5; i++) {
      allPrizes.push({
        ...shuffledTickets[i],
        type: "tickets" as const,
      })
      allPrizes.push({
        ...shuffledTp[i],
        type: "tp" as const,
      })
    }
    
    setCurrentPrizes(allPrizes)
  }

  const handleSpin = async () => {
    if (ticketsBalance < 1) {
      setShowTicketDialog(true)
      return
    }

    if (isSpinning) return

    setIsSpinning(true)

    try {
      const useTicketResponse = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "use_ticket",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (!useTicketResponse.ok) {
        throw new Error("Failed to use ticket")
      }

      setTicketsBalance((prev) => prev - 1)

      const isTickets = Math.random() < 0.3
      let eligibleIndices = []
      
      if (isTickets) {
        for (let i = 0; i < currentPrizes.length; i++) {
          if (currentPrizes[i].type === "tickets") {
            eligibleIndices.push(i)
          }
        }
      } else {
        for (let i = 0; i < currentPrizes.length; i++) {
          if (currentPrizes[i].type === "tp") {
            eligibleIndices.push(i)
          }
        }
      }

      if (eligibleIndices.length === 0) {
        eligibleIndices = Array.from({ length: currentPrizes.length }, (_, i) => i)
      }

      const randomIndex = eligibleIndices[Math.floor(Math.random() * eligibleIndices.length)]
      const selectedPrize = currentPrizes[randomIndex]
      setWinningSegmentIndex(randomIndex)

      const segmentsCount = currentPrizes.length
      const segmentAngle = 360 / segmentsCount
      const extraRotations = 5
      const targetRotation = extraRotations * 360 + (360 - (randomIndex * segmentAngle + segmentAngle/2))
      
      if (spinAnimationRef.current) {
        cancelAnimationFrame(spinAnimationRef.current)
      }

      const startTime = performance.now()
      const duration = 5000
      const startRotation = rotationDegrees % 360
      
      const animateSpin = (currentTime: number) => {
        const elapsedTime = currentTime - startTime
        const progress = Math.min(elapsedTime / duration, 1)
        
        const easedProgress = 1 - Math.pow(1 - progress, 4)
        const currentRotation = startRotation + (targetRotation - startRotation) * easedProgress
        
        setRotationDegrees(currentRotation)
        
        if (progress < 1) {
          spinAnimationRef.current = requestAnimationFrame(animateSpin)
        } else {
          spinAnimationRef.current = null
          handleSpinComplete(selectedPrize)
        }
      }
      
      spinAnimationRef.current = requestAnimationFrame(animateSpin)

    } catch (error) {
      console.error("Spin error:", error)
      toast({
        title: "Spin Error",
        description: "An error occurred while spinning, please try again",
        variant: "destructive",
      })
      setIsSpinning(false)
    }
  }

  const handleSpinComplete = async (selectedPrize: any) => {
    let result: SpinResult = {
      id: selectedPrize.id,
      type: selectedPrize.type,
      amount: selectedPrize.amount,
      timestamp: Date.now(),
    }

    if (selectedPrize.type === "tp") {
      await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "update_balance",
          initData: window.Telegram.WebApp.initData,
          miningData: { newBalance: selectedPrize.amount },
        }),
      })

      setTpBalance(prev => prev + selectedPrize.amount)
    } else {
      await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "add_tickets",
          initData: window.Telegram.WebApp.initData,
          ticketsAmount: selectedPrize.amount,
        }),
      })

      setTicketsBalance(prev => prev + selectedPrize.amount)
    }

    setSpinResult(result)
    setShowResultDialog(true)
    generateNewPrizes()
    setIsSpinning(false)
  }

  useEffect(() => {
    return () => {
      if (spinAnimationRef.current) {
        cancelAnimationFrame(spinAnimationRef.current)
      }
    }
  }, [])

  if (isLoading) {
    return <LoadingScreen />
  }

  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full flex flex-col pb-20 overflow-x-hidden">
        <div className="text-center pt-6 pb-4 px-4">
          <h1 className="text-2xl font-bold fire-text mb-1">Lucky Wheel</h1>
          <p className="text-[#a0a0a0] text-sm">Spin to win tickets and {SIMPLE}!</p>
        </div>

        <div className="flex justify-center items-center gap-4 mb-4 px-4">
          <div className="flex items-center gap-2">
            <FaTicketAlt className="w-4 h-4 text-tp" />
            <span className="text-sm font-medium">{formatBalance(ticketsBalance)}</span>
          </div>

          <div className="flex items-center gap-2">
            <Image src="/logo.svg" alt="tp" width={20} height={20} />
           <span className="text-sm font-medium">{formatBalance(tpBalance)}</span>
          </div>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-4">
          <div className="relative w-full max-w-xs mb-8">
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20">
              <svg width="25" height="25" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 40L0 0H40L20 40Z" fill="#ff6b35" />
              </svg>
            </div>

            <div className="relative w-full">
              <svg
                ref={wheelRef}
                viewBox="0 0 500 500"
                className="w-full h-full"
                style={{
                  transform: `rotate(${rotationDegrees}deg)`,
                  transition: "none",
                }}
              >
                <circle cx="250" cy="250" r="245" fill="none" stroke="#ff6b35" strokeWidth="5" />

                {currentPrizes.map((prize, index) => {
                  const angle = 360 / currentPrizes.length
                  const startAngle = index * angle
                  const endAngle = (index + 1) * angle
                  const startRad = ((startAngle - 90) * Math.PI) / 180
                  const endRad = ((endAngle - 90) * Math.PI) / 180
                  const x1 = 250 + 220 * Math.cos(startRad)
                  const y1 = 250 + 220 * Math.sin(startRad)
                  const x2 = 250 + 220 * Math.cos(endRad)
                  const y2 = 250 + 220 * Math.sin(endRad)
                  const path = `M 250 250 L ${x1} ${y1} A 220 220 0 0 1 ${x2} ${y2} Z`
                  const textRad = ((startAngle + angle / 2 - 90) * Math.PI) / 180
                  const textX = 250 + 150 * Math.cos(textRad)
                  const textY = 250 + 150 * Math.sin(textRad)
                  const textRotation = startAngle + angle / 2

                  return (
                    <g key={`${prize.id}-${index}`}>
                      <path
                        d={path}
                        fill={index % 2 === 0 ? "#1a1a1a" : "dark-bg"}
                        stroke="#1A1A1A"
                        strokeWidth="2"
                      />
                      <g transform={`rotate(${textRotation}, ${textX}, ${textY})`}>
                        <foreignObject x={textX - 30} y={textY - 30} width="65" height="65">
                          <div className="flex items-center justify-center h-full w-full">
                            {prize.type === "tp" ? (
                              <Image src="/logo.svg" alt="tp" width={45} height={45} />
                            ) : (
                              <FaTicketAlt className="w-10 h-10 text-tp" />
                            )}
                          </div>
                        </foreignObject>
                      </g>
                    </g>
                  )
                })}

                <circle cx="250" cy="250" r="40" fill="#000" stroke="#ff6b35" strokeWidth="2" />
                <circle cx="250" cy="250" r="30" fill="url(#centerGlow)" />

                <defs>
                  <radialGradient id="centerGlow" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                    <stop offset="0%" stopColor="#ff6b35" stopOpacity="0.6" />
                    <stop offset="100%" stopColor="#000" stopOpacity="0" />
                  </radialGradient>
                </defs>
              </svg>
            </div>
          </div>

          <div className="w-full max-w-xs grid grid-cols-2 gap-3">
            <motion.div whileTap={{ scale: 0.98 }} className="col-span-1">
              <Button
                onClick={handleSpin}
                disabled={isSpinning}
                className={`w-full h-12 rounded-2xl font-medium text-sm ${
                  isSpinning
                    ? "dark-bg text-[#a0a0a0]"
                    : "fire-gradient"
                }`}
              >
                {isSpinning ? (
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  </div>
                ) : (
                  `Spen (1 Ticket)`
                )}
              </Button>
            </motion.div>

            <div className="col-span-1">
              <Button
                onClick={() => setShowTicketDialog(true)}
                className="w-full h-12 dark-bg hover:bg-[#1a1a1a] rounded-2xl font-medium text-sm"
              >
                <FaTicketAlt className="w-4 h-4 text-tp mr-1" />
                Buy Tickets
              </Button>
            </div>
          </div>
        </div>

        <Dialog open={showResultDialog} onOpenChange={setShowResultDialog}>
          <DialogContent className="w-[95%] mx-auto gradient-dark rounded-3xl">
            <DialogHeader className="text-center">
              <DialogTitle className="fire-text text-xl font-bold">Congratulations!</DialogTitle>
              <DialogDescription className="text-[#a0a0a0] text-sm">You won an amazing prize!</DialogDescription>
            </DialogHeader>

            <DialogBody className="px-6 py-4">
              {spinResult && (
                <div className="text-center">
                  <div className="space-y-4">
                    <div className="w-20 h-20 mx-auto bg-tp rounded-full flex items-center justify-center">
                      {spinResult.type === "tp" ? (
                        <Image src="/logo.svg" alt="tp" width={65} height={65} />
                      ) : (
                        <FaTicketAlt className="w-16 h-16 text-white" />
                      )}
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold fire-text mb-2">
                        {spinResult.amount?.toLocaleString()} {spinResult.type === "tp" ? `${SIMPLE}` : "Tickets"}
                      </h3>
                      <p className="text-[#a0a0a0] text-sm">
                        {spinResult.type === "tp" ? `${SIMPLE} have been added to your balance!` : "Tickets have been added to your balance!"}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </DialogBody>

            <DialogFooter className="px-6 pb-6">
              <Button
                onClick={() => setShowResultDialog(false)}
                className="w-full fire-gradient rounded-2xl h-12"
              >
                Awesome!
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <TicketPurchaseDialog 
          open={showTicketDialog} 
          onOpenChange={setShowTicketDialog}
          onPurchaseSuccess={(newTickets) => {
            setTicketsBalance(prev => prev + newTickets)
            setShowTicketDialog(false)
          }}
          userBalance={tpBalance}
        />
      </div>
    </AppLayout>
  )
}

"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { LoadingScreen } from "@/components/loading-screen"
import { AppLayout } from "@/components/app-layout"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "@/components/ui/dialog"
import { FaTicketAlt, FaClock, FaPlay, FaStop } from "react-icons/fa"
import { GoGoal } from "react-icons/go"
import { TicketPurchaseDialog } from "@/components/ticket-purchase-dialog"
import { motion } from "framer-motion"
import Image from "next/image"
import { formatBalance } from "@/lib/utils"
import { SIMPLE, NAME } from "@/lib/config"

interface GameResult {
  won: boolean
  targetTime: number
  actualTime: number
  reward: number
  timestamp: number
}

const GAME_SPEED = 5;

export default function TimerGame() {
  const router = useRouter()
  const { toast } = useToast()

  const [isLoading, setIsLoading] = useState(true)
  const [ticketsBalance, setTicketsBalance] = useState(0)
  const [tpBalance, setTpBalance] = useState(0)
  const [showTicketDialog, setShowTicketDialog] = useState(false)
  const [showResultDialog, setShowResultDialog] = useState(false)
  const [gameResult, setGameResult] = useState<GameResult | null>(null)

  const [isGameActive, setIsGameActive] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [targetTime, setTargetTime] = useState(0)
  const [gameStarted, setGameStarted] = useState(false)
  const [canStop, setCanStop] = useState(false)
  const [showTarget, setShowTarget] = useState(false)

  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const gameStartTimeRef = useRef<number>(0)
  const animationFrameRef = useRef<number>(0)
  const stopTimeRef = useRef<number>(0)

  const fetchUserData = useCallback(async () => {
    try {
      if (typeof window === "undefined" || !window.Telegram?.WebApp?.initData) {
        return
      }

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_or_create_user",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setTicketsBalance(data.user.tickets_balance || 0)
        setTpBalance(data.user.balance || 0)
      }
    } catch (error) {
      console.error("Error fetching user data:", error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUserData()
  }, [fetchUserData])

  const generateTargetTime = () => {
    const minTime = 5000 
    const maxTime = 11000
    return Math.floor(Math.random() * (maxTime - minTime + 1)) + minTime
  }

  const calculateReward = (targetTimeMs: number) => {
    const targetSeconds = (targetTimeMs / 1000) * GAME_SPEED
    let baseReward = 5000

    if (targetSeconds <= 10) {
      baseReward = 80000
    } else if (targetSeconds <= 20) {
      baseReward = 75000
    } else if (targetSeconds <= 30) {
      baseReward = 50000
    } else if (targetSeconds <= 45) {
      baseReward = 25000
    } else if (targetSeconds <= 60) {
      baseReward = 15000
    } else {
      baseReward = 10000
    }

    return baseReward
  }

  const formatTime = (timeMs: number) => {
    const gameTimeMs = timeMs * GAME_SPEED
    const totalSeconds = Math.floor(gameTimeMs / 1000)
    const minutes = Math.floor(totalSeconds / 60)
    const seconds = totalSeconds % 60
    const milliseconds = Math.floor((gameTimeMs % 1000) / 10)
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}.${milliseconds.toString().padStart(2, "0")}`
  }

  const formatTargetTime = (timeMs: number) => {
    const gameTimeMs = timeMs * GAME_SPEED
    const totalSeconds = Math.floor(gameTimeMs / 1000)
    const minutes = Math.floor(totalSeconds / 60)
    const seconds = totalSeconds % 60
    const milliseconds = Math.floor((gameTimeMs % 1000) / 10)
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}.${milliseconds.toString().padStart(2, "0")}`
  }

  const formatResultTime = (gameTimeMs: number) => {
    const totalSeconds = Math.floor(gameTimeMs / 1000)
    const minutes = Math.floor(totalSeconds / 60)
    const seconds = totalSeconds % 60
    const milliseconds = Math.floor((gameTimeMs % 1000) / 10)
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}.${milliseconds.toString().padStart(2, "0")}`
  }

  const startGame = async () => {
    if (ticketsBalance < 1) {
      setShowTicketDialog(true)
      return
    }

    if (!showTarget) {
      const newTargetTime = generateTargetTime()
      setTargetTime(newTargetTime)
      setShowTarget(true)
      return
    }

    try {
      const useTicketResponse = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "use_ticket",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (!useTicketResponse.ok) {
        throw new Error("Failed to use ticket")
      }

      setTicketsBalance((prev) => prev - 1)

      setCurrentTime(0)
      setIsGameActive(true)
      setGameStarted(true)
      setCanStop(false)
      stopTimeRef.current = 0

      const startTimestamp = performance.now()
      gameStartTimeRef.current = startTimestamp

      setTimeout(() => {
        setCanStop(true)
      }, 100)

      const updateTime = () => {
        const elapsed = performance.now() - startTimestamp
        setCurrentTime(elapsed)
        animationFrameRef.current = requestAnimationFrame(updateTime)
      }

      animationFrameRef.current = requestAnimationFrame(updateTime)
    } catch (error) {
      console.error("Start game error:", error)
      toast({
        title: "Game Error",
        description: "An error occurred while starting the game, please try again",
        variant: "destructive",
      })
    }
  }

  const stopGame = async () => {
    if (!isGameActive || !canStop) return

    const stopTimestamp = performance.now()
    stopTimeRef.current = stopTimestamp

    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current)
      animationFrameRef.current = 0
    }

    if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }

    const finalElapsed = stopTimestamp - gameStartTimeRef.current
    setCurrentTime(finalElapsed)

    setIsGameActive(false)
    setGameStarted(false)
    setCanStop(false)
    setShowTarget(false)

    const finalTime = stopTimeRef.current - gameStartTimeRef.current
    const gameFinalTime = finalTime * GAME_SPEED
    const gameTargetTime = targetTime * GAME_SPEED
    
    const difference = Math.abs(gameFinalTime - gameTargetTime)
    const tolerance = gameTargetTime * 0.03

    const randomWin = Math.random() < 0.5
    const accurateStop = difference <= tolerance
    const won = randomWin && accurateStop

    let reward = 0
    if (won) {
      reward = calculateReward(targetTime)

      await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "update_balance",
          initData: window.Telegram.WebApp.initData,
          miningData: { newBalance: reward },
        }),
      })

      setTpBalance((prev) => prev + reward)
    }

    const result: GameResult = {
      won,
      targetTime: gameTargetTime,
      actualTime: gameFinalTime,
      reward,
      timestamp: Date.now(),
    }

    setGameResult(result)
    setShowResultDialog(true)
  }

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
    }
  }, [])

  if (isLoading) {
    return <LoadingScreen />
  }

  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full flex flex-col pb-20 overflow-x-hidden">
        <div className="text-center pt-6 pb-4 px-4">
          <h1 className="text-2xl font-bold fire-text mb-1">Timer Challenge</h1>
          <p className="text-[#a0a0a0] text-sm">Stop the timer at the exact target time!</p>
        </div>

        <div className="flex justify-center items-center gap-4 mb-8 px-4">
          <div className="flex items-center gap-2">
            <FaTicketAlt className="w-4 h-4 text-tp" />
            <span className="text-sm font-medium">{formatBalance(ticketsBalance)}</span>
          </div>

          <div className="flex items-center gap-2">
            <Image src="/logo.svg" alt="tp" width={20} height={20} />
            <span className="text-sm font-medium">{formatBalance(tpBalance)}</span>
          </div>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-4">
          <div className="w-full max-w-xs">
            <div className="text-center mb-8">
              <div className="relative">
                <div className="w-48 h-48 mx-auto rounded-full border-4 border-[#1A1A1A] flex items-center justify-center dark-bg">
                  <div className="text-center">
                    <FaClock className="w-8 h-8 text-tp mx-auto mb-2" />
                    <div className="text-3xl font-bold fire-text font-mono">{formatTime(currentTime)}</div>
                    <p className="text-[#a0a0a0] text-xs mt-1">{isGameActive ? "Running..." : "Waiting"}</p>
                  </div>
                </div>

                {isGameActive && (
                  <div className="absolute inset-0 w-48 h-48 mx-auto rounded-full border-4 border-tp animate-pulse"></div>
                )}
              </div>
            </div>

            <div className={`flex items-center justify-center h-12 mb-6 transition-all duration-300 ${showTarget ? 'min-h-[48px]' : 'min-h-[48px]'}`}>
              <div className={`flex items-center justify-between dark-bg rounded-2xl px-4 py-3 w-full max-w-xs h-12`}>
                <div className="flex items-center gap-2">
                  <GoGoal className="w-4 h-4 text-tp" />
                  <span className="text-sm font-medium text-white">Target</span>
                </div>
                <div className="text-sm font-bold font-mono text-white">
                  {showTarget && targetTime > 0 ? formatTargetTime(targetTime) : "00:00.00"}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              {!gameStarted ? (
                <div className="flex gap-3">
                  <motion.div whileTap={{ scale: 0.98 }} className="flex-1">
                    <Button onClick={startGame} className="w-full h-12 rounded-2xl font-medium text-sm fire-gradient">
                      <FaPlay className="w-4 h-4 mr-2" />
                      {showTarget ? "Start Game" : "Get Target"}
                    </Button>
                  </motion.div>

                  <motion.div whileTap={{ scale: 0.98 }} className="flex-1">
                    <Button
                      onClick={() => setShowTicketDialog(true)}
                      className="w-full h-12 dark-bg hover:bg-[#1a1a1a] rounded-2xl font-medium text-sm"
                    >
                      <FaTicketAlt className="w-4 h-4 text-tp mr-2" />
                      Buy Tickets
                    </Button>
                  </motion.div>
                </div>
              ) : (
                <motion.div whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={stopGame}
                    disabled={!canStop}
                    className={`w-full h-12 rounded-2xl font-medium text-sm ${
                      canStop ? "bg-[#a0a0a0]/50 hover:bg-[#a0a0a0]/20 text-white" : "dark-bg text-[#a0a0a0] cursor-not-allowed"
                    }`}
                  >
                    <FaStop className="w-4 h-4 mr-2" />
                    {canStop ? "Stop Now!" : "Wait..."}
                  </Button>
                </motion.div>
              )}
            </div>

            <div className="mt-6 dark-bg rounded-2xl p-4">
              <h3 className="text-white font-medium text-sm mb-2">How to Play:</h3>
              <ul className="text-[#a0a0a0] text-xs space-y-1">
                <li>• Click "Get Target" to see your target time</li>
                <li>• Click "Start Game" to begin the timer</li>
                <li>• Stop the timer exactly at the target time</li>
                <li>• Shorter targets = higher rewards</li>
                <li>• Stopping within ±10 seconds of target counts as win</li>
              </ul>
            </div>
          </div>
        </div>

        <Dialog open={showResultDialog} onOpenChange={setShowResultDialog}>
          <DialogContent className="w-[95%] mx-auto gradient-dark rounded-3xl">
            <DialogHeader className="text-center">
              <DialogTitle className={`text-xl font-bold ${gameResult?.won ? "fire-text" : "text-red-400"}`}>
                {gameResult?.won ? "Congratulations! You Won!" : "Sorry, You Lost This Time"}
              </DialogTitle>
              <DialogDescription className="text-[#a0a0a0] text-sm">
                {gameResult?.won ? "You stopped the timer at the perfect time!" : "Try again to win"}
              </DialogDescription>
            </DialogHeader>

            <DialogBody className="px-6 py-4">
              {gameResult && (
                <div className="text-center space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="dark-bg rounded-xl p-3">
                      <p className="text-[#a0a0a0] text-xs mb-1">Target Time</p>
                      <p className="text-white font-bold font-mono">{formatResultTime(gameResult.targetTime)}</p>
                    </div>
                    <div className="dark-bg rounded-xl p-3">
                      <p className="text-[#a0a0a0] text-xs mb-1">Your Time</p>
                      <p className="text-white font-bold font-mono">{formatResultTime(gameResult.actualTime)}</p>
                    </div>
                  </div>

                  {gameResult.won && (
                    <div className="w-20 h-20 mx-auto bg-tp rounded-full flex items-center justify-center">
                      <Image src="/logo.svg" alt="tp" width={50} height={50} />
                    </div>
                  )}

                  <div>
                    <h3 className={`text-2xl font-bold mb-2 ${gameResult.won ? "fire-text" : "text-[#a0a0a0]"}`}>
                      {gameResult.won ? `+${formatBalance(gameResult.reward)} ${SIMPLE}` : `0 ${SIMPLE}`}
                    </h3>
                    <p className="text-[#a0a0a0] text-sm">
                      {gameResult.won ? "Reward added to your balance!" : "No reward this time"}
                    </p>
                  </div>
                </div>
              )}
            </DialogBody>

            <DialogFooter className="px-6 pb-6">
              <Button onClick={() => setShowResultDialog(false)} className="w-full fire-gradient rounded-2xl h-12">
                Play Again
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <TicketPurchaseDialog
          open={showTicketDialog}
          onOpenChange={setShowTicketDialog}
          onPurchaseSuccess={(newTickets) => {
            setTicketsBalance((prev) => prev + newTickets)
            setShowTicketDialog(false)
          }}
          userBalance={tpBalance}
        />
      </div>
    </AppLayout>
  )
}

"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { LoadingScreen } from "@/components/loading-screen"
import { AppLayout } from "@/components/app-layout"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "@/components/ui/dialog"
import { FaTicketAlt, FaCoins, FaBomb, FaGem, FaPlay } from "react-icons/fa"
import { TicketPurchaseDialog } from "@/components/ticket-purchase-dialog"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import Image from "next/image"
import { formatBalance } from "@/lib/utils"
import { SIMPLE, NAME } from "@/lib/config"
import { PiHandWithdrawFill } from "react-icons/pi"

const GRID_SIZE = 5
const BASE_REWARD_MULTIPLIER = 0.05
const MAX_MULTIPLIER = 1.5
const WIN_RATE = 0.5 
const LOSE_RATE = 0.5 

type CellContent = "diamond" | "mine"
type CellStatus = "hidden" | "revealed"

interface Cell {
  id: string
  content: CellContent
  status: CellStatus
}

export default function DiamondMineGame() {
  const router = useRouter()
  const { toast } = useToast()

  const [isLoading, setIsLoading] = useState(true)
  const [board, setBoard] = useState<Cell[][]>([])
  const [gameOver, setGameOver] = useState(false)
  const [gameWon, setGameWon] = useState(false)
  const [diamondsFound, setDiamondsFound] = useState(0)
  const [potentialWithdrawal, setPotentialWithdrawal] = useState(0)
  const [betAmount, setBetAmount] = useState(0)
  const [ticketsBalance, setTicketsBalance] = useState(0)
  const [tpBalance, setTpBalance] = useState(0)
  const [showBetDialog, setShowBetDialog] = useState(false)
  const [showMinesDialog, setShowMinesDialog] = useState(false)
  const [showTicketDialog, setShowTicketDialog] = useState(false)
  const [betPercentage, setBetPercentage] = useState(1)
  const [minesCount, setMinesCount] = useState(15)
  const [initialized, setInitialized] = useState(false)
  const [currentMinesCount, setCurrentMinesCount] = useState(15)

  const fetchUserData = useCallback(async () => {
    try {
      if (typeof window === "undefined" || !window.Telegram?.WebApp?.initData) {
        return
      }

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_or_create_user",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setTpBalance(data.user.balance || 0)
        setTicketsBalance(data.user.tickets_balance || 0)
      }
    } catch (error) {
      console.error("Error fetching user data:", error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUserData()
  }, [fetchUserData])

  const deductBetAmount = useCallback(async (amount: number) => {
    try {
      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "deduct_balance",
          initData: window.Telegram.WebApp.initData,
          amount: amount,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to deduct balance")
      }

      const data = await response.json()
      setTpBalance(data.balance || 0)
      return true
    } catch (error) {
      console.error("Error deducting bet amount:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to deduct balance",
        variant: "destructive",
      })
      return false
    }
  }, [toast])

  const useTicket = useCallback(async () => {
    try {
      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "use_ticket",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        if (data.success) {
          setTicketsBalance(prev => {
            const newBalance = prev - 1
            return newBalance >= 0 ? newBalance : 0
          })
          return true
        }
      }
      return false
    } catch (error) {
      console.error("Error using ticket:", error)
      return false
    }
  }, [])

  const addReward = useCallback(async (amount: number) => {
    try {
      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "update_balance",
          initData: window.Telegram.WebApp.initData,
          miningData: { newBalance: amount },
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setTpBalance(data.balance || 0)
        return true
      }
      return false
    } catch (error) {
      console.error("Error adding reward:", error)
      return false
    }
  }, [])

  const initializeBoard = useCallback((mines: number) => {
    const newBoard: Cell[][] = Array.from({ length: GRID_SIZE }, (_, row) =>
      Array.from({ length: GRID_SIZE }, (_, col) => ({
        id: `${row}-${col}`,
        content: "diamond",
        status: "hidden",
      }))
    ) 

    const allPositions = []
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        allPositions.push({ row: r, col: c })
      }
    }

    for (let i = allPositions.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[allPositions[i], allPositions[j]] = [allPositions[j], allPositions[i]]
    }

    for (let i = 0; i < mines; i++) {
      const { row, col } = allPositions[i]
      newBoard[row][col].content = "mine"
    }

    setCurrentMinesCount(mines)
    setBoard(newBoard)
    setGameOver(false)
    setGameWon(false)
    setDiamondsFound(0)
    setPotentialWithdrawal(betAmount)
    setInitialized(true)
  }, [betAmount])

  const startGame = async () => {
    if (initialized && !gameOver && !gameWon) return

    if (ticketsBalance < 1) {
      setShowTicketDialog(true)
      return
    }

    const calculatedBet = Math.floor(tpBalance * (betPercentage / 100))
    if (calculatedBet <= 0) {
      toast({
        title: "Insufficient Balance",
        description: "Your balance is too low for this bet",
        variant: "destructive",
      })
      return
    }

    const ticketSuccess = await useTicket()
    if (!ticketSuccess) {
      toast({
        title: "Error",
        description: "Failed to use ticket, please try again",
        variant: "destructive",
      })
      return
    }

    const betSuccess = await deductBetAmount(calculatedBet)
    if (!betSuccess) {
      return
    }

    setBetAmount(calculatedBet)
    initializeBoard(minesCount)
  }

  const handleCellClick = async (row: number, col: number) => {
    if (gameOver || gameWon || board[row][col].status === "revealed") {
      return
    }

    const newBoard = board.map((r) => [...r])
    const clickedCell = newBoard[row][col]

    const shouldConvertToMine = Math.random() > WIN_RATE && clickedCell.content === "diamond"

    if (shouldConvertToMine) {
      clickedCell.content = "mine"
      if (currentMinesCount > 1) {
        setCurrentMinesCount(prev => prev - 1)
        
        const minePositions = []
        for (let r = 0; r < GRID_SIZE; r++) {
          for (let c = 0; c < GRID_SIZE; c++) {
            if (newBoard[r][c].content === "mine" && !(r === row && c === col)) {
              minePositions.push({ row: r, col: c })
            }
          }
        }
        
        if (minePositions.length > 0) {
          const randomMine = minePositions[Math.floor(Math.random() * minePositions.length)]
          newBoard[randomMine.row][randomMine.col].content = "diamond"
        }
      }
      
      setPotentialWithdrawal(prev => Math.floor(prev * 1.1))
    }

    clickedCell.status = "revealed"

    if (clickedCell.content === "mine") {
      setGameOver(true)
      toast({
        title: "Game Over",
        description: `You hit a mine and lost ${betAmount.toLocaleString()} ${SIMPLE}!`,
        variant: "destructive",
      })
      newBoard.forEach((r) => r.forEach((cell) => { cell.status = "revealed" }))
    } else {
      const newDiamondsFound = diamondsFound + 1
      const rewardPerDiamond = betAmount * (1 + (currentMinesCount * 0.03)) * 0.3
      const newPotential = Math.floor(betAmount + (rewardPerDiamond * newDiamondsFound))
      
      setDiamondsFound(newDiamondsFound)
      setPotentialWithdrawal(Math.min(newPotential, betAmount * 2))

      if (newDiamondsFound === (GRID_SIZE * GRID_SIZE - currentMinesCount)) {
        setGameWon(true)
        setGameOver(true)
        const rewardSuccess = await addReward(potentialWithdrawal)
        if (rewardSuccess) {
          toast({
            title: "Congratulations!",
            description: `You won ${potentialWithdrawal.toLocaleString()} ${SIMPLE}!`,
          })
        }
      }
    }

    setBoard(newBoard)
  }

  const handleWithdraw = async () => {
    if (diamondsFound > 0 && !gameOver && !gameWon) {
      const rewardSuccess = await addReward(potentialWithdrawal)
      if (rewardSuccess) {
        setGameWon(true)
        setGameOver(true)
        toast({
          title: "Success!",
          description: `You withdrew ${potentialWithdrawal.toLocaleString()} ${SIMPLE}!`,
        })
        const newBoard = board.map((r) => [...r])
        newBoard.forEach((r) => r.forEach((cell) => (cell.status = "revealed")))
        setBoard(newBoard)
      }
    }
  }

  const resetGame = () => {
    setInitialized(false)
    setGameOver(false)
    setGameWon(false)
    setBetPercentage(1)
    setMinesCount(4)
    setCurrentMinesCount(4)
    setBoard([])
  }

  const renderCell = (cell: Cell) => {
    const isRevealed = cell.status === "revealed"
    const isMine = cell.content === "mine"
    const isDiamond = cell.content === "diamond"

    return (
      <Button
        key={cell.id}
        className={cn(
          "w-14 h-14 flex items-center justify-center text-xl font-bold rounded-xl transition-all duration-200 border",
          isRevealed
            ? isMine
              ? "bg-red-500/20 border-red-600/90 text-white"
              : "gradient-dark tp-border text-white"
            : "dark-bg hover:bg-[#2a2a2a] text-white",
          (!initialized || gameOver || gameWon) && "cursor-not-allowed"
        )}
        onClick={() => handleCellClick(Number.parseInt(cell.id.split("-")[0]), Number.parseInt(cell.id.split("-")[1]))}
        disabled={!initialized || gameOver || gameWon || isRevealed}
      >
        {isRevealed ? (
          isMine ? (
            <FaBomb className="w-6 h-6 text-white" />
          ) : (
            <FaGem className="w-6 h-6 text-white" />
          )
        ) : (
          <div className="w-5 h-5 rounded-sm dark-bg" />
        )}
      </Button>
    )
  }

  if (isLoading) {
    return <LoadingScreen />
  }

  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full flex flex-col pb-20 overflow-x-hidden">
        <div className="text-center pt-6 pb-4 px-4">
          <h1 className="text-2xl font-bold fire-text mb-1">Diamond Mine</h1>
          <p className="text-[#a0a0a0] text-sm">Find diamonds and avoid bombs to win!</p>
        </div>

        <div className="flex justify-center items-center gap-4 mb-4 px-4">
          <div className="flex items-center gap-2">
            <FaTicketAlt className="w-4 h-4 text-tp" />
            <span className="text-sm font-medium">{formatBalance(ticketsBalance)}</span>
          </div>

          <div className="flex items-center gap-2">
            <Image src="/logo.svg" alt="tp" width={20} height={20} />
           <span className="text-sm font-medium">{formatBalance(tpBalance)}</span>
          </div>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-4">
          <div className="w-full max-w-xs">
            <div className="grid gap-3 mb-6 mx-auto" 
                 style={{ gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))`, width: 'fit-content' }}>
              {board.length > 0 ? (
                board.flat().map(renderCell)
              ) : (
                Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, i) => (
                  <div key={i} className="w-14 h-14 dark-bg rounded-xl" />
                ))
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <motion.div whileTap={{ scale: 0.98 }}>
                <Button 
                  onClick={() => setShowMinesDialog(true)}
                  className="w-full dark-bg hover:bg-[#1a1a1a] h-12 rounded-2xl flex flex-col items-center justify-center gap-1"
                >
                  <FaBomb className="w-4 h-4 text-tp" />
                  <span className="text-xs font-medium">Bombs {minesCount}</span>
                </Button>
              </motion.div>
              
              <motion.div whileTap={{ scale: 0.98 }}>
                <Button 
                  onClick={() => setShowBetDialog(true)}
                  className="w-full dark-bg hover:bg-[#1a1a1a] h-12 rounded-2xl flex flex-col items-center justify-center gap-1"
                >
                  <FaCoins className="w-4 h-4 text-tp" />
                  <span className="text-xs font-medium">Bet {betPercentage}%</span>
                </Button>
              </motion.div>
            </div>

            <div className="mt-4">
             <motion.div whileTap={{ scale: 0.98 }}>
              <Button                     
                onClick={gameOver || gameWon || !initialized ? startGame : handleWithdraw}
                className={`w-full h-12 rounded-2xl font-medium flex items-center justify-center gap-2 ${
                  gameOver || gameWon || !initialized
                ? "fire-gradient"
                : "bg-green-500 hover:bg-green-600"
                }`}
                 disabled={initialized && !gameOver && !gameWon && diamondsFound === 0}
               >
                  {gameOver || gameWon || !initialized ? (
                <>
                  <FaPlay className="w-4 h-4" />
                  Start Game
                </>
               ) : (
                 <>
                  <PiHandWithdrawFill className="w-4 h-4" />
                   Withdraw (${potentialWithdrawal.toLocaleString()} ${SIMPLE})
                 </>
                )}
              </Button>
             </motion.div>
            </div>
            
            <div className="mt-6 dark-bg rounded-2xl p-4">
              <h3 className="text-white font-medium text-sm mb-2">How to Play:</h3>
              <ul className="text-[#a0a0a0] text-xs space-y-1">
                <li>• Choose your bet amount</li>
                <li>• Select the number of bombs (more bombs = higher rewards)</li>
                <li>• Start the game using a ticket and your chosen bet</li>
                <li>• Click on the hidden cells to reveal what’s inside</li>
                <li>• Diamonds increase your reward and let you keep playing</li>
                <li>• Hitting a bomb ends the game and you lose your bet</li>
                <li>• You can withdraw your winnings anytime before hitting a bomb</li>
              </ul>
            </div>
          </div>
        </div>

        <Dialog open={showBetDialog} onOpenChange={setShowBetDialog}>
          <DialogContent className="w-[95%] max-w-md mx-auto gradient-dark rounded-3xl">
            <DialogHeader className="text-center">
              <DialogTitle className="fire-text text-xl font-bold">Bet Amount</DialogTitle>
              <DialogDescription className="text-[#a0a0a0] text-sm">
                Choose percentage of your balance to bet
              </DialogDescription>
            </DialogHeader>

            <DialogBody className="px-6 py-4">
              <div className="flex items-center justify-center gap-4 mb-6">
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={() => setBetPercentage(prev => Math.max(1, prev - 1))}
                  className="dark-bg hover:bg-[#1a1a1a] border border-[#1A1A1A]"
                >
                  -
                </Button>
                
                <div className="text-2xl font-bold fire-text w-20 text-center">
                  {betPercentage}%
                </div>
                
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={() => setBetPercentage(prev => Math.min(100, prev + 1))}
                  className="dark-bg hover:bg-[#1a1a1a] border border-[#1A1A1A]"
                >
                  +
                </Button>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {[1, 5, 10, 25, 50, 100].map((value) => (
                  <Button
                    key={value}
                    onClick={() => setBetPercentage(value)}
                    className={cn(
                      "py-2 rounded-lg",
                      betPercentage === value ? "fire-gradient text-white" : "dark-bg hover:bg-[#1a1a1a] border border-[#1A1A1A]"
                    )}
                  >
                    {value}%
                  </Button>
                ))}
              </div>
            </DialogBody>

            <DialogFooter className="px-6 pb-6">
              <Button 
                onClick={() => setShowBetDialog(false)}
                className="w-full fire-gradient text-white h-12 rounded-xl"
              >
                Confirm
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={showMinesDialog} onOpenChange={setShowMinesDialog}>
          <DialogContent className="w-[95%] max-w-md mx-auto gradient-dark rounded-3xl">
            <DialogHeader className="text-center">
              <DialogTitle className="fire-text text-xl font-bold">Number of bombs</DialogTitle>
              <DialogDescription className="text-[#a0a0a0] text-sm">
                More bombs = higher rewards (max 4x)
              </DialogDescription>
            </DialogHeader>

            <DialogBody className="px-6 py-4">
              <div className="flex items-center justify-center gap-4 mb-6">
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={() => setMinesCount(prev => Math.max(6, prev - 1))}
                  className="dark-bg hover:bg-[#1a1a1a] border border-[#1A1A1A]"
                  disabled={minesCount <= 6}
                >
                  -
                </Button>
                
                <div className="text-2xl font-bold fire-text w-20 text-center">
                  {minesCount}
                </div>
                
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={() => setMinesCount(prev => Math.min(15, prev + 1))}
                  className="dark-bg hover:bg-[#1a1a1a] border border-[#1A1A1A]"
                  disabled={minesCount >= 15}
                >
                  +
                </Button>
              </div>

              <div className="grid grid-cols-5 gap-2">
                {[6, 7, 8, 9, 10, 11, 12, 13, 14, 15].map((value) => (
                  <Button
                    key={value}
                    onClick={() => setMinesCount(value)}
                    className={cn(
                      "py-2 rounded-lg",
                      minesCount === value ? "fire-gradient text-white" : "dark-bg hover:bg-[#1a1a1a] border border-[#1A1A1A]"
                    )}
                  >
                    {value}
                  </Button>
                ))}
              </div>
            </DialogBody>

            <DialogFooter className="px-6 pb-6">
              <Button 
                onClick={() => setShowMinesDialog(false)}
                className="w-full fire-gradient text-white h-12 rounded-xl"
              >
                Confirm
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <TicketPurchaseDialog 
          open={showTicketDialog} 
          onOpenChange={setShowTicketDialog}
          onPurchaseSuccess={(newTickets) => {
            setTicketsBalance(prev => prev + newTickets)
            setShowTicketDialog(false)
          }}
          userBalance={tpBalance}
        />
      </div>
    </AppLayout>
  )
}

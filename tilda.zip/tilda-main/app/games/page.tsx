"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { AppLayout } from "@/components/app-layout"
import { BottomNavigation } from "@/components/bottom-navigation"
import { motion } from "framer-motion"
import { Skeleton } from "@/components/ui/skeleton"
import { SpinnerBall, SketchLogo, Ticket, Timer, Package } from "@phosphor-icons/react"

export default function GamesPage() {
  const router = useRouter()
  const [games, setGames] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchGames = async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 1000))

        setGames([
          {
            id: 1,
            title: "Lucky Wheel",
            description: "Spin the wheel and win random prizes",
            icon: <SpinnerBall className="w-6 h-6" />,
            path: "/games/wheel",
            color: "bg-[#FF6B6B]/10",
            iconColor: "text-[#FF6B6B]",
          },
          {
            id: 2,
            title: "Timer Challenge",
            description: "Stop the timer at the specified target and win a random reward.",
            icon: <Timer className="w-6 h-6" />,
            path: "/games/timer",
            color: "bg-[#10B981]/10",
            iconColor: "text-[#10B981]",
          },
          {
            id: 3,
            title: "Diamond Mine",
            description: "Collect as many diamonds as you can",
            icon: <SketchLogo className="w-6 h-6" />,
            path: "/games/diamond",
            color: "bg-[#45aef5]/10",
            iconColor: "text-[#45aef5]",
          },
          {
            id: 4,
            title: "Lucky Boxes",
            description: "Choose 3 boxes and discover your prizes",
            icon: <Package className="w-6 h-6" />,
            path: "/games/boxes",
            color: "bg-[#A855F7]/10",
            iconColor: "text-[#A855F7]",
          },
        ])
      } catch (error) {
        console.error("Error fetching games:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchGames()
  }, [])

  if (isLoading) {
    return (
      <AppLayout>
        <div className="min-h-screen text-white w-full">
          <div className="pb-24 pt-4 w-[90%] mx-auto max-w-md">
            <div className="text-center mb-6">
              <h1 className="text-2xl font-bold fire-text mb-1">Games</h1>
              <p className="text-[#a0a0a0] text-sm">Play games and earn real rewards</p>
            </div>

            <div className="space-y-4">
              {[...Array(4)].map((_, index) => (
                <div key={index} className="bg-[#0f0f0f] rounded-2xl p-4">
                  <div className="flex items-center gap-4">
                    <Skeleton className="w-12 h-12 bg-[#1A1A1A] rounded-xl" />
                    <div className="flex-1 min-w-0 space-y-2">
                      <Skeleton className="h-4 w-32 bg-[#1A1A1A]" />
                      <Skeleton className="h-3 w-36 bg-[#1A1A1A]" />
                      <div className="flex items-center mt-1">
                        <Skeleton className="w-3 h-3 bg-[#1A1A1A] rounded mr-1" />
                        <Skeleton className="h-3 w-16 bg-[#1A1A1A] rounded" />
                      </div>
                    </div>
                    <Skeleton className="h-8 w-16 bg-[#1A1A1A] rounded-xl" />
                  </div>
                </div>
              ))}
            </div>
          </div>
          <BottomNavigation />
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full">
        <div className="pb-24 pt-4 w-[90%] mx-auto max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold fire-text mb-1">Games</h1>
            <p className="text-[#a0a0a0] text-sm">Play games and earn real rewards</p>
          </div>

          <div className="space-y-4">
            {games.map((game) => (
              <motion.div
                key={game.id}
                whileTap={{ scale: 0.98 }}
                onClick={() => router.push(game.path)}
                className={`dark-bg rounded-2xl p-4 cursor-pointer hover:bg-[#1a1a1a] transition-colors`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 ${game.color} rounded-xl flex items-center justify-center flex-shrink-0`}>
                    <span className={game.iconColor}>{game.icon}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-white font-medium text-sm truncate">{game.title}</h3>
                    <p className="text-[#a0a0a0] text-xs truncate">{game.description}</p>
                    <div className="flex items-center mt-1">
                      <Ticket className="w-3 h-3 text-tp mr-1" />
                      <span className="text-[10px] text-[#a0a0a0]">1 ticket per play</span>
                    </div>
                  </div>
                  <Button size="sm" className="fire-gradient rounded-xl h-8 px-3 flex-shrink-0">
                    Play
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
        <BottomNavigation />
      </div>
    </AppLayout>
  )
}

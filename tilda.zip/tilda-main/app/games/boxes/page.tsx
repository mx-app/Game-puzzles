"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { AppLayout } from "@/components/app-layout"
import { useToast } from "@/components/ui/use-toast"
import { LoadingScreen } from "@/components/loading-screen"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "@/components/ui/dialog"
import Image from "next/image"
import { FaTicketAlt, FaGift, FaTimes } from "react-icons/fa"
import { motion } from "framer-motion"
import { TicketPurchaseDialog } from "@/components/ticket-purchase-dialog"
import { formatBalance, format } from "@/lib/utils"
import { SIMPLE } from "@/lib/config"
import { MdQuestionMark } from "react-icons/md"

interface BoxResult {
  id: string
  type: "tp" | "empty"
  amount: number
  timestamp: number
}

interface Box {
  id: number
  isRevealed: boolean
  content: "prize" | "empty"
  prizeAmount?: number
}

const generateRandomPrize = (): number => {
  const min = 5000
  const max = 100000
  return Math.floor(Math.random() * (max - min + 1)) + min
}

export default function LuckyBoxesPage() {
  const router = useRouter()
  const { toast } = useToast()

  const [isLoading, setIsLoading] = useState(true)
  const [showTicketDialog, setShowTicketDialog] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [gameResult, setGameResult] = useState<BoxResult | null>(null)
  const [showResultDialog, setShowResultDialog] = useState(false)
  const [boxes, setBoxes] = useState<Box[]>([])
  const [ticketsBalance, setTicketsBalance] = useState(0)
  const [tpBalance, setTpBalance] = useState(0)
  const [selectedBoxes, setSelectedBoxes] = useState<number[]>([])
  const [gameStarted, setGameStarted] = useState(false)
  const [currentPrize, setCurrentPrize] = useState<number>(0)
  const [winningBoxId, setWinningBoxId] = useState<number>(-1)

  const fetchUserData = useCallback(async () => {
    try {
      if (typeof window === "undefined" || !window.Telegram?.WebApp?.initData) {
        return
      }

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_or_create_user",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setTicketsBalance(data.user.tickets_balance || 0)
        setTpBalance(data.user.balance || 0)
      }
    } catch (error) {
      console.error("Error fetching user data:", error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUserData()
    initializeBoxes()
  }, [fetchUserData])

  const initializeBoxes = () => {
    const newPrize = generateRandomPrize()
    setCurrentPrize(newPrize)
    
    const winningBox = Math.floor(Math.random() * 4)
    setWinningBoxId(winningBox)
    
    const newBoxes: Box[] = []
    
    for (let i = 0; i < 4; i++) {
      if (i === winningBox) {
        newBoxes.push({
          id: i,
          isRevealed: false,
          content: "prize",
          prizeAmount: newPrize,
        })
      } else {
        newBoxes.push({
          id: i,
          isRevealed: false,
          content: "empty",
        })
      }
    }

    setBoxes(newBoxes)
  }

  const handleStartGame = async () => {
    if (ticketsBalance < 1) {
      setShowTicketDialog(true)
      return
    }

    if (gameStarted) return

    setIsPlaying(true)

    try {
      const useTicketResponse = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "use_ticket",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (!useTicketResponse.ok) {
        throw new Error("Failed to use ticket")
      }

      setTicketsBalance((prev) => prev - 1)
      setGameStarted(true)
      setIsPlaying(false)

      toast({
        title: "Game Started!",
        description: "Choose one box to reveal your prize!",
      })
    } catch (error) {
      console.error("Start game error:", error)
      toast({
        title: "Game Error",
        description: "An error occurred while starting the game, please try again",
        variant: "destructive",
      })
      setIsPlaying(false)
    }
  }

  const handleBoxClick = async (boxId: number) => {
    if (!gameStarted || boxes[boxId].isRevealed) {
      return
    }

    const updatedBoxes = boxes.map((box) => 
      box.id === boxId ? { ...box, isRevealed: true } : box
    )
    setBoxes(updatedBoxes)

    const clickedBox = boxes.find((box) => box.id === boxId)
    const isWinner = clickedBox?.content === "prize"

    if (isWinner && clickedBox.prizeAmount) {
      try {
        const updateResponse = await fetch("/api/user", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            action: "update_balance",
            initData: window.Telegram.WebApp.initData,
            miningData: { newBalance: clickedBox.prizeAmount },
          }),
        })

        if (updateResponse.ok) {
          setTpBalance((prev) => prev + clickedBox.prizeAmount!)
          
          toast({
            title: "Congratulations!",
            description: `You won ${format(clickedBox.prizeAmount)} ${SIMPLE}!`,
          })
        }
      } catch (error) {
        console.error("Error awarding prize:", error)
        toast({
          title: "Error",
          description: "An error occurred while awarding the prize",
          variant: "destructive",
        })
      }
    }

    setTimeout(() => {
      const allRevealedBoxes = boxes.map((box) => ({ ...box, isRevealed: true }))
      setBoxes(allRevealedBoxes)

      setGameResult({
        id: "game-result",
        type: isWinner ? "tp" : "empty",
        amount: isWinner ? clickedBox.prizeAmount! : 0,
        timestamp: Date.now(),
      })

      setShowResultDialog(true)
    }, 100)
  }

  const resetGame = () => {
    setGameStarted(false)
    setSelectedBoxes([])
    setGameResult(null)
    setShowResultDialog(false)
    initializeBoxes() 
  }

  if (isLoading) {
    return <LoadingScreen />
  }

  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full flex flex-col pb-20 overflow-x-hidden">
        <div className="text-center pt-6 pb-4 px-4">
          <h1 className="text-2xl font-bold fire-text mb-1">Lucky Boxes</h1>
          <p className="text-[#a0a0a0] text-sm">Choose one box and discover your prize!</p>
        </div>

        <div className="flex justify-center items-center gap-4 mb-4 px-4">
          <div className="flex items-center gap-2">
            <FaTicketAlt className="w-4 h-4 text-tp" />
            <span className="text-sm font-medium">{formatBalance(ticketsBalance)}</span>
          </div>

          <div className="flex items-center gap-2">
            <Image src="/logo.svg" alt="tp" width={20} height={20} />
            <span className="text-sm font-medium">{formatBalance(tpBalance)}</span>
          </div>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-4">
          <div className="w-full max-w-xs mb-8">
            <div className="grid grid-cols-2 gap-4 mb-6">
              {boxes.map((box) => (
                <motion.div
                  key={box.id}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleBoxClick(box.id)}
                  className={`
                    aspect-square rounded-2xl flex items-center justify-center cursor-pointer transition-all duration-300
                    ${
                      !gameStarted
                        ? "dark-bg"
                        : box.isRevealed
                          ? box.content === "prize"
                            ? "bg-tp/20 tp-border"
                            : "bg-red-500/20 border-red-600/90 border"
                          : "dark-bg hover:bg-[#1a1a1a]"
                    }
                    ${box.isRevealed && box.content === "prize" ? "scale-105" : ""}
                  `}
                >
                  {box.isRevealed ? (
                    <div className="flex flex-col items-center justify-center">
                      {box.content === "prize" ? (
                        <>
                          <Image src="/logo.svg" alt="tp" width={32} height={32} />
                          <span className="text-xs font-medium mt-1">{format(box.prizeAmount || 0)}</span>
                        </>
                      ) : (
                        <FaTimes className="w-8 h-8 text-red-500" />
                      )}
                    </div>
                  ) : (
                 !gameStarted ? (
                   <FaGift className="w-8 h-8 text-[#a0a0a0]" />
                  ) : (
                   <MdQuestionMark className="w-8 h-8 text-[#a0a0a0]" />
                  )
                )}
                </motion.div>
              ))}
            </div>

            <div className="text-center mb-4">
              {!gameStarted ? (
                <p className="text-[#a0a0a0] text-xs">Start the game to choose your lucky box!</p>
              ) : boxes.some(box => box.isRevealed) ? (
                <p className="text-[#a0a0a0] text-xs">Game completed! Check your result.</p>
              ) : (
                <p className="text-[#a0a0a0] text-xs">Choose one box to reveal your prize!</p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <motion.div whileTap={{ scale: 0.98 }}>
                <Button
                  onClick={gameStarted ? resetGame : handleStartGame}
                  disabled={isPlaying || (gameStarted && !boxes.some(box => box.isRevealed))}
                  className={`w-full h-12 rounded-2xl font-medium text-sm ${
                    isPlaying ? "dark-bg text-[#a0a0a0]" : "fire-gradient"
                  }`}
                >
                  {isPlaying ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    </div>
                  ) : gameStarted ? (
                    "New Game"
                  ) : (
                    "Start (1 Ticket)"
                  )}
                </Button>
              </motion.div>

              <div>
                <Button
                  onClick={() => setShowTicketDialog(true)}
                  className="w-full h-12 dark-bg hover:bg-[#1a1a1a] rounded-2xl font-medium text-sm"
                >
                  <FaTicketAlt className="w-4 h-4 text-tp mr-1" />
                  Buy Tickets
                </Button>
              </div>
            </div>
          </div>

          <div className="w-full max-w-xs dark-bg rounded-2xl p-4">
            <h3 className="text-white font-medium text-sm mb-2">How to Play:</h3>
            <ul className="text-[#a0a0a0] text-xs space-y-1">
              <li>• Use 1 ticket to start the game</li>
              <li>• Choose one box from the 4 available</li>
              <li>• 1 box contains prize (5,000-100,000 {SIMPLE})</li>
              <li>• 3 boxes are empty</li>
              <li>• Prize is awarded immediately if you win</li>
              <li>• Each game has a different random prize</li>
            </ul>
          </div>
        </div>

        <Dialog open={showResultDialog} onOpenChange={setShowResultDialog}>
          <DialogContent className="w-[95%] mx-auto gradient-dark rounded-3xl">
            <DialogHeader className="text-center">
              <DialogTitle className="fire-text text-xl font-bold">
                {gameResult?.amount && gameResult.amount > 0 ? "Congratulations!" : "Better Luck Next Time!"}
              </DialogTitle>
              <DialogDescription className="text-[#a0a0a0] text-sm">
                {gameResult?.amount && gameResult.amount > 0
                  ? "You found the winning box!"
                  : "The winning box was another one!"}
              </DialogDescription>
            </DialogHeader>

            <DialogBody className="px-6 py-4">
              {gameResult && (
                <div className="text-center">
                  <div className="space-y-4">
                    <div className="w-20 h-20 mx-auto bg-tp rounded-full flex items-center justify-center">
                      {gameResult.amount > 0 ? (
                        <FaGift className="w-16 h-16 text-white" />
                      ) : (
                        <FaTimes className="w-16 h-16 text-white" />
                      )}
                    </div>
                    <div>
                      {gameResult.amount > 0 ? (
                        <>
                          <h3 className="text-2xl font-bold fire-text mb-2">You Won!</h3>
                          <p className="text-[#a0a0a0] text-sm">
                            You earned {format(gameResult.amount)} {SIMPLE}!
                          </p>
                        </>
                      ) : (
                        <>
                          <h3 className="text-2xl font-bold text-red-400 mb-2">No Prize This Time</h3>
                          <p className="text-[#a0a0a0] text-sm">
                            Try again for a chance to win up to 100,000 {SIMPLE}!
                          </p>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </DialogBody>

            <DialogFooter className="px-6 pb-6">
              <Button
                onClick={() => {
                  setShowResultDialog(false)
                  resetGame()
                }}
                className="w-full fire-gradient rounded-2xl h-12"
              >
                Play Again
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <TicketPurchaseDialog
          open={showTicketDialog}
          onOpenChange={setShowTicketDialog}
          onPurchaseSuccess={(newTickets) => {
            setTicketsBalance((prev) => prev + newTickets)
            setShowTicketDialog(false)
          }}
          userBalance={tpBalance}
        />
      </div>
    </AppLayout>
  )
}

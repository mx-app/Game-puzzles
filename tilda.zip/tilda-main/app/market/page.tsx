"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AppLayout } from "@/components/app-layout"
import { useToast } from "@/components/ui/use-toast"
import { LoadingScreen } from "@/components/loading-screen"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FaCoins, FaShoppingCart, FaStar, FaImage, FaTicketAlt } from "react-icons/fa"
import Image from "next/image"
import { motion } from "framer-motion"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "@/components/ui/dialog"
import { useTonAddress, useTonConnectUI } from "@tonconnect/ui-react"
import { walletService } from "@/lib/wallet-service"
import { WALLET_ADDRESS } from "@/lib/wallet-config"
import { createInvoiceLink, openTelegramInvoice } from "@/lib/payment-service"
import { formatNumber } from "@/lib/utils"
import { TicketPackages } from "@/components/ticket-packages"
import { TicketPurchaseDialog } from "@/components/market-tickets"
import { SIMPLE, NAME } from "@/lib/config"
import { TP_PACKAGES, NFT_ITEMS } from "@/lib/data"

type TpPackage = {
  id: string
  tpAmount: number
  tonPrice: number
  starsPrice: number
  discount?: number
  popular?: boolean
}

type NftItem = {
  id: string
  name: string
  image: string
  tonPrice: number
  starsPrice: number
  popular?: boolean
}

export default function MarketPage() {
  const { toast } = useToast()
  const [tonConnectUI] = useTonConnectUI()
  const userAddress = useTonAddress()
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [showPaymentDialog, setShowPaymentDialog] = useState(false)
  const [showTicketDialog, setShowTicketDialog] = useState(false)
  const [selectedItem, setSelectedItem] = useState<TpPackage | NftItem | null>(null)
  const [selectedTicketPackage, setSelectedTicketPackage] = useState<any>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingMethod, setProcessingMethod] = useState<'TON' | 'STARS' | null>(null)
  const [walletBalance, setWalletBalance] = useState<string>("0")
  const [activeTab, setActiveTab] = useState<'tps' | 'nfts' | 'tickets'>('tps')
  
  const tpPackages: TpPackage[] = TP_PACKAGES
  const nftItems: NftItem[] = NFT_ITEMS

  const fetchUserData = useCallback(async () => {
    try {
      if (typeof window === "undefined" || !window.Telegram?.WebApp?.initData) {
        return
      }

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_or_create_user",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setUser(data.user)
      }
    } catch (error) {
      console.error("Error fetching user data:", error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUserData()
  }, [fetchUserData])

  useEffect(() => {
    const fetchWalletBalance = async () => {
      if (!userAddress) {
        setWalletBalance("0")
        return
      }

      try {
        const balanceData = await walletService.checkTonWalletBalance(userAddress)
        
        if (balanceData.success) {
          setWalletBalance(balanceData.balance)
        } else {
          console.error("Failed to fetch wallet balance:", balanceData.error)
          setWalletBalance("0")
        }
      } catch (error) {
        console.error("Error fetching wallet balance:", error)
        setWalletBalance("0")
      }
    }

    fetchWalletBalance()
  }, [userAddress])

  const handleItemSelect = (item: TpPackage | NftItem) => {
    setSelectedItem(item)
    setShowPaymentDialog(true)
  }

  const handleTicketPackageSelect = (pkg: any) => {
    setSelectedTicketPackage(pkg)
    setShowTicketDialog(true)
  }

  const handleTicketPurchaseSuccess = (newTickets: number) => {
    setUser((prev: any) => ({
      ...prev,
      tickets: (prev.tickets || 0) + newTickets
    }))
  }

  const handlePayment = async (paymentMethod: 'TON' | 'STARS') => {
    if (!selectedItem) return
    
    setIsProcessing(true)
    setProcessingMethod(paymentMethod)
    
    try {
      if (paymentMethod === 'TON') {
        if (!userAddress) {
          setShowPaymentDialog(false)
          await tonConnectUI.openModal()
          return
        }

        const requiredAmount = selectedItem.tonPrice
        const balanceCheck = await walletService.hasEnoughBalance(
          userAddress,
          requiredAmount
        )

        if (!balanceCheck.sufficient) {
          throw new Error(
            `Insufficient balance. You need ${requiredAmount} TON but have ${balanceCheck.currentBalance.toFixed(2)} TON`
          )
        }

        const tonAmount = BigInt(Math.floor(requiredAmount * 1000000000))

        const result = await tonConnectUI.sendTransaction({
          validUntil: Math.floor(Date.now() / 1000) + 600,
          messages: [
            {
              address: WALLET_ADDRESS,
              amount: tonAmount.toString(),
            },
          ],
        })

        if (!result?.boc) {
          throw new Error("Transaction failed")
        }
      } else if (paymentMethod === 'STARS') {
        if (!userAddress) {
          setShowPaymentDialog(false)
          await tonConnectUI.openModal()
          return
        }

        const starsCost = selectedItem.starsPrice
        
        const invoiceLink = await createInvoiceLink(
          starsCost,
          selectedItem.id.startsWith('package_') 
            ? `${SIMPLE} Package: ${(selectedItem as TpPackage).tpAmount.toLocaleString()}`
            : `NFT: ${selectedItem.name}`,
          selectedItem.id.startsWith('package_')
            ? `Purchase of ${(selectedItem as TpPackage).tpAmount.toLocaleString()} ${SIMPLE} package using Stars`
            : `Purchase of ${selectedItem.name} NFT using Stars`
        )

        const status = await openTelegramInvoice(invoiceLink)
        if (status !== "paid") {
          throw new Error("Payment not completed")
        }
      }

      const notificationResponse = await fetch("/api/nft-purchase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user?.telegram_id,
          username: user?.telegram_username,
          walletAddress: userAddress,
          productId: selectedItem.id,
          productType: selectedItem.id.startsWith('package_') ? "tp" : "nft",
          paymentMethod: paymentMethod.toLowerCase(),
          amount: paymentMethod === 'TON' ? selectedItem.tonPrice : selectedItem.starsPrice
        }),
      })

      if (!notificationResponse.ok) {
        throw new Error("Failed to send purchase notification")
      }

      if (selectedItem.id.startsWith('package_')) {
        const tpPackage = selectedItem as TpPackage
        const updateResponse = await fetch("/api/user", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "update_balance",
            initData: window.Telegram.WebApp.initData,
            miningData: { newBalance: tpPackage.tpAmount },
          }),
        })

        if (!updateResponse.ok) {
          throw new Error("Failed to update balance")
        }

        const data = await updateResponse.json()
        setUser((prev: any) => ({
          ...prev,
          balance: prev.balance + tpPackage.tpAmount
        }))
      }
      
      setShowPaymentDialog(false)
      toast({
        title: "Purchase successful!",
        description: selectedItem.id.startsWith('package_')
          ? `You've received ${(selectedItem as TpPackage).tpAmount.toLocaleString()} ${SIMPLE}`
          : `You've purchased ${selectedItem.name} NFT. It will be delivered to your wallet soon.`,
      })
    } catch (error) {
      console.error("Payment error:", error)
      toast({
        title: "Payment failed",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
      setProcessingMethod(null)
    }
  }
  
  const renderTpPackageCard = (tpPackage: TpPackage) => (
    <motion.div
      key={tpPackage.id}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="cursor-pointer mb-4"
      onClick={() => handleItemSelect(tpPackage)}
    >
      <Card className={`dark-bg rounded-2xl overflow-hidden ${tpPackage.popular ? 'bg-overlay' : ''}`}>
        <CardContent className="p-0">
          {tpPackage.popular && (
            <div className="bg-green-500 text-white text-xs font-bold py-1 px-3 text-center">
              MOST POPULAR
            </div>
          )}
          <div className="p-4">
            <div className="flex justify-between items-start mb-3">
              <div className="flex items-center gap-2">
                <Image src="/logo.svg" alt="TP" width={24} height={24} className="text-tp" />
                <h3 className="fire-text font-bold text-lg">
                  {formatNumber(tpPackage.tpAmount)} {SIMPLE}
                </h3>
              </div>
              {tpPackage.discount && (
                <Badge className="bg-green-500/10 text-green-400 border-green-500/20">
                  {tpPackage.discount}% OFF
                </Badge>
              )}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-[#a0a0a0]">TON Price</span>
                <div className="flex items-center">
                  <span className="font-medium">{tpPackage.tonPrice}</span>
                  <Image 
                    src="/toncoin.svg" 
                    alt="TON" 
                    width={16} 
                    height={16} 
                    className="ml-1 text-tp"
                  />
                </div>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-[#a0a0a0]">Stars Price</span>
                <div className="flex items-center">
                  <span className="font-medium">{formatNumber(tpPackage.starsPrice)}</span>
                  <Image 
                    src="/stars.svg" 
                    alt="Stars" 
                    width={16} 
                    height={16} 
                    className="ml-1 text-tp"
                  />
                </div>
              </div>
            </div>

            <Button className="w-full mt-4 fire-gradient rounded-xl">
              <FaShoppingCart className="w-4 h-4 mr-2 text-white" />
              Buy Now
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )

  const renderNftCard = (nft: NftItem) => (
    <motion.div
      key={nft.id}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="cursor-pointer"
      onClick={() => handleItemSelect(nft)}
    >
      <Card className="dark-bg rounded-2xl overflow-hidden">
        <CardContent className="p-0 flex flex-col h-full">
          {nft.popular && (
            <div className="bg-green-500 text-white text-xs font-bold py-1 px-3 text-center">
              POPULAR
            </div>
          )}
          
          <div className="relative w-full aspect-square">
            <Image 
              src={nft.image} 
              alt={nft.name} 
              fill
              className="object-cover"
              style={{ borderTopLeftRadius: '0.75rem', borderTopRightRadius: '0.75rem' }}
            />
          </div>
          
          <div className="p-4 border-t border-[#1A1A1A] flex flex-col flex-grow">
            <h3 className="fire-text font-bold text-lg mb-1 text-center">
              {nft.name}
            </h3>
            
            <div className="flex flex-row justify-between items-center mt-3 space-x-2">
              <div className="flex items-center flex-1 justify-center">
                <span className="font-medium">{nft.tonPrice}</span>
                <Image 
                  src="/toncoin.svg" 
                  alt="TON" 
                  width={16} 
                  height={16} 
                  className="ml-1 text-tp"
                />
              </div>
              
              <div className="flex items-center flex-1 justify-center">
                <span className="font-medium">{nft.starsPrice}</span>
                <Image 
                  src="/stars.svg" 
                  alt="Stars" 
                  width={16} 
                  height={16} 
                  className="ml-1 text-tp"
                />
              </div>
            </div>
            
            <Button className="w-full mt-4 fire-gradient rounded-xl">
              <FaShoppingCart className="w-4 h-4 mr-2 text-white" />
              Buy Now
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )

  if (isLoading) {
    return <LoadingScreen />
  }

  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full">
        <div className="pb-20 pt-4 w-[90%] mx-auto max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold fire-text mb-1">Market</h1>
            <div className="flex justify-center items-center space-x-2">
              <FaShoppingCart className="w-4 h-4 text-tp" />
              <span className="text-[#a0a0a0] text-sm">
                Purchase {SIMPLE}s packages, Tickets, and NFTs
              </span>
            </div>
          </div>

          <Tabs defaultValue="tps" className="w-full mb-4">
            <TabsList className="grid w-full grid-cols-3 dark-bg h-12 rounded-2xl p-1">
              <TabsTrigger
                value="tps"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
                onClick={() => setActiveTab('tps')}
              >
                <FaCoins className="w-4 h-4 mr-2 text-tp" />
                <span>{SIMPLE}s</span>
              </TabsTrigger>
              <TabsTrigger
                value="tickets"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
                onClick={() => setActiveTab('tickets')}
              >
                <FaTicketAlt className="w-4 h-4 mr-2 text-tp" />
                <span>Tickets</span>
              </TabsTrigger>
              <TabsTrigger
                value="nfts"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
                onClick={() => setActiveTab('nfts')}
              >
                <FaImage className="w-4 h-4 mr-2 text-tp" />
                <span>NFTs</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="tps" className="mt-4">
              <div className="dark-bg rounded-xl p-4 mb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Image src="/logo.svg" alt="TP" width={24} height={24} className="text-tp" />
                    <span className="text-sm text-[#a0a0a0]">Your Balance</span>
                  </div>
                  <div className="text-lg font-bold">
                    {formatNumber(user?.balance || 0)} {SIMPLE}
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                {tpPackages.map(renderTpPackageCard)}
              </div>
            </TabsContent>

            <TabsContent value="nfts" className="mt-4">
              <div className="grid grid-cols-2 gap-4">
                {nftItems.map(renderNftCard)}
              </div>
            </TabsContent>

            <TabsContent value="tickets" className="mt-4">
              <TicketPackages 
                onPackageSelect={handleTicketPackageSelect}
                userTickets={user?.tickets_balance || 0}
              />
            </TabsContent>
          </Tabs>
        </div>

        <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
          <DialogContent className="w-[95%] max-w-md mx-auto gradient-dark rounded-3xl">
            <DialogHeader className="text-center">
              <DialogTitle className="fire-text text-xl font-bold">
                {selectedItem?.id.startsWith('package_')
                  ? `Purchase ${(selectedItem as TpPackage)?.tpAmount.toLocaleString()} ${SIMPLE}`
                  : `Purchase ${selectedItem?.name} NFT`}
              </DialogTitle>
              <DialogDescription className="text-[#a0a0a0] text-sm">
                Choose your preferred payment method
              </DialogDescription>
            </DialogHeader>

            <DialogBody className="space-y-4 px-6 py-4">
              <div className="dark-bg rounded-xl p-4 text-center">
                {selectedItem?.id.startsWith('package_') ? (
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Image src="/logo.svg" alt="TP" width={24} height={24} className="text-tp" />
                    <span className="text-xl font-bold fire-text">
                      {(selectedItem as TpPackage)?.tpAmount.toLocaleString()} {SIMPLE}
                    </span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center">
                    <div className="relative w-20 h-20 mb-2 rounded-xl overflow-hidden dark-bg">
                      <Image 
                        src={selectedItem?.image || ''} 
                        alt={selectedItem?.name || ''} 
                        fill
                        className="object-contain"
                      />
                    </div>
                    <span className="text-xl font-bold fire-text">
                      {selectedItem?.name}
                    </span>
                  </div>
                )}
              </div>

              {selectedItem?.tonPrice && (
                <motion.div whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => handlePayment("TON")}
                    disabled={isProcessing || (userAddress && Number(walletBalance) < (selectedItem?.tonPrice || 0))}
                    className="w-full fire-gradient text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                  >
                    {processingMethod === "TON" ? (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : (
                      <>
                        <Image src="/toncoin.svg" alt="TON" width={20} height={20} className="text-tp" />
                        <span>
                          {!userAddress
                            ? "Connect Wallet"
                            : Number(walletBalance) < (selectedItem?.tonPrice || 0)
                              ? `Need ${((selectedItem?.tonPrice || 0) - Number(walletBalance)).toFixed(2)} TON more`
                              : `Pay ${selectedItem?.tonPrice} TON`}
                        </span>
                      </>
                    )}
                  </Button>
                </motion.div>
              )}

              {selectedItem?.starsPrice && !selectedItem.id.startsWith('nft_') && (
                <motion.div whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => handlePayment("STARS")}
                    disabled={isProcessing || !userAddress}
                    className="w-full fire-gradient text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                  >
                    {processingMethod === "STARS" ? (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : (
                      <>
                        <Image src="/stars.svg" alt="Stars" width={20} height={20} className="text-tp" />
                        <span>
                          {!userAddress
                            ? "Connect Wallet"
                            : `Pay ${selectedItem?.starsPrice.toLocaleString()} Stars`}
                        </span>
                      </>
                    )}
                  </Button>
                </motion.div>
              )}
            </DialogBody>

            <DialogFooter className="px-6 pb-6">
              <motion.div whileTap={{ scale: 0.98 }} className="w-full">
                <Button
                  onClick={() => setShowPaymentDialog(false)}
                  variant="outline"
                  className="w-full border-[#1A1A1A] text-[#a0a0a0] hover:bg-[#1a1a1a] rounded-xl h-10"
                >
                  Cancel
                </Button>
              </motion.div>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <TicketPurchaseDialog
          open={showTicketDialog}
          onOpenChange={setShowTicketDialog}
          onPurchaseSuccess={handleTicketPurchaseSuccess}
          selectedPackage={selectedTicketPackage}
        />
      </div>
    </AppLayout>
  )
}

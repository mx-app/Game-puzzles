"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AppLayout } from "@/components/app-layout"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FaCrown, FaStar, FaGift, FaCoins, FaHeadset, FaRocket, FaCheck, FaTrophy } from "react-icons/fa"
import Image from "next/image"
import { Skeleton } from "@/components/ui/skeleton"
import { motion } from "framer-motion"
import { createInvoiceLink, openTelegramInvoice } from "@/lib/payment-service"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "@/components/ui/dialog"
import { useTonAddress, useTonConnectUI } from "@tonconnect/ui-react"
import { walletService } from "@/lib/wallet-service"
import { WALLET_ADDRESS } from "@/lib/wallet-config"
import { SIMPLE, NAME } from "@/lib/config"

export default function PremiumPage() {
  const { toast } = useToast()
  const [tonConnectUI] = useTonConnectUI()
  const userAddress = useTonAddress()
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [showPaymentDialog, setShowPaymentDialog] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingMethod, setProcessingMethod] = useState<"wallet" | "stars" | null>(null)
  const [walletBalance, setWalletBalance] = useState<string>("0")

  const fetchUserData = useCallback(async () => {
    try {
      if (typeof window === "undefined" || !window.Telegram?.WebApp?.initData) {
        return
      }

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_or_create_user",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setUser(data.user)
      }
    } catch (error) {
      console.error("Error fetching user data:", error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUserData()
  }, [fetchUserData])

  useEffect(() => {
    const fetchWalletBalance = async () => {
      if (!userAddress) {
        setWalletBalance("0")
        return
      }

      try {
        const balanceData = await walletService.checkTonWalletBalance(userAddress)
        
        if (balanceData.success) {
          setWalletBalance(balanceData.balance)
        } else {
          console.error("Failed to fetch wallet balance:", balanceData.error)
          setWalletBalance("0")
        }
      } catch (error) {
        console.error("Error fetching wallet balance:", error)
        setWalletBalance("0")
      }
    }

    fetchWalletBalance()
  }, [userAddress])

  const handleSubscribe = async (paymentMethod: "wallet" | "stars") => {
    setIsProcessing(true)
    setProcessingMethod(paymentMethod)
    try {
      if (paymentMethod === "wallet") {
        if (!userAddress) {
          setShowPaymentDialog(false)
          await tonConnectUI.openModal()
          return
        }

        const balanceCheck = await walletService.hasEnoughBalance(
          userAddress,
          1
        )

        if (!balanceCheck.sufficient) {
          throw new Error(
            `Insufficient balance in your wallet. You need 1 TON but you have ${balanceCheck.currentBalance.toFixed(2)} TON`
          )
        }

        const tonAmount = BigInt(Math.floor(1 * 1000000000))

        const result = await tonConnectUI.sendTransaction({
          validUntil: Math.floor(Date.now() / 1000) + 600,
          messages: [
            {
              address: WALLET_ADDRESS,
              amount: tonAmount.toString(),
            },
          ],
        })

        if (!result?.boc) {
          throw new Error("Transaction failed")
        }
      } else if (paymentMethod === "stars") {
        const invoiceLink = await createInvoiceLink(
          400,
          `${NAME} Premium Subscription`,
          `Activate premium subscription for ${SIMPLE} tokens`,
        )

        const status = await openTelegramInvoice(invoiceLink)
        if (status !== "paid") {
          throw new Error("Payment not completed")
        }
      }

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "update_premium_status",
          initData: window.Telegram.WebApp.initData,
          premiumStatus: true,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to update premium status")
      }

      const data = await response.json()
      setUser(data.user)
      setShowPaymentDialog(false)
      toast({
        title: "Subscription activated",
        description: "Your premium subscription is now active!",
      })
    } catch (error) {
      console.error("Premium subscription error:", error)
      toast({
        title: "Subscription failed",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
      setProcessingMethod(null)
    }
  }

  if (isLoading) {
  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full">
        <div className="pb-20 pt-4 w-[90%] mx-auto max-w-md">
         <div className="text-center mb-6">
            <h1 className="text-2xl font-bold fire-text mb-1">{NAME} Premium</h1>
            <div className="flex justify-center items-center space-x-2 text-left">
              <FaCrown className="w-4 h-4 text-tp" />
              <span className="text-[#a0a0a0] text-sm">Loading premium status...</span>
            </div>
          </div>

          <Tabs defaultValue="features" className="w-full">
            <TabsList className="grid w-full grid-cols-2 dark-bg h-12 rounded-2xl p-1 mb-4">
              <TabsTrigger
                value="features"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
              >
                <div className="flex items-center justify-center space-x-2 z-10 relative">
                  <FaRocket className="w-4 h-4 text-tp" />
                  <span>Features</span>
                </div>
                <div className="absolute inset-0 data-[state=active]:bg-[#2a2a2a] data-[state=active]:rounded-xl z-0" />
              </TabsTrigger>
              <TabsTrigger
                value="pricing"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
              >
                <div className="flex items-center justify-center space-x-2 z-10 relative">
                  <FaCoins className="w-4 h-4 text-tp" />
                  <span>Pricing</span>
                </div>
                <div className="absolute inset-0 data-[state=active]:bg-[#2a2a2a] data-[state=active]:rounded-xl z-0" />
              </TabsTrigger>
            </TabsList>

            <TabsContent value="features" className="space-y-5">
              <Card className="dark-bg rounded-2xl">
                <CardContent className="p-6">
                  <Skeleton className="h-5 w-40 bg-[#1A1A1A] mb-6" />
                  <div className="space-y-4">
                    {[...Array(5)].map((_, index) => (
                      <div key={index} className="relative flex items-start space-x-3 bg-[#1a1a1a] p-3 rounded-xl">
                        <Skeleton className="w-9 h-9 bg-[#1A1A1A] rounded-lg" />
                        <div className="flex-1 space-y-2">
                          <Skeleton className="h-4 w-32 bg-[#1A1A1A]" />
                          <Skeleton className="h-3 w-48 bg-[#1A1A1A]" />
                        </div>
                        <Skeleton className="w-5 h-5 bg-[#1A1A1A] rounded-full" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="pricing" className="space-y-5">
              <Card className="dark-bg rounded-2xl">
                <CardContent className="p-6">
                  <Skeleton className="h-5 w-32 bg-[#1A1A1A] mb-6" />
                  <div className="bg-[#1a1a1a] rounded-xl p-4 mb-4 border tp-border">
                    <div className="flex items-center justify-between mb-3">
                      <Skeleton className="h-5 w-40 bg-[#1A1A1A]" />
                    </div>
                    <div className="flex items-end justify-between">
                      <Skeleton className="h-8 w-24 bg-[#1A1A1A]" />
                      <Skeleton className="h-4 w-32 bg-[#1A1A1A]" />
                    </div>
                  </div>
                  <div className="space-y-3">
                    {[...Array(3)].map((_, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <Skeleton className="h-4 w-24 bg-[#1A1A1A]" />
                        <Skeleton className="h-4 w-20 bg-[#1A1A1A]" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AppLayout>
   )
  }

  const isPremium = user?.premium || false
  const userPhoto = window.Telegram?.WebApp?.initDataUnsafe?.user?.photo_url || ""
  const userName = window.Telegram?.WebApp?.initDataUnsafe?.user?.first_name || "User"

  const premiumFeatures = [
    {
      icon: <FaStar className="w-5 h-5 text-tp" />,
      title: "Double Rewards",
      description: `Earn 2x ${SIMPLE} in every balance update`
    },
    {
      icon: <FaTrophy className="w-5 h-5 text-tp" />,
      title: "Premium Badge",
      description: `Crown badge in the leaderboard`
    }, 
    {
      icon: <FaGift className="w-5 h-5 text-tp" />,
      title: "Double Referral Rewards",
      description: `Get 10,000 ${SIMPLE} per referral`
    },
    {
      icon: <FaCoins className="w-5 h-5 text-tp" />,
      title: "No Withdrawal Fees",
      description: `Withdraw your ${SIMPLE} without fees`
    },
    {
      icon: <FaHeadset className="w-5 h-5 text-tp" />,
      title: "Priority Support",
      description: `Faster responses from our team`
    }
  ];

  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full">
        <div className="pb-20 pt-4 w-[90%] mx-auto max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold fire-text mb-1">{NAME} Premium</h1>
            <div className="flex justify-center items-center space-x-2 text-left">
              <FaCrown className="w-4 h-4 text-tp" />
              {isPremium ? (
                <span className="text-[#a0a0a0] text-sm">You're a Premium member</span>
              ) : (
                <span className="text-[#a0a0a0] text-sm">Unlock exclusive benefits</span>
              )}
            </div>
          </div>

          <Tabs defaultValue="features" className="w-full">
            <TabsList className="grid w-full grid-cols-2 dark-bg h-12 rounded-2xl p-1 mb-4">
              <TabsTrigger
                value="features"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
              >
                <div className="flex items-center justify-center space-x-2 z-10 relative">
                  <FaRocket className="w-4 h-4 text-tp" />
                  <span>Features</span>
                </div>
                <div className="absolute inset-0 data-[state=active]:bg-[#2a2a2a] data-[state=active]:rounded-xl z-0" />
              </TabsTrigger>
              <TabsTrigger
                value="pricing"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
              >
                <div className="flex items-center justify-center space-x-2 z-10 relative">
                  <FaCoins className="w-4 h-4 text-tp" />
                  <span>Pricing</span>
                </div>
                <div className="absolute inset-0 data-[state=active]:bg-[#2a2a2a] data-[state=active]:rounded-xl z-0" />
              </TabsTrigger>
            </TabsList>

            <TabsContent value="features" className="space-y-5">
              <Card className="dark-bg rounded-2xl">
                <CardContent className="p-6">
                  {isPremium ? (
                    <div className="text-center mb-6">
                      <h3 className="fire-text text-lg font-semibold mb-2">Premium Activated</h3>
                      <p className="text-[#a0a0a0] text-sm">
                        You're enjoying all the exclusive benefits of {NAME} Premium
                      </p>
                    </div>
                  ) : (
                    <h4 className="fire-text font-semibold mb-5 flex items-center gap-2">
                      <FaCrown className="text-tp" /> Premium Features
                    </h4>
                  )}
                  
                  <div className="space-y-4">
                    {premiumFeatures.map((feature, index) => (
                      <div key={index} className="relative flex items-start space-x-3 bg-[#1a1a1a] p-3 rounded-xl">
                        <div className="bg-[#2a2a2a] p-2 rounded-lg">
                          {feature.icon}
                        </div>
                        <div className="text-left">
                          <div className="text-white text-sm font-medium">{feature.title}</div>
                          <div className="text-[#a0a0a0] text-xs mt-1">{feature.description}</div>
                        </div>
                        {isPremium && (
                          <div className="absolute right-3 top-3 bg-green-500/10 p-1 rounded-full">
                            <FaCheck className="w-3 h-3 text-green-400" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                 {!isPremium && (
                  <Button
                   onClick={() => setShowPaymentDialog(true)}
                   className="w-full h-12 rounded-2xl fire-gradient text-white font-bold mt-4"
                  >
                  <FaCrown className="w-5 h-5 mr-2 text-white" />
                   Upgrade To Premium
                  </Button>
                 )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="pricing" className="space-y-5">
              <Card className="dark-bg rounded-2xl">
                <CardContent className="p-6">
                  <h4 className="fire-text font-semibold mb-5">Pricing Plans</h4>
                  
                  <div className="bg-[#1a1a1a] rounded-xl p-4 mb-4 border tp-border">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <FaCrown className="w-5 h-5 text-tp" />
                        <span className="font-medium">One-Time Purchase</span>
                      </div>
                    </div>
                    
                    <div className="flex items-end justify-between">
                      <div>
                        <div className="text-2xl font-bold fire-text">1 TON</div>
                        <div className="text-[#a0a0a0] text-xs">or 400 Stars</div>
                      </div>
                      <div className="text-[#a0a0a0] text-xs text-right">
                        Unlimited access
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-[#a0a0a0]">Payment Method:</span>
                      <span className="font-medium">TON or Stars</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-[#a0a0a0]">Duration:</span>
                      <span className="font-medium">Lifetime</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-[#a0a0a0]">Activation:</span>
                      <span className="font-medium">Instant</span>
                    </div>
                  </div>
                 {!isPremium && (
                  <Button
                   onClick={() => setShowPaymentDialog(true)}
                   className="w-full h-12 rounded-2xl fire-gradient text-white font-bold mt-4"
                 >
                  <FaCrown className="w-5 h-5 mr-2 text-white" />
                  Subscribe Now
                  </Button>
                )}
               </CardContent>
              </Card> 
            </TabsContent>
          </Tabs>
        </div>

        <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
          <DialogContent className="w-[95%] max-w-md mx-auto gradient-dark rounded-3xl">
            <DialogHeader className="text-center">
              <DialogTitle className="fire-text text-xl font-bold">{NAME} Premium</DialogTitle>
              <DialogDescription className="text-[#a0a0a0] text-sm">
                Choose your payment method to activate premium features
              </DialogDescription>
            </DialogHeader>

            <DialogBody className="space-y-4 px-6 py-4">
              <div className="dark-bg rounded-xl p-4 text-center">
                <div className="text-[#a0a0a0] text-sm mb-1">Subscription Cost</div>
                <div className="fire-text font-semibold text-lg flex items-center justify-center gap-1">
                  1 <Image src="/toncoin.svg" alt="TON" width={16} height={16} className="text-tp" />
                  <span className="mx-2">or</span> 
                  400 <Image src="/stars.svg" alt="Stars" width={16} height={16} className="text-tp" />
                </div>
                <div className="text-[#a0a0a0] text-xs mt-2">
                  One-time payment for lifetime access
                </div>
                {userAddress && (
                  <div className="text-sm text-[#a0a0a0] mt-2 text-center">
                    Wallet Balance: <span className="text-white">{Number(walletBalance).toFixed(2)} TON</span>
                  </div>
                )}
              </div>

              <motion.div whileTap={{ scale: 0.98 }}>
                <Button
                  onClick={() => handleSubscribe("wallet")}
                  disabled={isProcessing || (userAddress && Number(walletBalance) < 1)}
                  className="w-full fire-gradient text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                >
                  {processingMethod === "wallet" ? (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    </div>
                  ) : (
                    <>
                      <Image src="/toncoin.svg" alt="TON" width={20} height={20} className="text-tp" />
                      <span>
                        {!userAddress
                          ? "Connect Wallet"
                          : Number(walletBalance) < 1
                            ? `Need ${(1 - Number(walletBalance)).toFixed(2)} TON more`
                            : `Pay 1 TON`}
                      </span>
                    </>
                  )}
                </Button>
              </motion.div>

              <motion.div whileTap={{ scale: 0.98 }}>
                <Button
                  onClick={() => handleSubscribe("stars")}
                  disabled={isProcessing}
                  className="w-full fire-gradient text-white font-semibold rounded-xl h-12 flex items-center justify-center gap-2 relative"
                >
                  {processingMethod === "stars" ? (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    </div>
                  ) : (
                    <>
                      <Image src="/stars.svg" alt="Stars" width={20} height={20} className="text-tp" />
                      <span>Pay 400 Stars</span>
                    </>
                  )}
                </Button>
              </motion.div>
            </DialogBody>

            <DialogFooter className="px-6 pb-6">
              <motion.div whileTap={{ scale: 0.98 }} className="w-full">
                <Button
                  onClick={() => setShowPaymentDialog(false)}
                  variant="outline"
                  className="w-full border-[#1A1A1A] text-[#a0a0a0] hover:bg-[#1a1a1a] rounded-xl h-10"
                >
                  Cancel
                </Button>
              </motion.div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  )
}

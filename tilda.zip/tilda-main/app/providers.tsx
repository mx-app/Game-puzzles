"use client"

import type { ReactNode } from "react"
import { TonConnectUIProvider, THEME } from "@tonconnect/ui-react"
import { MINI_APP, MANIFEST_URL_TON } from "@/lib/config"

export function Providers({ children }: { children: ReactNode }) {
  return (
    <TonConnectUIProvider
      manifestUrl={MANIFEST_URL_TON}
      actionsConfiguration={{
        twaReturnUrl: MINI_APP,
      }}
      uiPreferences={{ theme: THEME.DARK }}
    >
      {children}
    </TonConnectUIProvider>
  )
}

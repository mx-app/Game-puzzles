"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogBody, DialogFooter } from "@/components/ui/dialog"
import { AppLayout } from "@/components/app-layout"
import { useToast } from "@/components/ui/use-toast"
import { createInvoiceLink, openTelegramInvoice } from "@/lib/payment-service"
import { FaCalendarDay, FaClock, FaBolt, FaTrophy, FaCrown, FaInfoCircle } from "react-icons/fa"
import { LuPickaxe, LuLoaderCircle } from "react-icons/lu"
import { BottomNavigation } from "@/components/bottom-navigation"
import Image from "next/image"
import { motion } from "framer-motion"
import { DailyRewardDialog } from "@/components/daily-reward-dialog"
import { UpgradeDialog } from "@/components/upgrade-dialog"
import { useTonAddress, useTonConnectUI } from "@tonconnect/ui-react"
import { WALLET_ADDRESS } from "@/lib/wallet-config"
import { walletService } from "@/lib/wallet-service"
import { WalletDialog } from "@/components/wallet-dialog"
import { Skeleton } from "@/components/ui/skeleton"
import { MiningSubscriptionDialog } from "@/components/mining-subscription-dialog"
import { MiningStatusCard } from "@/components/mining-status-card"
import { UserProfileSection } from "@/components/user-profile-section"
import { LeaderboardSection } from "@/components/leaderboard-section"
import { HeaderActions } from "@/components/header-actions"
import { UpgradeSelectionDialog } from "@/components/upgrade-selection-dialog"
import { SubscriptionDialog } from "@/components/subscription-mining-dialog"
import { TicketPurchaseDialog } from "@/components/ticket-purchase-dialog"
import { UserInfoDialog } from "@/components/user-info-dialog"
import { SIMPLE, NAME, CHANNEL_URL } from "@/lib/config"

const formatDate = (dateString?: string | null) => {
    if (!dateString) return "Never claimed"
    const date = new Date(dateString)
    return date.toLocaleDateString('en-GB') 
}

export default function MiningPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [tonConnectUI] = useTonConnectUI()
  const userAddress = useTonAddress()

  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false)
  const [showUpgradePaymentDialog, setShowUpgradePaymentDialog] = useState(false)
  const [showWalletDialog, setShowWalletDialog] = useState(false)
  const [showDailyRewardDialog, setShowDailyRewardDialog] = useState(false)
  const [showPlanDialog, setShowPlanDialog] = useState(false)
  const [showSubscriptionInfoDialog, setShowSubscriptionInfoDialog] = useState(false)
  const [selectedUpgrade, setSelectedUpgrade] = useState<"rate" | "time" | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [timeRemaining, setTimeRemaining] = useState(0)
  const [canClaim, setCanClaim] = useState(false)
  const [minedCoins, setMinedCoins] = useState(0)
  const [walletBalance, setWalletBalance] = useState("0")
  const [showTicketDialog, setShowTicketDialog] = useState(false)
  const [showUserInfoDialog, setShowUserInfoDialog] = useState(false)

  const fetchUserData = useCallback(async () => {
    try {
      if (typeof window === "undefined" || !window.Telegram?.WebApp?.initData) {
        return
      }

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_or_create_user",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setUser(data.user)
      }
    } catch (error) {
      console.error("Error fetching user data:", error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUserData()
  }, [fetchUserData])

  useEffect(() => {
    const fetchWalletBalance = async () => {
      if (!userAddress) {
        setWalletBalance("0")
        return
      }

      try {
        const balanceData = await walletService.checkTonWalletBalance(userAddress)
        if (balanceData.success) {
          setWalletBalance(balanceData.balance)
        } else {
          console.error("Failed to fetch wallet balance:", balanceData.error)
          setWalletBalance("0")
        }
      } catch (error) {
        console.error("Error fetching wallet balance:", error)
        setWalletBalance("0")
      }
    }

    fetchWalletBalance()
  }, [userAddress])

   useEffect(() => {
    if (!user?.mining_subscription?.isActive) return

    const subscription = user.mining_subscription
    const upgrades = user.mining_upgrades || {}
    const isPremium = subscription.plan === 'premium'
    
    const baseMiningDuration = isPremium ? 8 : 12 
    const miningDurationHours = baseMiningDuration - (upgrades.timeReduction || 0)
    const miningDurationMs = Math.max(1, miningDurationHours) * 60 * 60 * 1000 
    
    const lastClaimTime = subscription.lastClaimTime || subscription.startTime
    const endTime = lastClaimTime + miningDurationMs

    let animationFrameId: number
    let lastTimestamp: number

    const updateMining = (timestamp: number) => {
      if (!lastTimestamp) lastTimestamp = timestamp
      const deltaTime = timestamp - lastTimestamp
      lastTimestamp = timestamp

      const now = Date.now()
      const remaining = Math.max(0, endTime - now)
      const elapsed = now - lastClaimTime
      const progress = Math.min(1, elapsed / miningDurationMs)
      
      setTimeRemaining(remaining)
      setCanClaim(remaining === 0)
      
      const baseRate = isPremium ? 20000 : 5000
      const rateMultiplier = 1 + (upgrades.rateBoost || 0) * 1
      const currentRate = Math.floor(baseRate * rateMultiplier)
      const coins = currentRate * progress
      
      setMinedCoins(coins)

      animationFrameId = requestAnimationFrame(updateMining)
    }

    animationFrameId = requestAnimationFrame(updateMining)

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId)
      }
    }
  }, [user])

  const formatTime = (milliseconds: number) => {
    const totalSeconds = Math.floor(milliseconds / 1000)
    const hours = Math.floor(totalSeconds / 3600)
    const minutes = Math.floor((totalSeconds % 3600) / 60)
    const seconds = totalSeconds % 60
    return `${hours}h ${minutes}m ${seconds}s`
  }

  const formatBalance = (balance: number) => {
    return balance.toLocaleString('en-US')
  }

  const formatMiningCoins = (coins: number) => {
    return coins.toFixed(1)
  }

  const activateSubscription = async (plan: 'free' | 'premium') => {
    try {
      const subscriptionData = {
        isActive: true,
        plan: plan,
        startTime: Date.now(),
        lastClaimTime: Date.now(),
      }

      await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "update_mining_subscription",
          initData: window.Telegram.WebApp.initData,
          miningData: subscriptionData,
        }),
      })
      await fetchUserData()
    } catch (error) {
      console.error("Error activating subscription:", error)
      throw error
    }
  }

  const handleUpgradeSelect = (type: "rate" | "time") => {
    setSelectedUpgrade(type)
    setShowUpgradeDialog(false)
    setShowUpgradePaymentDialog(true)
  }

  const processUpgrade = async () => {
    if (!selectedUpgrade) return

    const upgrades = user?.mining_upgrades || {}
    const newUpgrades = { ...upgrades }
    
    if (selectedUpgrade === "rate") {
      newUpgrades.rateBoost = (newUpgrades.rateBoost || 0) + 1
    } else {
      newUpgrades.timeReduction = (newUpgrades.timeReduction || 0) + 1
    }

    try {
      await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "update_mining_upgrades",
          initData: window.Telegram.WebApp.initData,
          miningData: newUpgrades,
        }),
      })

      toast({
        title: "Upgrade successful",
        description: `Your mining ${selectedUpgrade} has been upgraded!`,
      })

      setShowUpgradePaymentDialog(false)
      await fetchUserData()
    } catch (error) {
      console.error("Upgrade error:", error)
      toast({
        title: "Upgrade failed",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      })
    }
  }

  const handleClaimReward = async () => {
    setIsProcessing(true)
    try {
      const subscription = user?.mining_subscription
      const isPremium = subscription?.plan === 'premium'
      const miningDuration = isPremium ? 8 : 12

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "claim_mining_reward",
          initData: window.Telegram.WebApp.initData,
          miningDuration: miningDuration * 60 * 60 * 1000
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to claim reward")
      }

      const data = await response.json()

      toast({
        title: "Reward claimed!",
        description: `You received ${data.reward} ${SIMPLE}`,
      })

      await fetchUserData()
        
      if (!isPremium) {
        window.Telegram.WebApp.openLink(CHANNEL_URL)
      }
        
    } catch (error) {
      console.error("Claim error:", error)
      toast({
        title: "Claim failed",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleClaimDailyReward = async (double: boolean) => {
    try {
      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "claim_daily_reward",
          initData: window.Telegram.WebApp.initData,
          double: double, 
       }),
     })
      
      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to claim reward")
      }

      const data = await response.json()
      await fetchUserData()
      return data
    } catch (error) {
      throw error
    }
  }

  const getMiningRate = () => {
   const upgrades = user?.mining_upgrades || {}
   const isPremium = user?.mining_subscription?.plan === 'premium'
   const baseRate = isPremium ? 20000 : 5000
   const rateMultiplier = 1 + (upgrades.rateBoost || 0) * 1
   return Math.floor(baseRate * rateMultiplier)
 }

  const getMiningDuration = () => {
   const upgrades = user?.mining_upgrades || {}
   const isPremium = user?.mining_subscription?.plan === 'premium'
   const baseDuration = isPremium ? 8 : 12
   return baseDuration - (upgrades.timeReduction || 0) 
  }

  const getUpgradeCost = (type: "rate" | "time") => {
    const upgrades = user?.mining_upgrades || {}
    const currentLevel = upgrades[type === "rate" ? "rateBoost" : "timeReduction"] || 0
    return 0.2 + currentLevel * 0.2
  }

  const isSubscriptionActive = user?.mining_subscription?.isActive
  const isPremiumUser = user?.premium || false
  const Balance = user?.balance || 0
  const tickets = user?.tickets_balance || 0
  const userPhoto = window.Telegram?.WebApp?.initDataUnsafe?.user?.photo_url || ""
  const userName = window.Telegram?.WebApp?.initDataUnsafe?.user?.first_name || "User"
  const displayName = userName.length > 12 ? `${userName.substring(0, 12)}...` : userName
  const upgrades = user?.mining_upgrades || {}

  if (isLoading) {
    return (
      <AppLayout>
        <div className="min-h-screen bg-[#000] flex items-center justify-center">
          <div className="w-14 h-14 border-2 border-[#ff6b35] border-t-transparent rounded-full animate-spin" />
        </div>
      </AppLayout>
    )
  }
    
  return (
    <AppLayout>
      <div className="min-h-screen bg-[#000] text-white w-full flex flex-col">
        <HeaderActions 
          router={router}
          setShowDailyRewardDialog={setShowDailyRewardDialog}
          setShowWalletDialog={setShowWalletDialog}
          setShowUpgradeDialog={setShowUpgradeDialog}
          isSubscriptionActive={isSubscriptionActive}
          isPremiumUser={isPremiumUser}
          tickets={tickets}
          setShowTicketDialog={setShowTicketDialog}  
        />

        <UserProfileSection 
          userPhoto={userPhoto}
          userName={userName}
          displayName={displayName}
          isPremiumUser={isPremiumUser}
          Balance={Balance}
          router={router}
          user={user}
          onImageClick={() => setShowUserInfoDialog(true)}
        />
          
        <UserInfoDialog
          open={showUserInfoDialog}
          onOpenChange={setShowUserInfoDialog}
          user={user}
          userPhoto={userPhoto}
          userName={userName}
         />
        
        <div className="pb-24 px-6 relative">
          <MiningStatusCard
            isSubscriptionActive={isSubscriptionActive}
            canClaim={canClaim}
            minedCoins={minedCoins}
            timeRemaining={timeRemaining}
            isProcessing={isProcessing}
            setShowPlanDialog={setShowPlanDialog}
            setShowSubscriptionInfoDialog={setShowSubscriptionInfoDialog}
            handleClaimReward={handleClaimReward}
         />
          <LeaderboardSection router={router} />
        </div>

        <UpgradeSelectionDialog
          open={showUpgradeDialog}
          onOpenChange={setShowUpgradeDialog}
          onUpgradeSelect={handleUpgradeSelect}
          upgrades={upgrades}
          miningRate={getMiningRate()}
          miningDuration={getMiningDuration()}
        />

        <UpgradeDialog
          open={showUpgradePaymentDialog}
          onOpenChange={setShowUpgradePaymentDialog}
          onUpgrade={processUpgrade}
          type={selectedUpgrade!}
          currentLevel={upgrades[selectedUpgrade === "rate" ? "rateBoost" : "timeReduction"] || 0}
          miningRate={getMiningRate()}
          miningDuration={getMiningDuration()}
        />
          
        <DailyRewardDialog
          open={showDailyRewardDialog}
          onOpenChange={setShowDailyRewardDialog}
          onClaim={handleClaimDailyReward}
          lastClaimedDate={user?.last_daily_reward}
          balance={walletBalance}
          hasWallet={!!userAddress}
        />
        
        <WalletDialog
          open={showWalletDialog}
          onOpenChange={setShowWalletDialog}
          walletConnected={!!userAddress}
          userAddress={userAddress}
        />
          
        <SubscriptionDialog
          open={showPlanDialog}
          onOpenChange={setShowPlanDialog}
          onSubscribe={activateSubscription}
          currentPlan={user?.mining_subscription?.plan}
        />

        <MiningSubscriptionDialog
          open={showSubscriptionInfoDialog}
          onOpenChange={setShowSubscriptionInfoDialog}
          subscription={user?.mining_subscription}
          upgrades={user?.mining_upgrades || {}}
          onUpgrade={() => {
            setShowSubscriptionInfoDialog(false)
            setShowPlanDialog(true)
          }}
         />

        <TicketPurchaseDialog 
          open={showTicketDialog} 
          onOpenChange={setShowTicketDialog}
        />
          
        <BottomNavigation />
      </div>
    </AppLayout>
  )
}

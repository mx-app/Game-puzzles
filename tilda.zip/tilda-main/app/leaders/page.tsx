"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AppLayout } from "@/components/app-layout"
import { useToast } from "@/components/ui/use-toast"
import { LoadingScreen } from "@/components/loading-screen"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FaCoins, FaUserFriends, FaCrown, FaMedal } from "react-icons/fa"
import { BottomNavigation } from "@/components/bottom-navigation"
import Image from "next/image"
import { motion } from "framer-motion"
import { Skeleton } from "@/components/ui/skeleton"
import { formatBalance } from "@/lib/utils"
import { SIMPLE, NAME } from "@/lib/config"

type LeaderboardUser = {
  telegram_id: string
  telegram_username?: string
  user_photo_url?: string
  balance?: number
  referrals_count?: number
  premium?: boolean 
  rank: number
}

const LeaderboardSkeleton = ({ count = 15 }: { count?: number }) => {
  return (
    <div className="space-y-4">
      {Array.from({ length: count }).map((_, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
          className="dark-bg rounded-2xl p-4"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 min-w-0">
              <Skeleton className="w-10 h-10 rounded-lg bg-[#1A1A1A]" />
              <div className="min-w-0 space-y-2">
                <Skeleton className="h-4 bg-[#1A1A1A] rounded w-24" />
                <Skeleton className="h-3 bg-[#1A1A1A] rounded w-16" />
              </div>
            </div>
            <Skeleton className="h-4 bg-[#1A1A1A] rounded w-12" />
          </div>
        </motion.div>
      ))}
    </div>
  )
}

export default function LeaderboardPage() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(true)
  const [balanceLeaderboard, setBalanceLeaderboard] = useState<LeaderboardUser[]>([])
  const [referralsLeaderboard, setReferralsLeaderboard] = useState<LeaderboardUser[]>([])
  const [activeTab, setActiveTab] = useState("balance")
  const [currentUserId, setCurrentUserId] = useState<string | null>(null)

  const truncateUsername = (username?: string) => {
    if (!username) return "User"
    if (username.length <= 2) return username
    return username[0] + "***" + username[username.length - 1]
  }

  const fetchCurrentUser = async () => {
    try {
      if (typeof window === "undefined" || !window.Telegram?.WebApp?.initData) {
        return null
      }

      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_or_create_user",
          initData: window.Telegram.WebApp.initData,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        return data.user.telegram_id
      }
      return null
    } catch (error) {
      console.error("Error fetching current user:", error)
      return null
    }
  }

  const fetchLeaderboardData = async (type: string) => {
    try {
      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "get_leaderboard",
          initData: window.Telegram.WebApp.initData,
          leaderboardType: type,
        }),
      })

      if (!response.ok) throw new Error("Failed to fetch leaderboard")

      const data = await response.json()
      return data.leaderboard || []
    } catch (error) {
      console.error(`Error fetching ${type} leaderboard:`, error)
      toast({
        title: "Error",
        description: `Failed to load ${type} leaderboard`,
        variant: "destructive",
      })
      return []
    }
  }

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true)
      const userId = await fetchCurrentUser()
      setCurrentUserId(userId)

      const [balanceData, referralsData] = await Promise.all([
        fetchLeaderboardData("balance"),
        fetchLeaderboardData("referrals"),
      ])
      setBalanceLeaderboard(balanceData)
      setReferralsLeaderboard(referralsData)
      setIsLoading(false)
    }

    loadData()
  }, [])

  const getUserCardStyle = (rank: number, isCurrentUser: boolean) => {
    let borderClass = ""
    let bgClass = "dark-bg"

    if (isCurrentUser) {
      borderClass = "border border-tp"
      bgClass = "bg-tp bg-overlay"
    } else {
      switch (rank) {
        case 1:
          borderClass = "border border-[#FFD700]"
          bgClass = "bg-gradient-to-b from-[#FFD700]/10 to-dark-bg"
          break
        case 2:
          borderClass = "border border-[#C0C0C0]"
          bgClass = "bg-gradient-to-b from-[#C0C0C0]/10 to-dark-bg"
          break
        case 3:
          borderClass = "border border-[#CD7F32]"
          bgClass = "bg-gradient-to-b from-[#CD7F32]/10 to-dark-bg"
          break
        default:
          borderClass = ""
      }
    }

    return `${borderClass} ${bgClass} rounded-2xl`
  }

  const getRankBadge = (rank: number) => {
    switch (rank) {
      case 1:
        return (
          <Badge className="bg-gradient-to-r from-[#FFD700] to-[#FFC000] text-black border-[#FFD700]">
            <FaCrown className="w-3 h-3" />
          </Badge>
        )
      case 2:
        return (
          <Badge className="bg-gradient-to-r from-[#C0C0C0] to-[#A0A0A0] text-black border-[#C0C0C0]">
            <FaMedal className="w-3 h-3" />
          </Badge>
        )
      case 3:
        return (
          <Badge className="bg-gradient-to-r from-[#CD7F32] to-[#B87333] text-black border-[#CD7F32]">
            <FaMedal className="w-3 h-3" />
          </Badge>
        )
      default:
        return (
          <Badge className="dark-bg text-[#a0a0a0] border-[#1A1A1A]">
            #{rank}
          </Badge>
        )
    }
  }

  const renderLeaderboardList = (users: LeaderboardUser[], type: 'balance' | 'referrals') => {
    if (users.length === 0) return null

    return (
      <div className="space-y-3">
        {users.map((user) => {
          const isCurrentUser = user.telegram_id === currentUserId
          return (
            <motion.div
              key={`${type}-${user.telegram_id}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className={getUserCardStyle(user.rank, isCurrentUser)}
            >
              <div className="py-2 px-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 min-w-0 flex-1">
                    <div className="w-10 h-10 bg-tp ml-2 rounded-2xl mr-2 flex items-center justify-center relative flex-shrink-0">
                      {user.user_photo_url ? (
                        <Image
                          src={user.user_photo_url}
                          alt={user.telegram_username || 'User'}
                          width={40}
                          height={40}
                          className="object-cover rounded-2xl"
                        />
                      ) : (
                        <div className="text-tp font-bold">
                          {user.telegram_username?.charAt(0) || '?'}
                        </div>
                      )}
                      {user.premium && (
                        <div className="absolute -top-2 -right-2 z-1 bg-[#ff6b35] rounded-full p-1">
                          <FaCrown className="w-3 h-3 text-white" />
                        </div>
                      )}
                    </div>
                    
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center space-x-2">
                        <div className="text-white font-medium text-sm">
                          {truncateUsername(user.telegram_username)}
                        </div>
                        {isCurrentUser && (
                          <span className="fire-text font-bold text-sm">
                            You
                          </span>
                        )}
                      </div>
                      <div className="mt-1">
                        {getRankBadge(user.rank)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center ml-2">
                    <span className="text-sm font-medium">
                      {type === 'balance' 
                        ? formatBalance(user.balance || 0)
                        : user.referrals_count || 0}
                    </span>
                    {type === 'balance' ? (
                      <Image 
                        src="/logo.svg" 
                        alt="TP" 
                        width={22} 
                        height={22} 
                        className="ml-1 text-tp"
                      />
                    ) : (
                      <FaUserFriends className="w-4 h-4 ml-1 text-tp" />
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>
    )
  }

  if (isLoading) {
    return (
      <AppLayout>
        <div className="min-h-screen text-white w-full">
          <div className="pb-24 pt-4 w-[90%] mx-auto max-w-md">
            <div className="text-center mb-6">
              <h1 className="text-2xl font-bold fire-text mb-1">Leaderboard</h1>
              <p className="text-[#a0a0a0] text-sm">
                Top Performers in the {NAME} Community
              </p>
            </div>

            <Tabs defaultValue="balance" className="w-full">
              <TabsList className="grid w-full grid-cols-2 dark-bg h-12 rounded-2xl p-1 mb-4">
                <TabsTrigger
                  value="balance"
                  className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
                >
                  <div className="flex items-center justify-center space-x-2 z-10 relative">
                    <FaCoins className="w-4 h-4 text-tp" />
                    <span>Balance</span>
                  </div>
                </TabsTrigger>
                <TabsTrigger
                  value="referrals"
                  className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
                >
                  <div className="flex items-center justify-center space-x-2 z-10 relative">
                    <FaUserFriends className="w-4 h-4 text-tp" />
                    <span>Referrals</span>
                  </div>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="balance" className="mt-2">
                <LeaderboardSkeleton />
              </TabsContent>

              <TabsContent value="referrals" className="mt-2">
                <LeaderboardSkeleton />
              </TabsContent>
            </Tabs>
          </div>
          <BottomNavigation />
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout>
      <div className="min-h-screen text-white w-full">
        <div className="pb-24 pt-4 w-[90%] mx-auto max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold fire-text mb-1">Leaderboard</h1>
             <p className="text-[#a0a0a0] text-sm">
              Top Performers in the {NAME} Community
             </p>
           </div>

          <Tabs 
            defaultValue="balance" 
            className="w-full"
            onValueChange={(value) => setActiveTab(value)}
          >
            <TabsList className="grid w-full grid-cols-2 dark-bg h-12 rounded-2xl p-1 mb-4">
              <TabsTrigger
                value="balance"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
              >
                <div className="flex items-center justify-center space-x-2 z-10 relative">
                  <FaCoins className="w-4 h-4 text-tp" />
                  <span>Balance</span>
                </div>
                <div className="absolute inset-0 data-[state=active]:bg-[#2a2a2a] data-[state=active]:rounded-xl z-0" />
              </TabsTrigger>
              <TabsTrigger
                value="referrals"
                className="relative rounded-xl h-full text-sm font-medium data-[state=active]:text-white data-[state=active]:bg-[#2a2a2a] transition-all"
              >
                <div className="flex items-center justify-center space-x-2 z-10 relative">
                  <FaUserFriends className="w-4 h-4 text-tp" />
                  <span>Referrals</span>
                </div>
                <div className="absolute inset-0 data-[state=active]:bg-[#2a2a2a] data-[state=active]:rounded-xl z-0" />
              </TabsTrigger>
            </TabsList>

            <TabsContent value="balance" className="mt-2">
              {balanceLeaderboard.length === 0 ? (
                <Card className="dark-bg rounded-2xl">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 mx-auto mb-4 bg-[#2a2a2a] rounded-2xl flex items-center justify-center">
                      <FaCoins className="w-7 h-7 text-[#a0a0a0]" />
                    </div>
                    <h3 className="fire-text text-lg font-semibold mb-2">No Data Available</h3>
                    <p className="text-[#a0a0a0] text-sm">
                      Leaderboard data will appear here soon
                    </p>
                  </CardContent>
                </Card>
              ) : (
                renderLeaderboardList(balanceLeaderboard, 'balance')
              )}
            </TabsContent>

            <TabsContent value="referrals" className="mt-2">
              {referralsLeaderboard.length === 0 ? (
                <Card className="dark-bg rounded-2xl">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 mx-auto mb-4 bg-[#2a2a2a] rounded-2xl flex items-center justify-center">
                      <FaUserFriends className="w-7 h-7 text-[#a0a0a0]" />
                    </div>
                    <h3 className="fire-text text-lg font-semibold mb-2">No Data Available</h3>
                    <p className="text-[#a0a0a0] text-sm">
                      Leaderboard data will appear here soon
                    </p>
                  </CardContent>
                </Card>
              ) : (
                renderLeaderboardList(referralsLeaderboard, 'referrals')
              )}
            </TabsContent>
          </Tabs>
        </div>
        <BottomNavigation />
      </div>
    </AppLayout>
  )
}

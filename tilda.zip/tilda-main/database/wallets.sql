-- Environmental Variables
-- ============================
-- ADMIN_SECRET
-- SUPABASE_KEY
-- SUPABASE_URL
-- TELEGRAM_BOT_TOKEN
-- ALLOWED_ORIGINS

CREATE TABLE IF NOT EXISTS wallets (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  telegram_id TEXT NOT NULL UNIQUE,
  telegram_username TEXT,
  user_photo_url TEXT, 
  balance DECIMAL(20,2) DEFAULT 0,
  tickets_balance INTEGER DEFAULT 0,
  mining_subscription JSONB DEFAULT '{}'::jsonb,
  mining_upgrades JSONB DEFAULT '{}'::jsonb,
  referrals JSONB DEFAULT '[]'::jsonb,
  completed_tasks JSONB DEFAULT '[]'::jsonb, 
  is_banned BOOLEAN DEFAULT FALSE,
  premium BOOLEAN DEFAULT FALSE, 
  last_daily_reward TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tasks (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  image_url TEXT NOT NULL,
  task_url TEXT NOT NULL,
  reward_amount DECIMAL(20,2) NOT NULL,
  task_type TEXT NOT NULL CHECK (task_type IN ('main', 'partner')),
  completed_count INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_wallets_telegram_id ON wallets(telegram_id);
CREATE INDEX IF NOT EXISTS idx_wallets_balance ON wallets(balance);
CREATE INDEX IF NOT EXISTS idx_tasks_type ON tasks(task_type);
CREATE INDEX IF NOT EXISTS idx_tasks_active ON tasks(is_active) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS idx_wallets_premium ON wallets(premium);
CREATE INDEX IF NOT EXISTS idx_wallets_tickets_balance ON wallets(tickets_balance);

-- وظيفة لتحديث رصيد التذاكر
CREATE OR REPLACE FUNCTION update_tickets_balance(
    p_telegram_id TEXT,
    p_tickets_amount INTEGER
)
RETURNS INTEGER
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
    v_new_balance INTEGER;
BEGIN
    UPDATE wallets
    SET 
        tickets_balance = tickets_balance + p_tickets_amount,
        updated_at = NOW()
    WHERE telegram_id = p_telegram_id
    RETURNING tickets_balance
    INTO v_new_balance;
    
    RETURN v_new_balance;
END;
$$ SECURITY DEFINER;

-- وظيفة لاستخدام تذكرة واحدة
CREATE OR REPLACE FUNCTION use_ticket(
    p_telegram_id TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
    v_current_balance INTEGER;
BEGIN
    -- التحقق من الرصيد الحالي
    SELECT tickets_balance INTO v_current_balance
    FROM wallets
    WHERE telegram_id = p_telegram_id;
    
    -- إذا لم يكن هناك رصيد كافي
    IF v_current_balance < 1 THEN
        RETURN FALSE;
    END IF;
    
    -- خصم تذكرة واحدة
    UPDATE wallets
    SET 
        tickets_balance = tickets_balance - 1,
        updated_at = NOW()
    WHERE telegram_id = p_telegram_id;
    
    RETURN TRUE;
END;
$$ SECURITY DEFINER;

-- وظيفة لتحديث حالة البريميوم
CREATE OR REPLACE FUNCTION update_premium_status(
    p_telegram_id TEXT,
    p_premium_status BOOLEAN
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
    v_affected INTEGER;
BEGIN
    UPDATE wallets
    SET 
        premium = p_premium_status,
        updated_at = NOW()
    WHERE telegram_id = p_telegram_id;

    GET DIAGNOSTICS v_affected = ROW_COUNT;

    RETURN v_affected > 0;
END;
$$ SECURITY DEFINER;

-- وظيفة لمنح مكافأة الرصيد
CREATE OR REPLACE FUNCTION award_reward(
    p_telegram_id TEXT,
    p_reward      DECIMAL(20,2)
)
RETURNS DECIMAL(20,2)
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
    v_effective_reward DECIMAL(20,2);
    v_new_balance      DECIMAL(20,2);
BEGIN
    -- حساب المكافأة الفعلية (مضاعفة للبريميوم)
    SELECT
        CASE WHEN premium THEN p_reward * 2 ELSE p_reward END
    INTO v_effective_reward
    FROM wallets
    WHERE telegram_id = p_telegram_id
    FOR UPDATE;                  

    -- تحديث الرصيد
    UPDATE wallets
    SET balance = balance + v_effective_reward,
        updated_at = NOW()
    WHERE telegram_id = p_telegram_id
    RETURNING balance
    INTO v_new_balance;

    RETURN v_new_balance;
END;
$$ SECURITY DEFINER;

--
CREATE OR REPLACE FUNCTION deduct_balance(
  p_telegram_id TEXT,
  p_amount      DECIMAL(20,2)
)
RETURNS DECIMAL(20,2)
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  v_current_balance DECIMAL(20,2);
  v_new_balance     DECIMAL(20,2);
BEGIN
  -- تأكيد وجود المستخدم وقفل السطر للتحديث
  SELECT balance
  INTO v_current_balance
  FROM wallets
  WHERE telegram_id = p_telegram_id
  FOR UPDATE;

  -- التأكد من أن الرصيد كافٍ للخصم
  IF v_current_balance < p_amount THEN
    RAISE EXCEPTION 'Insufficient balance. Available: %, Requested: %', v_current_balance, p_amount;
  END IF;

  -- الخصم من الرصيد
  UPDATE wallets
  SET balance = balance - p_amount,
      updated_at = NOW()
  WHERE telegram_id = p_telegram_id
  RETURNING balance
  INTO v_new_balance;

  RETURN v_new_balance;
END;
$$
SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_top_users_by_balance(
    limit_count integer DEFAULT 50
)
RETURNS TABLE (
    telegram_id        TEXT,
    telegram_username  TEXT,
    user_photo_url     TEXT,
    balance            DECIMAL(20,2),
    premium            BOOLEAN,
    rank               BIGINT
)
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
    RETURN QUERY
    SELECT
        w.telegram_id,
        w.telegram_username,
        w.user_photo_url,
        w.balance,
        w.premium,
        ROW_NUMBER() OVER (
            ORDER BY w.balance DESC,         
                     w.telegram_id ASC       
        )::BIGINT AS rank
    FROM wallets w
    ORDER BY
        w.balance DESC,
        w.telegram_id ASC
    LIMIT limit_count;
END;
$$;

CREATE OR REPLACE FUNCTION get_top_users_by_referrals(
    limit_count integer DEFAULT 50
)
RETURNS TABLE (
    telegram_id        TEXT,
    telegram_username  TEXT,
    user_photo_url     TEXT,
    referrals_count    BIGINT,
    premium            BOOLEAN,
    rank               BIGINT
)
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
    RETURN QUERY
    SELECT
        w.telegram_id,
        w.telegram_username,
        w.user_photo_url,
        jsonb_array_length(w.referrals)::BIGINT AS referrals_count,
        w.premium,
        ROW_NUMBER() OVER (
            ORDER BY jsonb_array_length(w.referrals) DESC,
                     w.telegram_id ASC 
        )::BIGINT AS rank
    FROM wallets w
    WHERE jsonb_array_length(w.referrals) > 0
    ORDER BY
        referrals_count DESC,
        w.telegram_id ASC
    LIMIT limit_count;
END;
$$;

-- وظيفة لتحديث وقت التعديل تلقائيا
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at := NOW();
  RETURN NEW;
END;
$$;

-- مشغل لتحديث وقت التعديل في جدول المحافظ
CREATE TRIGGER update_wallets_updated_at
BEFORE UPDATE ON wallets
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- مشغل لتحديث وقت التعديل في جدول المهام
CREATE OR REPLACE FUNCTION update_tasks_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at := NOW();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_tasks_updated_at
BEFORE UPDATE ON tasks
FOR EACH ROW
EXECUTE FUNCTION update_tasks_updated_at();

-- سياسات الأمان
ALTER TABLE wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "deny_all_to_public_wallets"
ON wallets
AS RESTRICTIVE
FOR ALL
TO public
USING (false);

CREATE POLICY "deny_all_to_public_tasks"
ON tasks
AS RESTRICTIVE
FOR ALL
TO public
USING (false);

CREATE POLICY "Allow tasks to read their own data" ON tasks
    FOR SELECT TO public
    USING (true);

CREATE POLICY "Allow public insertion of tasks" ON tasks
    FOR INSERT TO public
    WITH CHECK (true);

CREATE POLICY "Allow public updating for tasks" ON tasks
    FOR UPDATE TO public
    WITH CHECK (true);

CREATE POLICY "Allow users to read their own data" ON wallets
    FOR SELECT TO public
    USING (true);

CREATE POLICY "Allow public insertion of users" ON wallets
    FOR INSERT TO public
    WITH CHECK (true);

CREATE POLICY "Allow public updating for users" ON wallets
    FOR UPDATE TO public
    WITH CHECK (true);

-- فهارس إضافية
CREATE INDEX IF NOT EXISTS idx_wallets_balance_desc ON wallets(balance DESC);
CREATE INDEX IF NOT EXISTS idx_wallets_referrals_count ON wallets((jsonb_array_length(referrals)) DESC);

INSERT INTO tasks (title, image_url, task_url, reward_amount, task_type)
VALUES
('Join Our Telegram Channel', 'https://raw.githubusercontent.com/elsoghiar/image/refs/heads/main/gem.png', 'https://t.me/Gem_Farming', 500, 'main'),

('Play Specters', 'https://raw.githubusercontent.com/elsoghiar/image/refs/heads/main/specters.jpg', 'https://t.me/TheSpecters_Bot/app', 1000, 'partner');

---

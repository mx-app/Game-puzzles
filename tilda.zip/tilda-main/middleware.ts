import { NextResponse, NextRequest } from 'next/server'
import { APP_URL } from "@/lib/config"

const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS ?? `${APP_URL}`)
  .split(',')
  .map(s => s.trim())
  .filter(Boolean)

const CORS_COMMON = {
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
}

function isAllowed(request: NextRequest) {
  const origin = request.headers.get('origin') ?? ''
  const referer = request.headers.get('referer') ?? ''
  const host = request.headers.get('host') ?? ''
  const origins = new Set(ALLOWED_ORIGINS)

  if (host && ALLOWED_ORIGINS.some(o => o.includes(host))) return true

  if (origin && origins.has(origin)) return true

  try {
    if (referer) {
      const refOrigin = new URL(referer).origin
      if (origins.has(refOrigin)) return true
    }
  } catch {}

  return false
}

function isForbiddenClient(request: NextRequest) {
  const ua = (request.headers.get('user-agent') || '').toLowerCase()

  if (
    ua.includes('curl') ||
    ua.includes('wget') ||
    ua.includes('httpclient') ||
    ua.includes('python-requests') ||
    ua.includes('axios') ||
    ua.includes('node-fetch') ||
    ua.includes('okhttp') ||
    ua.includes('java') ||
    ua.includes('libwww')
  ) {
    return true
  }

  if (ua.trim() === '') return true

  return false
}

export function middleware(request: NextRequest) {
  if (!request.nextUrl.pathname.startsWith('/api')) {
    return NextResponse.next()
  }

  if (request.method === 'OPTIONS') {
    const origin = request.headers.get('origin') ?? ''
    const headers = {
      ...(ALLOWED_ORIGINS.includes(origin) && { 'Access-Control-Allow-Origin': origin }),
      ...CORS_COMMON,
    }
    return NextResponse.json({}, { headers })
  }

  if (!isAllowed(request)) {
    return NextResponse.json(
      { error: 'Access denied. Requests must come from inside the app only' },
      { status: 403 }
    )
  }

  if (isForbiddenClient(request)) {
    return NextResponse.json(
      { error: 'API access not allowed from this client' },
      { status: 403 }
    )
  }

  if (request.method === 'POST') {
    const ct = request.headers.get('content-type') || ''
    if (!ct.toLowerCase().startsWith('application/json')) {
      return NextResponse.json(
        { error: 'Invalid content type. Only JSON allowed' },
        { status: 400 }
      )
    }
  }

  const res = NextResponse.next()
  const origin = request.headers.get('origin') ?? ''
  if (ALLOWED_ORIGINS.includes(origin)) {
    res.headers.set('Access-Control-Allow-Origin', origin)
  }
  Object.entries(CORS_COMMON).forEach(([k, v]) => res.headers.set(k, v))
  return res
}

export const config = {
  matcher: '/api/:path*',
}

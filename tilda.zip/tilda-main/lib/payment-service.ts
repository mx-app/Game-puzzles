"use client"

export async function createInvoiceLink(amount: number, label: string, description: string ) {
  try {
    console.log("Creating invoice for subscription:", { amount, label, description })

    const response = await fetch("/api/create-invoice", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        amount,
        label,
        description, 
      }),
      cache: "no-store",
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("Failed to create invoice. Status:", response.status, "Error:", errorText)
      throw new Error(`Failed to create invoice: ${response.status} ${errorText}`)
    }

    const data = await response.json()
    console.log("Invoice created successfully:", data)
    return data.invoiceLink
  } catch (error) {
    console.error("Error creating invoice:", error)
    throw error
  }
}

export function openTelegramInvoice(invoiceLink: string): Promise<"paid" | "cancelled" | "failed"> {
  return new Promise((resolve) => {
    console.log("Opening Telegram invoice:", invoiceLink)

    if (window.Telegram && window.Telegram.WebApp) {
      window.Telegram.WebApp.openInvoice(invoiceLink, (status: string) => {
        console.log("Invoice status:", status)
        resolve(status as "paid" | "cancelled" | "failed")
      })
    } else {
      console.error("Telegram WebApp not available")
      resolve("failed")
    }
  })
}

"use client"

import { useEffect } from "react"
import { usePathname } from "next/navigation"
import { MINI_APP } from "@/lib/config"

function isValidTelegramWebApp(tg) {
  return tg &&
    typeof tg.initData === "string" &&
    tg.initData.length > 0
}

export function useTelegramInit() {
  const pathname = usePathname()

  useEffect(() => {
    if (typeof window === "undefined") return

    const tg = window.Telegram?.WebApp
    if (!isValidTelegramWebApp(tg)) {
      window.location.href = MINI_APP
      return
    }

    tg.ready()
    tg.expand()
    tg.setBackgroundColor("#000")
    tg.setHeaderColor("#000")
    tg.setBottomBarColor("#000")
    tg.disableVerticalSwipes()
    tg.enableClosingConfirmation()

    const handleBackButton = () => {
      if (window.history.length > 1) {
        window.history.back()
      } else {
        tg.close()
      }
    }

    if (pathname === "/") {
      tg.BackButton.hide()
    } else {
      tg.BackButton.show()
      tg.BackButton.onClick(handleBackButton)
    }

    return () => {
      try {
        tg.BackButton.offClick(handleBackButton)
      } catch (e) {
        console.warn("BackButton.offClick failed", e)
      }
    }
  }, [pathname])
}

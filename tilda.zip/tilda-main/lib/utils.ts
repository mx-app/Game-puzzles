import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatNumber(num: number, decimals = 1): string {
  if (num === null || num === undefined) return "0"
  if (num === 0) return "0"

  const absNum = Math.abs(num)
  const sign = num < 0 ? "-" : ""

  if (absNum >= 1e33) {
    return sign + (absNum / 1e33).toFixed(decimals) + ' Dec'
  } else if (absNum >= 1e30) {
    return sign + (absNum / 1e30).toFixed(decimals) + ' Non'
  } else if (absNum >= 1e27) {
    return sign + (absNum / 1e27).toFixed(decimals) + ' Oct'
  } else if (absNum >= 1e24) {
    return sign + (absNum / 1e24).toFixed(decimals) + ' Sep'
  } else if (absNum >= 1e21) {
    return sign + (absNum / 1e21).toFixed(decimals) + ' Sex'
  } else if (absNum >= 1e18) {
    return sign + (absNum / 1e18).toFixed(decimals) + ' Quin'
  } else if (absNum >= 1e15) {
    return sign + (absNum / 1e15).toFixed(decimals) + ' Quad'
  } else if (absNum >= 1e12) {
    return sign + (absNum / 1e12).toFixed(decimals) + ' T'
  } else if (absNum >= 1e9) {
    return sign + (absNum / 1e9).toFixed(decimals) + ' B'
  } else if (absNum >= 1e6) {
    return sign + (absNum / 1e6).toFixed(decimals) + ' M'
  } else if (absNum >= 1e3) {
    return sign + (absNum / 1e3).toFixed(decimals) + ' K'
  }
  
  return sign + absNum.toString()
}

export function formatBalance(balance: number, decimals = 1): string {
  const absBalance = Math.abs(balance)
  const sign = balance < 0 ? '-' : ''

  if (absBalance >= 1e33) {
    return sign + (absBalance / 1e33).toFixed(decimals) + ' Dec'
  } else if (absBalance >= 1e30) {
    return sign + (absBalance / 1e30).toFixed(decimals) + ' Non'
  } else if (absBalance >= 1e27) {
    return sign + (absBalance / 1e27).toFixed(decimals) + ' Oct'
  } else if (absBalance >= 1e24) {
    return sign + (absBalance / 1e24).toFixed(decimals) + ' Sep'
  } else if (absBalance >= 1e21) {
    return sign + (absBalance / 1e21).toFixed(decimals) + ' Sex'
  } else if (absBalance >= 1e18) {
    return sign + (absBalance / 1e18).toFixed(decimals) + ' Quin'
  } else if (absBalance >= 1e15) {
    return sign + (absBalance / 1e15).toFixed(decimals) + ' Quad'
  } else if (absBalance >= 1e12) {
    return sign + (absBalance / 1e12).toFixed(decimals) + ' T'
  } else if (absBalance >= 1e9) {
    return sign + (absBalance / 1e9).toFixed(decimals) + ' B'
  } else if (absBalance >= 1e6) {
    return sign + (absBalance / 1e6).toFixed(decimals) + ' M'
  } else if (absBalance >= 1e3) {
    return sign + (absBalance / 1e3).toFixed(decimals) + ' K'
  }
  
  return sign + absBalance.toString()
}

export function format(num?: number) {
  if (typeof num !== "number" || isNaN(num)) return "0";
  return num.toLocaleString("en-US");
}

export interface WalletBalance {
  balance: string
  address: string
  success: boolean
  error?: string
  status?: string
  last_activity?: number
}

export class WalletService {
  private static instance: WalletService
  public static getInstance(): WalletService {
    if (!WalletService.instance) {
      WalletService.instance = new WalletService()
    }
    return WalletService.instance
  }

  public async checkTonWalletBalance(walletAddress: string): Promise<WalletBalance> {
    try {
      const response = await fetch(`/api/ton/balance?address=${encodeURIComponent(walletAddress)}`)
      
      if (!response.ok) {
        throw new Error("فشل في الاتصال بالخادم")
      }

      const data = await response.json()
      
      if (typeof data.balance === 'undefined') {
        throw new Error("استجابة الخادم غير متوقعة")
      }

      return {
        balance: data.balance.toString(),
        address: walletAddress,
        success: true,
        status: data.status,
        last_activity: data.last_activity
      }
      
    } catch (error) {
      console.error("خطأ في التحقق من رصيد المحفظة:", error)
      return {
        balance: "0",
        address: walletAddress,
        success: false,
        error: error instanceof Error ? error.message : "خطأ غير معروف",
      }
    }
  }

  public async hasEnoughBalance(
    walletAddress: string,
    requiredAmount: number
  ): Promise<{
    sufficient: boolean
    currentBalance: number
    requiredAmount: number
    difference?: number
    error?: string
    status?: string
  }> {
    const balanceData = await this.checkTonWalletBalance(walletAddress)

    if (!balanceData.success) {
      return {
        sufficient: false,
        currentBalance: 0,
        requiredAmount,
        difference: requiredAmount,
        error: balanceData.error,
        status: balanceData.status
      }
    }

    const currentBalance = parseFloat(balanceData.balance)
    const sufficient = currentBalance >= requiredAmount

    return {
      sufficient,
      currentBalance,
      requiredAmount,
      difference: sufficient ? undefined : requiredAmount - currentBalance,
      status: balanceData.status
    }
  }
}

export const walletService = WalletService.getInstance()

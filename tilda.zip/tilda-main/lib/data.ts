export const TICKET_PACKAGES = [
  {
    id: "pack_1",
    title: "Starter Pack",
    tickets: 1,
    tonPrice: 0.4,
    starsPrice: 160,
  },
  {
    id: "pack_2",
    title: "Gamer Pack",
    tickets: 5,
    tonPrice: 1.2,
    starsPrice: 480,
  },
  {
    id: "pack_3",
    title: "Pro Pack",
    tickets: 12,
    tonPrice: 2.0,
    starsPrice: 800,
    bonus: 3,
  },
  {
    id: "pack_4",
    title: "Legend Pack",
    tickets: 30,
    tonPrice: 5.0,
    starsPrice: 2000,
    bonus: 10,
  },
  {
    id: "pack_5",
    title: "Mega Pack",
    tickets: 60,
    tonPrice: 9.0,
    starsPrice: 3600,
    bonus: 20,
  },
  {
    id: "pack_6",
    title: "Ultimate Pack",
    tickets: 100,
    tonPrice: 15.0,
    starsPrice: 6000,
    bonus: 50,
  },
]

export const TICKET_PACKAGES4 = [
  {
    id: "pack_1",
    title: "Starter Pack",
    tickets: 1,
    tonPrice: 0.4,
    starsPrice: 160,
  },
  {
    id: "pack_2",
    title: "Gamer Pack",
    tickets: 5,
    tonPrice: 1.2,
    starsPrice: 480,
  },
  {
    id: "pack_3",
    title: "Pro Pack",
    tickets: 12,
    tonPrice: 2.0,
    starsPrice: 800,
    bonus: 3,
  },
  {
    id: "pack_4",
    title: "Legend Pack",
    tickets: 30,
    tonPrice: 5.0,
    starsPrice: 2000,
    bonus: 10,
  },
]

export const TP_PACKAGES = [
  {
    id: "package_1",
    tpAmount: 100000,
    tonPrice: 1,
    starsPrice: 400,
  },
  {
    id: "package_2",
    tpAmount: 250000,
    tonPrice: 2.25,
    starsPrice: 900,
    discount: 10,
  },
  {
    id: "package_3",
    tpAmount: 500000,
    tonPrice: 4,
    starsPrice: 1600,
    discount: 20,
  },
  {
    id: "package_4",
    tpAmount: 750000,
    tonPrice: 5.5,
    starsPrice: 2200,
    discount: 27,
  },
  {
    id: "package_5",
    tpAmount: 1000000,
    tonPrice: 7,
    starsPrice: 2800,
    discount: 30,
    popular: true,
  },
  {
    id: "package_6",
    tpAmount: 2500000,
    tonPrice: 15,
    starsPrice: 6000,
    discount: 40,
  },
  {
    id: "package_7",
    tpAmount: 5000000,
    tonPrice: 27.5,
    starsPrice: 11000,
    discount: 45,
  },
  {
    id: "package_8",
    tpAmount: 7500000,
    tonPrice: 37.5,
    starsPrice: 15000,
    discount: 50,
  },
  {
    id: "package_9",
    tpAmount: 10000000,
    tonPrice: 45,
    starsPrice: 18000,
    discount: 55,
  },
  {
    id: "package_10",
    tpAmount: 20000000,
    tonPrice: 80,
    starsPrice: 32000,
    discount: 60,
  },
]

export const NFT_ITEMS = [
  {
    id: "nft_1",
    name: "TP #1",
    image: "/tp1.svg",
    tonPrice: 1,
    starsPrice: 400,
  },
  {
    id: "nft_2",
    name: "TP #2",
    image: "/tp2.svg",
    tonPrice: 3,
    starsPrice: 1200,
  },
  {
    id: "nft_3",
    name: "TP #3",
    image: "/tp3.svg",
    tonPrice: 5,
    starsPrice: 2000,
  },
  {
    id: "nft_4",
    name: "TP #4",
    image: "/tp4.svg",
    tonPrice: 10,
    starsPrice: 4000,
  },
]

export const TICKET_PRIZES = [
  { id: "tickets_1", type: "tickets", amount: 1, color: "#ff6b35" },
  { id: "tickets_2", type: "tickets", amount: 2, color: "#ff6b35" },
  { id: "tickets_3", type: "tickets", amount: 3, color: "#ff6b35" },
  { id: "tickets_4", type: "tickets", amount: 5, color: "#ff6b35" },
  { id: "tickets_5", type: "tickets", amount: 10, color: "#ff6b35" },
]

export const TP_PRIZES = [
  { id: "tp_1", type: "tp", amount: 5000, color: "#ff6b35" },
  { id: "tp_2", type: "tp", amount: 10000, color: "#ff6b35" },
  { id: "tp_3", type: "tp", amount: 15000, color: "#ff6b35" },
  { id: "tp_4", type: "tp", amount: 25000, color: "#ff6b35" },
  { id: "tp_5", type: "tp", amount: 50000, color: "#ff6b35" },
  { id: "tp_6", type: "tp", amount: 75000, color: "#ff6b35" },
  { id: "tp_7", type: "tp", amount: 100000, color: "#ff6b35" },
]

export default {
  async fetch(request, env) {
    if (request.method !== "POST") {
      return new Response("Only POST requests are allowed", { status: 405 });
    }

    const TELEGRAM_BOT_TOKEN = env.TELEGRAM_BOT_TOKEN;
    if (!TELEGRAM_BOT_TOKEN) {
      return new Response("Bot token is missing in environment variables.", { status: 500 });
    }

    try {
      const update = await request.json();

      if (update.pre_checkout_query) {
        const query_id = update.pre_checkout_query.id;

        const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/answerPreCheckoutQuery`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ pre_checkout_query_id: query_id, ok: true }),
        });

        if (!res.ok) {
          console.error("Failed to answer pre_checkout_query:", await res.text());
        }

        return new Response("Pre-checkout query handled", { status: 200 });
      }

      if (!update.message || !update.message.text) {
        return new Response("No message to process", { status: 200 });
      }

      const chat_id = update.message.chat.id;
      const text = update.message.text.trim();

      if (text.startsWith("/start")) {
        return await sendWelcomeMessage(chat_id, TELEGRAM_BOT_TOKEN);
      }

      return new Response("Message received", { status: 200 });

    } catch (err) {
      console.error("Unexpected error in bot handler:", err);
      return new Response("Internal server error", { status: 500 });
    }
  }
};

async function sendWelcomeMessage(chat_id, token) {
  const caption = `<b>Welcome to Tilda!</b>\n\n` +
    `Discover, mine tokens, earn rewards, and rise to the top of the leaderboard.\n` +
    `<i>Quick. Transparent. Rewarding.</i>`;
  
  const keyboard = {
    inline_keyboard: [
      [{ text: "Join Channel", url: "https://t.me/TildaApp" }],
      [{ text: "Launch Tilda", url: "https://t.me/TildaAppBot/App" }]
    ]
  };

  const body = JSON.stringify({
    chat_id,
    photo: "https://raw.githubusercontent.com/elsoghiar/image/refs/heads/main/bot-tilda.png",
    caption,
    parse_mode: "HTML",
    reply_markup: keyboard
  });

  const res = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body,
  });

  if (!res.ok) {
    console.error("Failed to send welcome message:", await res.text());
  }

  return new Response("Welcome message sent", { status: 200 });
}
